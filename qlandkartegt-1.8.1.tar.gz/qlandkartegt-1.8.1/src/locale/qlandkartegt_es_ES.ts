<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_ES">
<context>
    <name></name>
    <message>
        <source>Warning...</source>
        <translation type="obsolete">Peligro...</translation>
    </message>
    <message>
        <source>This is a typ file with unknown polygon encoding. Please report!</source>
        <translation type="obsolete">Esto es un archivo TYP con codificación de poligonos desconocida, ¡Por favor comuniquelo!</translation>
    </message>
    <message>
        <source>This is a typ file with unknown polyline encoding. Please report!</source>
        <translation type="obsolete">Esto es un archivo TYP con codificación de lineas desconocida, ¡Por favor comuniquelo!</translation>
    </message>
    <message>
        <source>This is a typ file with unknown point encoding. Please report!</source>
        <translation type="obsolete">Esto es un archivo TYP con codificación de puntos desconocida, ¡Por favor comuniquelo!</translation>
    </message>
</context>
<context>
    <name>CActions</name>
    <message>
        <location filename="../CActions.cpp" line="55"/>
        <location filename="../CActions.cpp" line="67"/>
        <location filename="../CActions.cpp" line="79"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="55"/>
        <source>&amp;Map ...</source>
        <translation>&amp;Mapa ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="55"/>
        <source>Manage maps.</source>
        <translation>Administrar mapas.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="56"/>
        <location filename="../CActions.cpp" line="68"/>
        <location filename="../CActions.cpp" line="80"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="56"/>
        <source>&amp;Waypoint ...</source>
        <translation>&amp;Waypoint ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="56"/>
        <source>Manage waypoints.</source>
        <translation>Administrar waypoints.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="57"/>
        <location filename="../CActions.cpp" line="69"/>
        <location filename="../CActions.cpp" line="81"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="57"/>
        <source>&amp;Track ...</source>
        <translation>&amp;Track ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="57"/>
        <source>Manage tracks.</source>
        <translation>Administrar tracks.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="58"/>
        <location filename="../CActions.cpp" line="82"/>
        <source>F4</source>
        <translation>F4</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="58"/>
        <source>&amp;Route ...</source>
        <translation>&amp;Ruta ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="60"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="59"/>
        <location filename="../CActions.cpp" line="71"/>
        <location filename="../CActions.cpp" line="85"/>
        <location filename="../CActions.cpp" line="93"/>
        <location filename="../CActions.cpp" line="101"/>
        <location filename="../CActions.cpp" line="107"/>
        <location filename="../CActions.cpp" line="111"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="59"/>
        <source>Live &amp;Log ...</source>
        <translation>Grabación en &amp;Vivo ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="59"/>
        <source>Toggle live log recording.</source>
        <translation>Cambiar a grabación de archivo en vivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="60"/>
        <location filename="../CActions.cpp" line="72"/>
        <location filename="../CActions.cpp" line="86"/>
        <location filename="../CActions.cpp" line="94"/>
        <location filename="../CActions.cpp" line="102"/>
        <location filename="../CActions.cpp" line="108"/>
        <location filename="../CActions.cpp" line="116"/>
        <source>F6</source>
        <translation>F6</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="60"/>
        <source>&amp;Overlay ...</source>
        <translation>&amp;Superponer ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="60"/>
        <source>Manage overlays, such as textboxes</source>
        <translation>Administrar capas, como cuadros de texto</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="61"/>
        <location filename="../CActions.cpp" line="73"/>
        <location filename="../CActions.cpp" line="95"/>
        <location filename="../CActions.cpp" line="103"/>
        <location filename="../CActions.cpp" line="109"/>
        <location filename="../CActions.cpp" line="110"/>
        <source>F7</source>
        <translation>F7</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="61"/>
        <source>Mor&amp;e ...</source>
        <translation>&amp;Más...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="61"/>
        <source>Extended functions.</source>
        <translation>Funciones Adicionales.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="62"/>
        <location filename="../CActions.cpp" line="74"/>
        <location filename="../CActions.cpp" line="88"/>
        <location filename="../CActions.cpp" line="96"/>
        <location filename="../CActions.cpp" line="112"/>
        <location filename="../CActions.cpp" line="113"/>
        <source>F8</source>
        <translation>F8</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="62"/>
        <source>&amp;Clear all</source>
        <translation>&amp;Eliminar todo</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="62"/>
        <source>Remove all waypoints, tracks, ...</source>
        <translation>Eliminar todos los waypoints, tracks, ...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="63"/>
        <location filename="../CActions.cpp" line="75"/>
        <location filename="../CActions.cpp" line="90"/>
        <location filename="../CActions.cpp" line="97"/>
        <location filename="../CActions.cpp" line="119"/>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="63"/>
        <source>U&amp;pload all</source>
        <translation>&amp;Cargar todo</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="63"/>
        <source>Upload all data to device.</source>
        <translation>Cargar todos los datos en el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="64"/>
        <location filename="../CActions.cpp" line="91"/>
        <location filename="../CActions.cpp" line="98"/>
        <location filename="../CActions.cpp" line="120"/>
        <source>F10</source>
        <translation>F10</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="64"/>
        <source>Down&amp;load all</source>
        <translation>&amp;Descargar todo</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="64"/>
        <source>Download all data from device.</source>
        <translation>Descargar todos los datos del dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="66"/>
        <location filename="../CActions.cpp" line="78"/>
        <location filename="../CActions.cpp" line="106"/>
        <source>ESC</source>
        <translation>ESC</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="66"/>
        <location filename="../CActions.cpp" line="106"/>
        <source>&amp;Back</source>
        <translation>&amp;Atrás</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="66"/>
        <source>Go back to main menu.</source>
        <translation>Volver al menu principal.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="67"/>
        <source>Mo&amp;ve Map</source>
        <translation>Mo&amp;ver Mapa</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="67"/>
        <source>Move the map. Press down the left mouse button and move the mouse.</source>
        <translation>Mover el mapa. Pulse el botón izquierdo del ratón y mueva el ratón.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="68"/>
        <source>&amp;Zoom Map</source>
        <translation>A&amp;cercar/Alejar Mapa</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="68"/>
        <source>Select area for zoom.</source>
        <translation>Seleccionar area para ampliar.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="69"/>
        <source>&amp;Center Map</source>
        <translation>&amp;Centrar Mapa</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="69"/>
        <source>Find your map by jumping to it&apos;s center.</source>
        <translation>Encuentre su mapa yendo a su centro.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="71"/>
        <source>Select &amp;Sub Map</source>
        <translation>&amp;Selecionar zona del Mapa</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="71"/>
        <source>Select area of map to export. Select area by pressing down the left mouse button and move the mouse.</source>
        <translation>Seleccione el área del mapa que exportar. Seleccione pulsando el botón izquierdo del ratón y moviendo el ratón.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="72"/>
        <source>&amp;Edit / Create Map</source>
        <translation>&amp;Editar / Crear Mapa</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="73"/>
        <source>&amp;Search Map</source>
        <translation>&amp;Buscar Mapa</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="73"/>
        <source>Find symbols on a map via image recognition.</source>
        <translation>Encontrar símbolos en el mapa mediante recononocimiento de imagen.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="74"/>
        <source>3&amp;D Map...</source>
        <translation>Mapa 3&amp;D...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="74"/>
        <source>Show 3D map</source>
        <translation>Ver mapa en 3D</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="75"/>
        <location filename="../CActions.cpp" line="90"/>
        <location filename="../CActions.cpp" line="97"/>
        <location filename="../CActions.cpp" line="119"/>
        <source>U&amp;pload</source>
        <translation>&amp;Cargar</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="75"/>
        <source>Upload map selection to device.</source>
        <translation>Cargar la selección del mapa en el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="78"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="78"/>
        <source>Close 3D view.</source>
        <translation>Cerrar vista 3D.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="86"/>
        <source>&amp;Radius Select</source>
        <translation>Seleccionar en &amp;Radio</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="86"/>
        <source>Select waypoints in a radius</source>
        <translation>Selecciona los waypoints incluidos en un radio</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="111"/>
        <source>Join Distance PolyLines</source>
        <translation>Unir Polilíneas de Distancia</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="111"/>
        <source>Join distance polylines to one.</source>
        <translation>Unir polilíneas de distancia en una.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="112"/>
        <source>Add Area Polygon</source>
        <translation>Añadir Polígono de Área</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="112"/>
        <location filename="../CActions.cpp" line="113"/>
        <source>Mark an area with a polygon.</source>
        <translation>Marcar un área con un polígono.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="113"/>
        <source>Area Polygon</source>
        <translation>Polígono de Área</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="116"/>
        <source>&amp;Export to OCM</source>
        <translation>&amp;Exportar a OCM</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="116"/>
        <source>Send current workspace to Open Cache Manager.</source>
        <translation>Enviar el espacio de trabajo actual a Open Cache Manager.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="151"/>
        <source>Action with the name &apos;%1&apos; already registered. Please choose another name.</source>
        <translation>La acción con nombre &apos;%1&apos; ya está registrada. Por favor, elija otro nombre.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="305"/>
        <source>&amp;Overlay Area</source>
        <translation>&amp;Superponer Área</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="704"/>
        <location filename="../CActions.cpp" line="707"/>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="704"/>
        <location filename="../CActions.cpp" line="711"/>
        <source>Overlay</source>
        <translation>Superponer</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="705"/>
        <source>What to do?</source>
        <translation>¿Qué hacer?</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="705"/>
        <source>I do not know what to copy. Please select:</source>
        <translation>No sé lo que copiar. Seleccione por favor:</translation>
    </message>
    <message>
        <source>&amp;Flat / 3D Mode</source>
        <translation type="obsolete">Modo de &amp;Vuelo / 3D</translation>
    </message>
    <message>
        <source>Toggle between 3D track only and full map surface model.</source>
        <translation type="obsolete">Cambiar entre solo &quot;track&quot; en 3D y modelo mapa completo .</translation>
    </message>
    <message>
        <source>&amp;Inc. Elevation</source>
        <translation type="obsolete">&amp;Aumentar elevación</translation>
    </message>
    <message>
        <source>Make elevations on the map higher as they are.</source>
        <translation type="obsolete">Aumentar altura sobre el mapa.</translation>
    </message>
    <message>
        <source>&amp;Dec. Elevation</source>
        <translation type="obsolete">&amp;Reducir Elevación</translation>
    </message>
    <message>
        <source>Make elevations on the map lower as they are.</source>
        <translation type="obsolete">Disminuir la altura sobre el mapa.</translation>
    </message>
    <message>
        <source>&amp;Lighting On/Off</source>
        <translation type="obsolete">Encender / Apagar &amp;Luz</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="81"/>
        <source>Turn on/off lighting.</source>
        <translation>Encender / Apagar iluminación.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="85"/>
        <source>&amp;New Waypoint</source>
        <translation>&amp;Nuevo Waypoint</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="85"/>
        <source>Create a new user waypoint. The default position will be the current cursor position.</source>
        <translation>Crear un nuevo waypoint. La posición predeterminada será la posición del cursor.</translation>
    </message>
    <message>
        <source>&amp;Edit Waypoint</source>
        <translation type="obsolete">&amp;Editar Waypoint</translation>
    </message>
    <message>
        <source>Switch cursor to &apos;Edit Waypoint&apos; mode. Point-n-click to edit a waypoint.</source>
        <translation type="obsolete">Cambiar cursor a modo &apos;Editar Waypoint&apos;. Pinche y haga clic para editar.</translation>
    </message>
    <message>
        <source>&amp;Move Waypoint</source>
        <translation type="obsolete">&amp;Desplazar Waypoint</translation>
    </message>
    <message>
        <source>Switch cursor to &apos;Move Waypoint&apos; mode. Point-click-move-click to move a waypoint. Use the right mouse button to abort. It is ok to leave &apos;Move Waypoint&apos; mode and to resume.</source>
        <translation type="obsolete">Cambiar el cursor a modo &apos;Mover Waypoint&apos;. Pulse F7, haga click sobre el waypoint, y desplácelo. Pulse el botón derecho para abortar. Es correcto abandonar el modo &apos;Mover Waypoint&apos; y continuar.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="88"/>
        <source>From &amp;Images...</source>
        <translation>A partir de &amp;Imágenes...</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="88"/>
        <source>Create waypoints from geo-referenced images in a path.</source>
        <translation>Crear waypoints a partir de fotos georeferenciadas en el directorio.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="90"/>
        <source>Upload waypoints to device.</source>
        <translation>Cargar waypoints en el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="91"/>
        <location filename="../CActions.cpp" line="98"/>
        <location filename="../CActions.cpp" line="120"/>
        <source>Down&amp;load</source>
        <translation>&amp;Descargar</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="91"/>
        <source>Download waypoints from device.</source>
        <translation>Descargar waypoints del dispositivo.</translation>
    </message>
    <message>
        <source>Combine &amp;Tracks</source>
        <translation type="obsolete">Combinar &quot;&amp;Tracks&quot;</translation>
    </message>
    <message>
        <source>Combine multiple selected tracks to one.</source>
        <translation type="obsolete">Combinar varios &quot;tracks&quot; en uno.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="94"/>
        <source>&amp;Edit Track</source>
        <translation>&amp;Editar Track</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="94"/>
        <source>Toggle track edit dialog.</source>
        <translation>Activar el menú de edición de track.</translation>
    </message>
    <message>
        <source>&amp;Cut Tracks</source>
        <translation type="obsolete">&amp;Cortar &quot;Track&quot;</translation>
    </message>
    <message>
        <source>Cut a track into pieces.</source>
        <translation type="obsolete">Cortar el &quot;track&quot; en trozos.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="79"/>
        <source>3D / 2D</source>
        <translation>3D / 2D</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="79"/>
        <source>Toggle between 3D and 2D map.</source>
        <translation>Cambiar entre mapa 3D y 2D.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="80"/>
        <source>FPV / Rot.</source>
        <translatorcomment>FPV=First Person View    VPP=Vista en Primera Persona</translatorcomment>
        <translation>VPP / Rot.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="80"/>
        <source>Toggle between first person view and rotation mode.</source>
        <translation>Cambiar entre vista en primera persona y modo rotación.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="81"/>
        <source>Lighting On/Off</source>
        <translation>Encender / Apagar Iluminación</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="82"/>
        <source>Trackmode</source>
        <translation>Modo track</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="82"/>
        <source>Glue point of view to track.</source>
        <translation>Pegar punto de vista al track.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="93"/>
        <source>Join &amp;Tracks</source>
        <translation>Unir &amp;Tracks</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="93"/>
        <source>Join multiple selected tracks to one.</source>
        <translation>Unir varios tracks seleccionados en uno.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="95"/>
        <source>&amp;Split Track</source>
        <translation>&amp;Dividir Track</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="95"/>
        <source>Split a track into pieces.</source>
        <translation>Dividir Track en trozos.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="96"/>
        <source>&amp;Select Points</source>
        <translation>&amp;Seleccionar Puntos</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="96"/>
        <source>Select track points by rectangle.</source>
        <translation>Seleccionar puntos del track mediante un rectángulo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="97"/>
        <source>Upload tracks to device.</source>
        <translation>Cargar tracks en el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="98"/>
        <source>Download tracks from device.</source>
        <translation>Descargar tracks del dispositivo.</translation>
    </message>
    <message>
        <source>Del</source>
        <translation type="obsolete">Supr</translation>
    </message>
    <message>
        <source>Purge Selection</source>
        <translation type="obsolete">Eliminar Selección</translation>
    </message>
    <message>
        <source>Purge the selected points of the track.</source>
        <translation type="obsolete">Eliminar del &quot;track&quot; los puntos seleccionados.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="99"/>
        <source>ctrl+Del</source>
        <translation>Ctrl+Supr</translation>
    </message>
    <message>
        <source>Delete Selection</source>
        <translation type="obsolete">Borrar Selección</translation>
    </message>
    <message>
        <source>Deletes the selected points of the track.</source>
        <translation type="obsolete">Borrar los puntos del &quot;track&quot; seleccionados.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="99"/>
        <source>Hide/Show Selection</source>
        <translation>Ocultar/Mostrar Selección</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="99"/>
        <source>Toggle visibility of the selected track points.</source>
        <translation>Cambiar la visibilidad de los puntos seleccionados del track.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="101"/>
        <source>&amp;Start / Stop</source>
        <translation>&amp;Iniciar / Detener</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="101"/>
        <source>Start / stop live log recording.</source>
        <translation>Iniciar / Detener el registro en vivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="102"/>
        <source>Move Map to &amp;Pos.</source>
        <translation>Mover el Mapa a la &amp;Posición</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="102"/>
        <source>Move the map to keep the positon cursor centered.</source>
        <translation>Centrar el mapa en la posición del cursor.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="103"/>
        <source>Add &amp;Waypoint</source>
        <translation>Añadir &amp;Waypoint</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="103"/>
        <source>Add a waypoint at current position.</source>
        <translation>Añadir waypoint en la posición actual.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="106"/>
        <source>Go back to overlay menu.</source>
        <translation>Volver al menú superponer.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="107"/>
        <source>Add Static &amp;Text Box</source>
        <translation>Añadir Cuadro de &amp;Texto Estático</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="107"/>
        <source>Add text on the map.</source>
        <translation>Añadir texto al mapa.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="108"/>
        <source>Add &amp;Geo-Ref. Text Box</source>
        <translation>Añadir Cuadro de texto &amp;Geo-Ref</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="108"/>
        <source>Add a textbox on the map.</source>
        <translation>Añadir caja de texto al mapa.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="109"/>
        <source>Add Distance &amp;Polyline</source>
        <translation>Añadir &amp;Polilínea de Distancia</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="109"/>
        <location filename="../CActions.cpp" line="110"/>
        <source>Add a polyline to measure distances.</source>
        <translation>Añadir polilínea para medir distancias.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="110"/>
        <source>Distance &amp;Polyline</source>
        <translation>&amp;Polilínea de Distancia</translation>
    </message>
    <message>
        <source>&amp;Diary</source>
        <translation type="obsolete">&amp;Diario</translation>
    </message>
    <message>
        <source>Add / edit diary data</source>
        <translation type="obsolete">Añadir / Editar datos del diario</translation>
    </message>
    <message>
        <source>&amp;Pick Color</source>
        <translation type="obsolete">&amp;Seleccionar Color</translation>
    </message>
    <message>
        <source>test only</source>
        <translation type="obsolete">modo de prueba</translation>
    </message>
    <message>
        <source>Create World &amp;Basemap</source>
        <translation type="obsolete">Crear un Mapa &amp;Base Mundial</translation>
    </message>
    <message>
        <source>Create a world basemap from OSM tiles to be used by QLandkarte M</source>
        <translation type="obsolete">Crear un mapa base mundial a partir de las teselas OSM usando QLandkarte M</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="119"/>
        <source>Upload routes to device.</source>
        <translation>Cargar rutas en el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="120"/>
        <source>Download routes from device.</source>
        <translation>Descargar rutas del dispositivo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="123"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="123"/>
        <source>&amp;Zoom in</source>
        <translation>&amp;Acercar</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="123"/>
        <source>Zoom&apos;s into the Map.</source>
        <translation>Acerca el mapa.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="124"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="124"/>
        <source>&amp;Zoom out</source>
        <translation>A&amp;lejar</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="124"/>
        <source>Zoom&apos;s out of the Map.</source>
        <translation>Aleja el Mapa.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="125"/>
        <source>&amp;Move left</source>
        <translation>&amp;Mover a la izquierda</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="125"/>
        <source>Move to the left side.</source>
        <translation>Mover al lado izquierdo.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="126"/>
        <source>&amp;Move right</source>
        <translation>&amp;Mover a la derecha</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="126"/>
        <source>Move to the right side.</source>
        <translation>Mover al lado derecho.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="127"/>
        <source>&amp;Move up</source>
        <translation>&amp;Subir</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="127"/>
        <source>Move up.</source>
        <translation>Subir.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="128"/>
        <source>&amp;Move down</source>
        <translation>&amp;Bajar</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="128"/>
        <source>Move down.</source>
        <translation>Bajar.</translation>
    </message>
    <message>
        <source>ctrl+c</source>
        <translation type="obsolete">ctrl+c</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="129"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>Copy selected trackpoints to clipboard.</source>
        <translation type="obsolete">Copiar los puntos selecionados al portapapeles.</translation>
    </message>
    <message>
        <source>ctrl+v</source>
        <translation type="obsolete">ctrl+v</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="130"/>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Paste Track.</source>
        <translation type="obsolete">Pegar &quot;Track&quot;.</translation>
    </message>
    <message>
        <source>ctrl+z</source>
        <translation type="obsolete">ctrl+z</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="131"/>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="131"/>
        <source>Undo a command.</source>
        <translation>Deshacer un comando.</translation>
    </message>
    <message>
        <source>ctrl+y</source>
        <translation type="obsolete">ctrl+y</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="132"/>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="132"/>
        <source>Redo a command.</source>
        <translation>Rehacer un comando.</translation>
    </message>
    <message>
        <source>Action with the name &apos;%1&apos; already registered. Please choose an other name.</source>
        <translation type="obsolete">La acción de nombre&apos;%1&apos; ya está registrada. Por favor seleccione otro nombre.</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="184"/>
        <source>Action with name &apos;%1&apos; not found. %2</source>
        <translation>La acción de nombre &apos;%1&apos; no se encontró. %2</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="205"/>
        <source>&amp;Main</source>
        <translation>&amp;Menu Principal</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="215"/>
        <location filename="../CActions.cpp" line="234"/>
        <source>&amp;Maps</source>
        <translation>&amp;Mapas</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="244"/>
        <source>&amp;Waypoints</source>
        <translation>&amp;Waypoints</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="254"/>
        <source>&amp;Tracks</source>
        <translation>&amp;Tracks</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="264"/>
        <source>&amp;Routes</source>
        <translation>&amp;Rutas</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="274"/>
        <source>&amp;Live Log</source>
        <translation>&amp;Registro en vivo</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="284"/>
        <source>&amp;Overlay</source>
        <translation>&amp;Superponer</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="294"/>
        <source>&amp;Overlay Distance</source>
        <translation>&amp;Superponer Distancia</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="316"/>
        <source>&amp;Main (More)</source>
        <translation>&amp;Principal (Más)</translation>
    </message>
    <message>
        <location filename="../CActions.cpp" line="430"/>
        <source>Maps ...</source>
        <translation>Mapas...</translation>
    </message>
</context>
<context>
    <name>CCanvas</name>
    <message>
        <source>Click to edit track and to see large profile</source>
        <translation type="obsolete">Pulse para editar el track y ver el perfil grande</translation>
    </message>
    <message>
        <source>Copy Position</source>
        <translation type="obsolete">Copiar Posición</translation>
    </message>
    <message>
        <location filename="../CCanvas.cpp" line="900"/>
        <source>[Grid: %1] </source>
        <translation>[Rejilla: %1] </translation>
    </message>
    <message>
        <location filename="../CCanvas.cpp" line="904"/>
        <source>[Grid: N %1m, E %2m] </source>
        <translation>[Rejilla: N %1m, E %2m] </translation>
    </message>
    <message>
        <source>[Grid: %1m, %2m] </source>
        <translation type="obsolete">[Rejilla: %1m, %2m] </translation>
    </message>
</context>
<context>
    <name>CCopyright</name>
    <message>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br/&gt;Sarah Neumann (German)&lt;br/&gt;Fabrice Crohas (French)&lt;br/&gt;Alessandro Briosi (Italian)&lt;br/&gt;Mike Markov (Russian)&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución en el proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br/&gt;Sarah Neumann (Alemán)&lt;br/&gt;Oscar A. (Español)&lt;br/&gt;Fabrice Crohas (Francés)&lt;br/&gt;Alessandro Briosi (Italiano)&lt;br/&gt;Mike Markov (Ruso)&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la &lt;b&gt;Oxygen&lt;/b&gt; icon&quot; set. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br/&gt;Sarah Neumann (German)&lt;br/&gt;Fabrice Crohas (French)&lt;br/&gt;Alessandro Briosi (Italian)&lt;br/&gt;Mike Markov (Russian)&lt;br/&gt;Oscar A. (Spanish)&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución en el proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br/&gt;Sarah Neumann (Alemán)&lt;br/&gt;Fabrice Crohas (Francés)&lt;br/&gt;Alessandro Briosi (Italiano)&lt;br/&gt;Mike Markov (Ruso)&lt;br/&gt;Oscar A. (Español)&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la &lt;b&gt;Oxygen&lt;/b&gt; icon&quot; set. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br/&gt;Sarah Neumann (German)&lt;br/&gt;Fabrice Crohas (French)&lt;br/&gt;Alessandro Briosi (Italian)&lt;br/&gt;Mike Markov (Russian)&lt;br/&gt;Oscar A. (Spanish)&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Typ file decoding is done with the help of the source code published at http://ati.land.cz/gps/typedit//&lt;p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución en el proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br/&gt;Sarah Neumann (Alemán)&lt;br/&gt;Fabrice Crohas (Francés)&lt;br/&gt;Alessandro Briosi (Italiano)&lt;br/&gt;Mike Markov (Ruso)&lt;br/&gt;Oscar A. (Español)&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la &lt;b&gt;Oxygen&lt;/b&gt; icon&quot; set. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;El descifrado del archivo de Typ se hace con la ayuda del código fuente publicado en http://ati.land.cz/gps/typedit//&lt;p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br/&gt;Sarah Neumann (German)&lt;br/&gt;Fabrice Crohas (French)&lt;br/&gt;Alessandro Briosi (Italian)&lt;br/&gt;Mike Markov (Russian)&lt;br/&gt;Oscar A. (Spanish)&lt;br/&gt;Harrie Klomp (Dutch)&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Typ file decoding is done with the help of the source code published at http://ati.land.cz/gps/typedit//&lt;p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución en el proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br/&gt;Sarah Neumann (Alemán)&lt;br/&gt;Fabrice Crohas (Francés)&lt;br/&gt;Alessandro Briosi (Italiano)&lt;br/&gt;Mike Markov (Ruso)&lt;br/&gt;Oscar A. (Español)&lt;br/&gt;Harrie Klomp (Holandés)&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la de&lt;b&gt;Oxygen&lt;/b&gt;. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; y &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;El descifrado del archivo de Typ se hace con la ayuda del código fuente publicado en http://ati.land.cz/gps/typedit//&lt;p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br&gt;Sarah Neumann (German)&lt;br&gt;Fabrice Crohas (French)&lt;br&gt;Alessandro Briosi (Italian)&lt;br&gt;Mike Markov (Russian)&lt;br&gt;Oscar A. (Spanish)&lt;br&gt;Harrie Klomp (Dutch)&lt;br&gt;&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.Geocache icons are taken from the OpenCacheManager project. See &lt;b&gt;http://opencachemanage.sourceforge.net/&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Typ file decoding is done with the help of the source code published at http://ati.land.cz/gps/typedit//&lt;p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución en el proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br/&gt;Sarah Neumann (Alemán)&lt;br/&gt;Fabrice Crohas (Francés)&lt;br/&gt;Alessandro Briosi (Italiano)&lt;br/&gt;Mike Markov (Ruso)&lt;br/&gt;Oscar A. (Español)&lt;br/&gt;Harrie Klomp (Holandés)&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la de&lt;b&gt;Oxygen&lt;/b&gt;. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; y &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;. Los iconos de geocache se han tomado del proyecto OpenCacheManager. Ver &lt;b&gt;http://opencachemanage.sourceforge.net/&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;El descifrado del archivo de Typ se hace con la ayuda del código fuente publicado en http://ati.land.cz/gps/typedit//&lt;p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br&gt;Sarah Neumann (German)&lt;br&gt;Fabrice Crohas (French)&lt;br&gt;Alessandro Briosi (Italian)&lt;br&gt;Mike Markov (Russian)&lt;br&gt;Oscar A. and Luis Llorente (Spanish)&lt;br&gt;Harrie Klomp (Dutch)&lt;br&gt;&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.Geocache icons are taken from the OpenCacheManager project. See &lt;b&gt;http://opencachemanage.sourceforge.net/&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Typ file decoding is done with the help of the source code published at http://ati.land.cz/gps/typedit//&lt;p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución en el proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br/&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br/&gt;Sarah Neumann (Alemán)&lt;br/&gt;Fabrice Crohas (Francés)&lt;br/&gt;Alessandro Briosi (Italiano)&lt;br/&gt;Mike Markov (Ruso)&lt;br/&gt;Oscar A. y Luis Llorente (Español)&lt;br/&gt;Harrie Klomp (Holandés)&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la de&lt;b&gt;Oxygen&lt;/b&gt;. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; y &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;. Los iconos de geocache se han tomado del proyecto OpenCacheManager. Ver &lt;b&gt;http://opencachemanage.sourceforge.net/&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;El descifrado del archivo de Typ se hace con la ayuda del código fuente publicado en http://ati.land.cz/gps/typedit//&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../CCopyright.cpp" line="40"/>
        <source>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Thanks for contributing to the project:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;Michael Klein&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Translation:&lt;br&gt;Sarah Neumann (German)&lt;br&gt;Fabrice Crohas (French)&lt;br&gt;Alessandro Briosi (Italian)&lt;br&gt;Mike Markov (Russian)&lt;br&gt;Oscar A. and Luis Llorente (Spanish)&lt;br&gt;Harrie Klomp (Dutch)&lt;br&gt;&lt;/p&gt;&lt;p&gt;Icons and eye candy are from the &lt;b&gt;KDE&lt;/b&gt; icon set, the &lt;b&gt;Nuvola&lt;/b&gt; icon set and the &lt;b&gt;Oxygen&lt;/b&gt; icon set.See &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; and &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Waypoint icons are copied from &lt;b&gt;GPSMan&lt;/b&gt;. See &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Cursor icons are from the &apos;Polar Cursor Theme&apos;. See &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;.Geocache icons are taken from the OpenCacheManager project. See &lt;b&gt;http://opencachemanage.sourceforge.net/&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Some of the 2D polygon math is copied from &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. The geodesic distance calculation by Thaddeus Vincenty is copied from &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Typ file decoding is done with the help of the source code published at http://ati.land.cz/gps/typedit//&lt;p&gt;</source>
        <translation>&lt;p&gt;&amp;#169; 2007 Oliver Eichler (oliver.eichler@gmx.de)&lt;/p&gt;&lt;p&gt;Gracias por la contribución al proyecto:&lt;/p&gt;&lt;p&gt;Andrew Vagin&lt;br/&gt;Fabrice Crohas&lt;br/&gt;Marc Feld&lt;br/&gt;Joerg Wunsch&lt;br/&gt;Albrecht Dre&amp;szlig;&lt;br&gt;Christian Ehrlicher&lt;br/&gt;Christian Treffs&lt;br/&gt;Michael Klein&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Traducción:&lt;br&gt;Sarah Neumann (Alemán)&lt;br&gt;Fabrice Crohas (Francés)&lt;br&gt;Alessandro Briosi (Italiano)&lt;br&gt;Mike Markov (Ruso)&lt;br&gt;Oscar A., Luis Llorente y Carlos Dávila (Español)&lt;br&gt;Harrie Klomp (Holandés)&lt;br&gt;&lt;/p&gt;&lt;p&gt;Los iconos y la colección &quot;eye candy&quot; son de la colección de iconos de &lt;b&gt;KDE&lt;/b&gt;, la colección de iconos &lt;b&gt;Nuvola&lt;/b&gt; y la de &lt;b&gt;Oxygen&lt;/b&gt;. Ver &lt;b&gt;http://www.kde.org/&lt;/b&gt;,&lt;b&gt;http://www.icon-king.com/&lt;/b&gt; y &lt;b&gt;http://www.oxygen-icons.org/&lt;/b&gt;. Los iconos de &quot;Waypoint&quot; han sido copiados de &lt;b&gt;GPSMan&lt;/b&gt;. Ver &lt;b&gt;http://www.ncc.up.pt/gpsman/&lt;/b&gt;. Los iconos del cursor son del &apos;Polar Cursor Theme&apos;. Ver &lt;b&gt;http://www.kde-look.org/content/show.php?content=27913&lt;/b&gt;. Los iconos de geocache se han tomado del proyecto OpenCacheManager. Ver &lt;b&gt;http://opencachemanage.sourceforge.net/&lt;/b&gt;.&lt;/p&gt; &lt;p&gt;Algunos de los &quot;2D polygon math&quot; son copias de &lt;b&gt;http://local.wasp.uwa.edu.au/~pbourke/geometry/&lt;/b&gt;. La calculadora de distancias geodésicas de Thaddeus Vincenty se ha copiado de &lt;b&gt;http://www.movable-type.co.uk/scripts/LatLongVincenty.html&lt;/b&gt;&lt;/p&gt;&lt;p&gt;El descifrado del archivo Typ se hace con la ayuda del código fuente publicado en http://ati.land.cz/gps/typedit//&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../CCopyright.cpp" line="90"/>
        <source>running gdal_translate failed!</source>
        <translation>¡la ejecución de gdal_translate falló!</translation>
    </message>
    <message>
        <location filename="../CCopyright.cpp" line="93"/>
        <source>
GDAL Environment
</source>
        <translation>
Entorno GDAL
</translation>
    </message>
</context>
<context>
    <name>CCreateMapFineTune</name>
    <message>
        <location filename="../CCreateMapFineTune.cpp" line="64"/>
        <source>Open map file...</source>
        <translation>Abrir archivo de mapa...</translation>
    </message>
    <message>
        <location filename="../CCreateMapFineTune.cpp" line="64"/>
        <source>Referenced file (*.tif *.tiff *.png *.gif)</source>
        <translation>Archivo georreferenciado (*.tif *.tiff *.png *.gif)</translation>
    </message>
</context>
<context>
    <name>CCreateMapGeoTiff</name>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="56"/>
        <source>Load Raster Map</source>
        <translation>Cargar Mapa Raster</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="57"/>
        <source>This dialog allows you to georeference raster map files. As pre-requisite you need a set of reference points and the projection for those points. You will get best results if the projection of the points is also the projection of the map. In most cases this is mercator. It is recommended to shift the reference point to WGS84 datum, right from the beginning.</source>
        <translation>Este diálogo le permite georreferenciar mapas raster. Como requisito previo usted necesita un sistema de puntos de referencia y la proyección para esos puntos. Conseguirá los mejores resultados si la proyección de los puntos es la misma que la del mapa. En la mayoría de los casos ésta es Mercator. Se recomienda convertir los puntos de referencia a datum WGS84 desde el principio.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="58"/>
        <source>Add Reference Points</source>
        <translation>Añadir Puntos de Referencia</translation>
    </message>
    <message utf8="true">
        <source>The next stage is to add known reference points. Simply add reference points to the map and enter their latitude / longitude (WGS84) or the easting and northing [m] in the table. Next you move the point to the correct location on the map.

coordinate formats:
â¢ &quot;N49Â° 10.234 E12Â° 01.456&quot;
â¢ &quot;12.193172   46.575377&quot;
â¢ &quot;285000 5162000&quot;</source>
        <translation type="obsolete">El siguiente paso consiste en añadir puntos de referencia conocidos. Simplemente añada los puntos de referencia al mapa y escriba su latitud/longitud (WGS84) o este y norte [m] en la tabla. Después mueva el punto a la localización correcta en el mapa.

formato de las coordenadas:
&quot;N49° 10.234 E12° 01.456&quot;
&quot;12.193172   46.575377&quot;
&quot;285000 5162000&quot;</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="60"/>
        <source>Reference Map</source>
        <translation>Mapa de referencia</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="61"/>
        <source>Now QLandkarte GT will reference your file with the help of the GDAL tools. Watch the progress in the output browser.</source>
        <translation>Ahora QLandKarte GT creará referencias para su archivo con la ayuda de las herraminentas GDAL. Vea el progreso en el navegador.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="92"/>
        <source>square pixels (2 Ref. Pts.)</source>
        <translation>píxeles cuadrados (2 puntos de referencia)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="93"/>
        <source>linear (3 Ref. Pts.)</source>
        <translation>lineal (3 puntos de referencia)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="94"/>
        <source>quadratic (6 Ref. Pts.)</source>
        <translation>cuadrático (6 puntos de referencia)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="95"/>
        <source>thin plate (4 Ref. Pts.)</source>
        <translation>thin plate (4 puntos de referencia)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="246"/>
        <source>Open map file...</source>
        <translation>Abrir archivo de mapa...</translation>
    </message>
    <message>
        <source>Raw bitmaps (*.tif *.png *.gif)</source>
        <translation type="obsolete">Mapa de bits en bruto (*.tif *.png *.gif)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="291"/>
        <source>Save result as...</source>
        <translation>Guardar el resultado como...</translation>
    </message>
    <message>
        <source>GeoTiff (*.tif)</source>
        <translation type="obsolete">GeoTiff (*.tif)</translation>
    </message>
    <message utf8="true">
        <source>The next stage is to add known reference points. Simply add reference points to the map and enter their latitude / longitude (WGS84) or the easting and northing [m] in the table. Next you move the point to the correct location on the map.

coordinate formats:
â¢ &quot;N49Â° 10.234 E12Â° 01.456&quot;
â¢ &quot;46.575377   12.193172&quot;
â¢ &quot;285000 5162000&quot;</source>
        <translation type="obsolete">El siguiente paso es añadir puntos de referencia conocidos. Simplemente añada los puntos al mapa e introduzca su latitud / longitud (WGS84) o este y norte [m] en la tabla. A continuación mueva el punto a la posición correcta en el mapa.

formatos de coordenadas:
â¢ &quot;N49Â° 10.234 E12Â° 01.456&quot;
â¢ &quot;46.575377   12.193172&quot;
â¢ &quot;285000 5162000&quot;</translation>
    </message>
    <message utf8="true">
        <source>The next stage is to add known reference points. Simply add reference points to the map and enter their latitude / longitude (WGS84) or the easting and northing [m] in the table. Next you move the point to the correct location on the map.

coordinate formats:
• &quot;N49° 10.234 E12° 01.456&quot;
• &quot;46.575377   12.193172&quot;
• &quot;285000 5162000&quot;</source>
        <translation type="obsolete">El siguiente paso es añadir puntos de referencia conocidos. Simplemente añada los puntos al mapa e introduzca su latitud / longitud (WGS84) o este y norte [m] en la tabla. A continuación mueva el punto a la posición correcta en el mapa.

formatos de coordenadas:
• &quot;N49° 10.234 E12° 01.456&quot;
• &quot;46.575377   12.193172&quot;
• &quot;285000 5162000&quot;</translation>
    </message>
    <message utf8="true">
        <location filename="../CCreateMapGeoTiff.cpp" line="59"/>
        <source>The next stage is to add known reference points. Simply add reference points to the map and enter their latitude / longitude (WGS84) or the easting and northing [m] in the table. Next you move the point to the correct location on the map.

coordinate formats:
• &quot;N49° 10.234 E12° 01.456&quot; (dd mm.mmm)
• &quot;46.575377   12.193172&quot;  (dd.dddddd)
• &quot;285000 5162000&quot;</source>
        <translation>El siguiente paso es añadir puntos de referencia conocidos. Simplemente añada puntos de referencia al mapa e introduzca su latitud / longitud (WGS84) o su referencia este y norte [m] en la tabla. A continuación mueva el punto a la ubicación correcta en el mapa.

formatos de coordenadas:
• &quot;N49° 10.234 E12° 01.456&quot; (dd mm.mmm)
• &quot;46.575377   12.193172&quot;  (dd.dddddd)
• &quot;285000 5162000&quot;</translation>
    </message>
    <message>
        <source>Raw bitmaps (*.tif *.tiff *.png *.gif)</source>
        <translation type="obsolete">Mapas de bit en bruto (*.tif *.tiff *.png *.gif)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="246"/>
        <source>Raw bitmaps (*.tif *.tiff *.png *.gif *.jpg)</source>
        <translation>Mapas de bit en bruto (*.tif *.tiff *.png *.gif *.jpg)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="291"/>
        <source>GeoTiff (*.tif *.tiff)</source>
        <translation>GeoTiff (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="349"/>
        <location filename="../CCreateMapGeoTiff.cpp" line="381"/>
        <location filename="../CCreateMapGeoTiff.cpp" line="492"/>
        <location filename="../CCreateMapGeoTiff.cpp" line="532"/>
        <location filename="../CCreateMapGeoTiff.cpp" line="604"/>
        <source>Ref %1</source>
        <translation>Ref %1</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="350"/>
        <source>&lt;enter coord&gt;</source>
        <translation>&lt;introduzca las coordenadas&gt;</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="438"/>
        <source>Load reference points...</source>
        <translation>Cargar puntos de referencia...</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="630"/>
        <source>Save reference points...</source>
        <translation>Guardar los puntos de referencia...</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="701"/>
        <source>Sorry...</source>
        <translation>Lo siento...</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="701"/>
        <source>No Mapinfo TAB file support yet.</source>
        <translation>Aún no hay soporte para archivos Mapinfo TAB.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="709"/>
        <source>Grid Tool</source>
        <translation>Herramienta de Rejilla</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="823"/>
        <source>Error ...</source>
        <translation>Error ...</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="823"/>
        <source>Reference points are too close.</source>
        <translation>Los puntos de referencia están demasiado cerca.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="882"/>
        <source>Failed!
</source>
        <translation>¡Falló!</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="994"/>
        <source>--- finished ---
</source>
        <translation>--- finalizado ---
</translation>
    </message>
    <message>
        <location filename="../CCreateMapGeoTiff.cpp" line="286"/>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CCreateMapGridTool</name>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="44"/>
        <source>Place Reference Points</source>
        <translation>Coloque los puntos de referencia</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="45"/>
        <source>The grid tool will place reference points with calculated longitude and latitude to the line crossings of a linear map grid. To do so you have to place the 4 initial reference points to the grid as shown in the example.

Altenatively you might have chosen to use already existing reference points. In this case you simply have to define the grid step size.</source>
        <translation>La herramienta de rejilla situará los puntos de referencia con longitud y latitud calculadas sobre intersecciones de la rejilla. Para ello, debe colocar los 4 primeros puntos de referencia sobre la rejilla como muestra el ejemplo..

Como alternativa puede utilizar puntos de referencia ya existentes. En ese caso, le bastará con definir el tamaño de los cuadros de la rejilla.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="46"/>
        <source>Add Source projection</source>
        <translation>Añadir proyección origen</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="47"/>
        <source>Next you might want to add a source projection to do a grid shift to WGS84. And you have to define the longitude and the latitude of the top left reference point. And the spacing between point 1 and 2, and 1 and 4.</source>
        <translation>A continuación, quizá quiera añadir una proyección origen para transformar la rejilla en WGS84. Y debe definir la longitud y la latitud del punto de referencia superior izquierdo. Y la separación entre los puntos 1 y 2, y 1 y 4.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="48"/>
        <source>Create grid</source>
        <translation>Crear rejilla</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="49"/>
        <source>On ok, the grid tool will add equally spaced reference points over your map. Keep in mind to manually fine tune the location of each point to get good results.</source>
        <translation>Al validar, la herramienta de rejilla agregará puntos de referencia equidistantes sobre su mapa. Tenga en cuenta que es necesario ajustar manualmente para obtener buenos resultados.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="75"/>
        <source>Reference points found.</source>
        <translation>Encontrados puntos de referencia.</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="75"/>
        <source>Do you want to take the existing reference points to calculate additional points on the grid?</source>
        <translation>¿Desea usar los puntos de referencia existentes para calcular puntos adicionales en la rejilla?</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="132"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="304"/>
        <location filename="../CCreateMapGridTool.cpp" line="316"/>
        <source>Error ...</source>
        <translation>Error ...</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="304"/>
        <source>Failed to calculate transformation for ref. points. Are all 4 points placed propperly?</source>
        <translation>Falló el cálculo de la transformación para los puntos de referencia. ¿Están los 4 puntos colocados adecuadamente?</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="316"/>
        <source>Failed to setup projection. Bad syntax?</source>
        <translation>Falló la configuración de la proyección. ¿Sintaxis incorrecta?</translation>
    </message>
    <message>
        <location filename="../CCreateMapGridTool.cpp" line="113"/>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CCreateMapOSM</name>
    <message>
        <source>Information missing ...</source>
        <translation type="obsolete">Falta información ...</translation>
    </message>
    <message>
        <source>The top left coordinate is missing</source>
        <translation type="obsolete">Faltan las coordenadas superior izquierda</translation>
    </message>
    <message>
        <source>The bottom right coordinate is missing</source>
        <translation type="obsolete">Faltan las coordenadas inferior derecha</translation>
    </message>
    <message>
        <source>The map name is missing.</source>
        <translation type="obsolete">Falta el nombre del mapa.</translation>
    </message>
    <message>
        <source>The comment is missing.</source>
        <translation type="obsolete">Falta el comentario.</translation>
    </message>
    <message>
        <source>Download files ...</source>
        <translation type="obsolete">Descargar archivos ...</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation type="obsolete">Abortar</translation>
    </message>
    <message>
        <source>Calculating tiles ...</source>
        <translation type="obsolete">Calculando teselas ...</translation>
    </message>
    <message>
        <source>download: </source>
        <translation type="obsolete">descargar: </translation>
    </message>
    <message>
        <source>tile %1 of %2</source>
        <translation type="obsolete">tesela %1 de %2</translation>
    </message>
    <message>
        <source>Failed to download tile!</source>
        <translation type="obsolete">¡No se pudo descargar la tesela!</translation>
    </message>
    <message>
        <source>Select output path ...</source>
        <translation type="obsolete">Seleccionar el directorio de salida ...</translation>
    </message>
</context>
<context>
    <name>CCreateMapQMAP</name>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="43"/>
        <source>Define Map</source>
        <translation>Definir Mapa</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="44"/>
        <source>You can edit or create QLandkarte GT map definition files (*.qmap). A map definition defines what files to show at a certain zoom level. The comment will be used to list the map collection as known map in the map tool view. You can choose between a linear or quadratic zoom level increment.
Once you created a map set you can attach DEM data to it via the context menu in the lefthand map tool view.</source>
        <translation>Puede modificar o crear ficheros QLandkarte GT de definición del mapas (*.qmap). Un fichero de definición de mapas determina los ficheros que deben mostrarse en los distintos niveles de zoom. El comentario se utilizará para identificar el conjunto de mapas en la herramienta de mapas. Puede elegir entre incrementos de zoom lineales o exponenciales.
Una vez haya creado un conjunto de mapas, podrá asociar datos DEM mediante el menú contextual en la parte izquierda de la herramienta de mapas.</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="45"/>
        <source>Add Maps</source>
        <translation>Añadir Mapas</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="46"/>
        <source>You can stack maps of different detail as layer. For each detail layer you can define the number of zoom levels. Several map files can be grouped into a detail layer. All map files in a layer must have the same projection and scale. You need at least one layer with one file.</source>
        <translation>Puede apilar mapas con distinto detalle como capas. Para cada capa de detalle puede definir el número de niveles de zoom. Se pueden agrupar varios mapas en una capa de detalle. Todos los mapas en una misma capa deben tener la misma proyección y escala. Necesitará al menos una capa con un archivo.</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="74"/>
        <source>Select map definition file...</source>
        <translation>Seleccione el archivo de definición de mapas...</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="88"/>
        <location filename="../CCreateMapQMAP.cpp" line="112"/>
        <source>Define a map collection file...</source>
        <translation>Definir un archivo de conjunto de mapas...</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="150"/>
        <location filename="../CCreateMapQMAP.cpp" line="157"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="150"/>
        <source>Failed to load file %1.</source>
        <translation>Falló la carga del archivo %1.</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="157"/>
        <source>All maps in a level must have the same projection.</source>
        <translation>Todos los mapas en un mismo nivel deben de tener la misma proyección.</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="216"/>
        <source>Top/left corner:	%1
</source>
        <translation>Esquina superior/izquierda:	%1
</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="218"/>
        <source>Bottom/right corner:	%1
</source>
        <translation>Esquina inferior/derecha: 	%1
</translation>
    </message>
    <message>
        <location filename="../CCreateMapQMAP.cpp" line="232"/>
        <source>Width x Height [m] x [m]:	 %1 x %2</source>
        <translation>Ancho x Alto [m] x [m]:	 %1 x %2</translation>
    </message>
</context>
<context>
    <name>CCreateMapWMS</name>
    <message>
        <source>Error...</source>
        <translation type="obsolete">Error...</translation>
    </message>
    <message>
        <source>Failed to query capabilities.

%1

</source>
        <translation type="obsolete">Falló la consulta de capacidades.

%1

</translation>
    </message>
    <message>
        <source>Failed to parse capabilities.

%1

%2</source>
        <translation type="obsolete">Falló el procesado de las capacidades.

%1

%2</translation>
    </message>
    <message>
        <source>Failed to check WMS version.

Expected %1, received %2.</source>
        <translation type="obsolete">Falló la comprobación de versión del WMS.

Se esperaba %1, se recibió %2.</translation>
    </message>
    <message>
        <source>You need to select at least one layer.</source>
        <translation type="obsolete">Debe seleccionar al menos una capa.</translation>
    </message>
    <message>
        <source>Define GDAL WMS definition file...</source>
        <translation type="obsolete">Crear fichero de definición para GDAL-WMS...</translation>
    </message>
</context>
<context>
    <name>CDeviceGPSD</name>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="107"/>
        <location filename="../CDeviceGPSD.cpp" line="113"/>
        <location filename="../CDeviceGPSD.cpp" line="119"/>
        <location filename="../CDeviceGPSD.cpp" line="125"/>
        <location filename="../CDeviceGPSD.cpp" line="131"/>
        <location filename="../CDeviceGPSD.cpp" line="137"/>
        <location filename="../CDeviceGPSD.cpp" line="143"/>
        <location filename="../CDeviceGPSD.cpp" line="149"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="107"/>
        <source>GPSD: Upload waypoints is not implemented.</source>
        <translation>GPSD: La carga de waypoints no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="113"/>
        <source>GPSD: Download waypoints is not implemented.</source>
        <translation>GPSD: La descarga de waypoints no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="119"/>
        <source>GPSD: Upload tracks is not implemented.</source>
        <translation>GPSD: La carga de tracks no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="125"/>
        <source>GPSD: Download tracks is not implemented.</source>
        <translation>GPSD: La descarga de tracks no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="131"/>
        <source>GPSD: Upload routes is not implemented.</source>
        <translation>GPSD: La carga de rutas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="137"/>
        <source>GPSD: Download routes is not implemented.</source>
        <translation>GPSD: La descarga de rutas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="143"/>
        <source>GPSD: Upload maps is not implemented.</source>
        <translation>GPSD: La carga de mapas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGPSD.cpp" line="149"/>
        <source>GPSD: Download screenshots is not implemented.</source>
        <translation>GPSD: La descarga de capturas de pantalla no está implementada.</translation>
    </message>
</context>
<context>
    <name>CDeviceGarmin</name>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="542"/>
        <location filename="../CDeviceGarmin.cpp" line="555"/>
        <source>Error ...</source>
        <translation>Error ...</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="543"/>
        <source>Failed to load driver.</source>
        <translation>Falló la carga del controlador.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="556"/>
        <source>Driver version mismatch.</source>
        <translation>Discrepancia en la versión del controlador.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="558"/>
        <source>The version of your driver plugin &quot;%1&quot; does not match the version QLandkarteGT expects (&quot;%2&quot;).</source>
        <translation>La versión de su controlador &quot;%1&quot; no coincide con la versión que QLandkarteGT espera (&quot;%2&quot;).</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="598"/>
        <location filename="../CDeviceGarmin.cpp" line="711"/>
        <location filename="../CDeviceGarmin.cpp" line="741"/>
        <location filename="../CDeviceGarmin.cpp" line="832"/>
        <location filename="../CDeviceGarmin.cpp" line="861"/>
        <location filename="../CDeviceGarmin.cpp" line="932"/>
        <location filename="../CDeviceGarmin.cpp" line="1033"/>
        <location filename="../CDeviceGarmin.cpp" line="1062"/>
        <location filename="../CDeviceGarmin.cpp" line="1154"/>
        <location filename="../CDeviceGarmin.cpp" line="1180"/>
        <source>Device Link Error</source>
        <translation>Error al enlazar con el dispositivo</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="716"/>
        <source>Upload waypoints finished!</source>
        <translation>¡La carga de waypoints terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="775"/>
        <source>Download waypoints finished!</source>
        <translation>¡La descarga de waypoints terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="837"/>
        <source>Upload tracks finished!</source>
        <translation>¡La carga de tracks terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="903"/>
        <source>Download tracks finished!</source>
        <translation>¡La descarga de tracks terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="1038"/>
        <source>Upload routes finished!</source>
        <translation>¡La carga de rutas terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="1095"/>
        <source>Download routes finished!</source>
        <translation>¡La descarga de rutas terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="1124"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="1124"/>
        <source>Failed to create image file.</source>
        <translation>Fallo al crear el archivo de imagen.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="1159"/>
        <source>Upload maps finished!</source>
        <translation>¡La carga de mapas terminó!</translation>
    </message>
    <message>
        <source>Garmin: Download routes is not implemented.</source>
        <translation type="obsolete">Garmin : Descarga de archivos no implementada.</translation>
    </message>
</context>
<context>
    <name>CDeviceGarminBulk</name>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="165"/>
        <location filename="../CDeviceGarminBulk.cpp" line="178"/>
        <location filename="../CDeviceGarminBulk.cpp" line="192"/>
        <source>Missing...</source>
        <translation>No se encuentra...</translation>
    </message>
    <message>
        <source>The selected path must have a subdirectory &apos;GPX&apos;.</source>
        <translation type="obsolete">La ruta seleccionada debe tener un subdirectorio &apos;GPX&apos;.</translation>
    </message>
    <message>
        <source>The selected path must have a subdirectory &apos;JPEG&apos; or &apos;Pictures&apos;.</source>
        <translation type="obsolete">La ruta seleccionada debe tener un subdirectorio &apos;JPEG&apos; o &apos;Pictures&apos;.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="142"/>
        <source>Path to Garmin device...</source>
        <translation>Ruta al dispositivo Garmin...</translation>
    </message>
    <message>
        <source>The selected path must have a subdirectory &apos;%1&apos;.</source>
        <translation type="obsolete">La ruta seleccionada debe tener un subdirectorio &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="165"/>
        <location filename="../CDeviceGarminBulk.cpp" line="178"/>
        <source>The selected path must have a subdirectory &apos;%1&apos;. Should I create the path?

%2</source>
        <translation>La ruta seleccionada debe tener un subdirectorio &apos;%1&apos;. ¿Debería crear la ruta?

%2</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="192"/>
        <source>The selected path must have a subdirectory &apos;%1. Should I create the path?

%2</source>
        <translation>La ruta seleccionada debe tener un subdirectorio &apos;%1&apos;. ¿Debería crear la ruta?

%2</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="239"/>
        <source>waypoints</source>
        <translation>waypoints</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="307"/>
        <location filename="../CDeviceGarminBulk.cpp" line="344"/>
        <location filename="../CDeviceGarminBulk.cpp" line="446"/>
        <location filename="../CDeviceGarminBulk.cpp" line="481"/>
        <location filename="../CDeviceGarminBulk.cpp" line="522"/>
        <location filename="../CDeviceGarminBulk.cpp" line="558"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="311"/>
        <source>Upload waypoints finished!</source>
        <translation>¡La carga de waypoints terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="415"/>
        <source>Download waypoints finished!</source>
        <translation>¡La descarga de waypoints terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="428"/>
        <source>tracks</source>
        <translation>tracks</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="449"/>
        <source>Upload tracks finished!</source>
        <translation>¡La carga de tracks terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="492"/>
        <source>Download tracks finished!</source>
        <translation>¡La descarga de tracks terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="504"/>
        <source>routes</source>
        <translation>rutas</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="525"/>
        <source>Upload routes finished!</source>
        <translation>¡La carga de rutas terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="569"/>
        <source>Download routes finished!</source>
        <translation>¡La descarga de rutas terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="575"/>
        <location filename="../CDeviceGarminBulk.cpp" line="581"/>
        <location filename="../CDeviceGarminBulk.cpp" line="587"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="575"/>
        <source>Garmin Mass Storage: Upload maps is not implemented.</source>
        <translation>Almacenamiento Masivo de Garmin: La carga de mapas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="581"/>
        <source>Garmin Mass Storage: Download screenshots is not implemented.</source>
        <translation>Almacenamiento Masivo de Garmin: La descarga de capturas de pantalla no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceGarminBulk.cpp" line="587"/>
        <source>Garmin Mass Storage: Live log is not implemented.</source>
        <translation>Almacenamiento Masivo de Garmin: El registro en vivo no está implementado.</translation>
    </message>
</context>
<context>
    <name>CDeviceMagellan</name>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="73"/>
        <source>Path to Magellan device...</source>
        <translation>Ruta al dispositivo Magellan...</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="82"/>
        <location filename="../CDeviceMagellan.cpp" line="286"/>
        <location filename="../CDeviceMagellan.cpp" line="292"/>
        <location filename="../CDeviceMagellan.cpp" line="298"/>
        <location filename="../CDeviceMagellan.cpp" line="304"/>
        <location filename="../CDeviceMagellan.cpp" line="310"/>
        <source>Error...</source>
        <translatorcomment>Error...</translatorcomment>
        <translation>Error...</translation>
    </message>
    <message>
        <source>I need a path with &apos;TwoNavData/Data&apos; as subdirectory</source>
        <translation type="obsolete">Se necesita una ruta con &apos;TwoNavData/Data&apos; como subdirectorio</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="82"/>
        <source>I need a path with &apos;Track&apos;, &apos;Waypoints&apos;, &apos;Routes&apos; and &apos;Geocaches&apos; as subdirectory</source>
        <translation>Se necesita una ruta con &apos;Track&apos;, &apos;Waypoints&apos;, &apos;Routes&apos; y &apos;Geocaches&apos; como subdirectorio</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="113"/>
        <source>waypoints</source>
        <translatorcomment>waypoints</translatorcomment>
        <translation>waypoints</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="139"/>
        <location filename="../CDeviceMagellan.cpp" line="154"/>
        <location filename="../CDeviceMagellan.cpp" line="185"/>
        <location filename="../CDeviceMagellan.cpp" line="203"/>
        <location filename="../CDeviceMagellan.cpp" line="243"/>
        <location filename="../CDeviceMagellan.cpp" line="274"/>
        <source>Error</source>
        <translatorcomment>Error</translatorcomment>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="157"/>
        <source>Upload waypoints finished!</source>
        <translation>¡Terminó la carga de los waypoints!</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="209"/>
        <source>Download waypoints finished!</source>
        <translation>¡Terminó la descarga de los waypoints!</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="225"/>
        <source>tracks</source>
        <translation>tracks</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="248"/>
        <source>Upload tracks finished!</source>
        <translation>¡Terminó la carga de los tracks!</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="280"/>
        <source>Download tracks finished!</source>
        <translation>¡Terminó la descarga de los tracks!</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="286"/>
        <source>Magellan: Upload routes is not implemented.</source>
        <translation>Magellan: la carga de rutas aún no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="292"/>
        <source>Magellan: Download routes is not implemented.</source>
        <translation>Magellan: la descarga de rutas aún no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="298"/>
        <source>Magellan: Upload maps is not implemented.</source>
        <translation>Magellan: La carga de mapas aún no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="304"/>
        <source>Magellan: Live log is not supported.</source>
        <translation>Magellan: El registro en vivo aún no está soportado.</translation>
    </message>
    <message>
        <location filename="../CDeviceMagellan.cpp" line="310"/>
        <source>Magellan: Screen shot is not supported.</source>
        <translation>Magellan: La captura de pantallas aún no está soportada.</translation>
    </message>
</context>
<context>
    <name>CDeviceMikrokopter</name>
    <message>
        <source>Error...</source>
        <translation type="obsolete">Error...</translation>
    </message>
    <message>
        <source>Mikrokopter: Failed to open serial port.</source>
        <translation type="obsolete">Mikrokopter: Fallo al abrir el puerto serie.</translation>
    </message>
    <message>
        <source>Mikrokopter: Upload waypoints is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La carga de waypoints no está implementada.</translation>
    </message>
    <message>
        <source>Mikrokopter: Upload tracks is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La carga de tracks no está implementada.</translation>
    </message>
    <message>
        <source>Mikrokopter: Download tracks is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La descarga tracks no está implementada.</translation>
    </message>
    <message>
        <source>Mikrokopter: Upload routes is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La carga de rutas no está implementada.</translation>
    </message>
    <message>
        <source>Mikrokopter: Download routes is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La descarga de rutas no está implementada.</translation>
    </message>
    <message>
        <source>Mikrokopter: Upload maps is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La carga de mapas no está implementada.</translation>
    </message>
    <message>
        <source>Mikrokopter: Download screenschots is not implemented.</source>
        <translation type="obsolete">Mikrokopter: La descarga de capturas de pantalla no está implementada.</translation>
    </message>
</context>
<context>
    <name>CDeviceNMEA</name>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="494"/>
        <location filename="../CDeviceNMEA.cpp" line="499"/>
        <location filename="../CDeviceNMEA.cpp" line="504"/>
        <location filename="../CDeviceNMEA.cpp" line="509"/>
        <location filename="../CDeviceNMEA.cpp" line="514"/>
        <location filename="../CDeviceNMEA.cpp" line="519"/>
        <location filename="../CDeviceNMEA.cpp" line="524"/>
        <location filename="../CDeviceNMEA.cpp" line="529"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="494"/>
        <source>NMEA: Upload waypoints is not implemented.</source>
        <translation>NMEA: La carga de waypoints no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="499"/>
        <source>NMEA: Download waypoints is not implemented.</source>
        <translation>NMEA: La descarga de waypoints no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="504"/>
        <source>NMEA: Upload tracks is not implemented.</source>
        <translation>NMEA: La carga de tracks no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="509"/>
        <source>NMEA: Download tracks is not implemented.</source>
        <translation>NMEA: La descarga de tracks no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="514"/>
        <source>NMEA: Upload routes is not implemented.</source>
        <translation>NMEA: La carga de rutas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="519"/>
        <source>NMEA: Download routes is not implemented.</source>
        <translation>NMEA: La descarga de rutas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="524"/>
        <source>NMEA: Upload maps is not implemented.</source>
        <translation>NMEA: La carga de mapas no está implemetada.</translation>
    </message>
    <message>
        <location filename="../CDeviceNMEA.cpp" line="529"/>
        <source>NMEA: Download screenshots is not implemented.</source>
        <translation>NMEA: La descarga de capturas de pantalla no está implementada.</translation>
    </message>
    <message>
        <source>NMEA: Download screenschots is not implemented.</source>
        <translation type="obsolete">NMEA: Descarga de capturas de pantalla no implementada.</translation>
    </message>
</context>
<context>
    <name>CDeviceQLandkarteM</name>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="157"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="163"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="187"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="193"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="221"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="227"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="261"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="267"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="303"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="309"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="334"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="340"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="368"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="374"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="395"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="402"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="409"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="444"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="495"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <source>QLandkarteM: Download waypoints is not implemented.</source>
        <translation type="obsolete">QLandkarteM: Descarga de &quot;waypoints&quot; no implementada.</translation>
    </message>
    <message>
        <source>QLandkarteM: Upload tracks is not implemented.</source>
        <translation type="obsolete">QLandkarteM: Subida de &quot;tracks&quot; no implementada.</translation>
    </message>
    <message>
        <source>QLandkarteM: Download tracks is not implemented.</source>
        <translation type="obsolete">QLandkarteM: Descarga de &quot;tracks&quot; no implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="395"/>
        <source>QLandkarteM: Upload map is not implemented.</source>
        <translation>QLandkarteM: La carga de mapas no está implemetada.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="402"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="409"/>
        <source>QLandkarteM: Download routes is not implemented.</source>
        <translation>QLandkarteM: La descarga de rutas no esta implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="53"/>
        <source>Connect to device.</source>
        <translation>Conectar al dispositivo.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="495"/>
        <source>QLandkarteM: Failed to connect to device.</source>
        <translation>QLandkarteM: Fallo al conectar con el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="138"/>
        <source>Upload waypoints ...</source>
        <translation>Cargar waypoints ...</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="149"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="295"/>
        <source>%1
%2 of %3</source>
        <translation>%1
%2 de %3</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="157"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="221"/>
        <source>QLandkarteM: Failed to transfer waypoints.</source>
        <translation>QLandkarteM: Fallo al transferir waypoints.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="251"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="253"/>
        <source>Download screenshot ...</source>
        <translation>Descargar captura de pantalla ...</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="261"/>
        <source>QLandkarteM: Failed to download screenshot from device.</source>
        <translation>QLandkarteM: Fallo al descargar capturas desde el dispositivo.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="284"/>
        <source>Uplaod tracks ...</source>
        <translation>Cargar tracks ...</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="303"/>
        <location filename="../CDeviceQLandkarteM.cpp" line="368"/>
        <source>QLandkarteM: Failed to transfer tracks.</source>
        <translation>QLandkarteM: Fallo al transferir tracks.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="324"/>
        <source>Download tracks ...</source>
        <translation>Descargar tracks ...</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="326"/>
        <source>Query list of tracks from the device</source>
        <translation>Recuperar lista de tracks desde el dispositivo</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="334"/>
        <source>QLandkarteM: Failed to query tracks from device.</source>
        <translation>QLandkarteM: Fallo al recuperar tracks del dispositivo.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="361"/>
        <source>Download track: %1</source>
        <translation>Descargar track: %1</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="444"/>
        <source>QLandkarteM: No device found. Is it connected to the network?</source>
        <translation>QLandkarteM: Dispositivo no encontrado. ¿Está conectado a la red?</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="177"/>
        <source>Download waypoints ...</source>
        <translation>Descargar waypoints ...</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="179"/>
        <source>Query list of waypoints from the device</source>
        <translation>Recuperar lista de waypoints desde el dispositivo</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="187"/>
        <source>QLandkarteM: Failed to query waypoints from device.</source>
        <translation>QLandkarteM: Fallo al recuperar waypoints del dispositivo.</translation>
    </message>
    <message>
        <location filename="../CDeviceQLandkarteM.cpp" line="214"/>
        <source>Download waypoint: %1</source>
        <translation>Descargar waypoint: %1</translation>
    </message>
</context>
<context>
    <name>CDeviceTBDOE</name>
    <message>
        <source>%1
%2 of %3</source>
        <translation type="obsolete">%1
%2 de %3</translation>
    </message>
</context>
<context>
    <name>CDeviceTwoNav</name>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="149"/>
        <location filename="../CDeviceTwoNav.cpp" line="440"/>
        <location filename="../CDeviceTwoNav.cpp" line="446"/>
        <location filename="../CDeviceTwoNav.cpp" line="452"/>
        <location filename="../CDeviceTwoNav.cpp" line="458"/>
        <location filename="../CDeviceTwoNav.cpp" line="659"/>
        <location filename="../CDeviceTwoNav.cpp" line="669"/>
        <location filename="../CDeviceTwoNav.cpp" line="1013"/>
        <location filename="../CDeviceTwoNav.cpp" line="1023"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <source>TwoNav: Upload wapoints is not implemented.</source>
        <translation type="obsolete">TwoNav: la subida de waypoint no está implementada.</translation>
    </message>
    <message>
        <source>TwoNav: Download wapoints is not implemented.</source>
        <translation type="obsolete">TwoNav: la descarga de waypoints no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="140"/>
        <source>Path to TwoNav device...</source>
        <translation>Ruta al dispositivo TwoNav...</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="149"/>
        <source>I need a path with &apos;TwoNavData/Data&apos; as subdirectory</source>
        <translation>Se necesita una ruta con &apos;TwoNavData/Data&apos; como subdirectorio</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="193"/>
        <source>waypoints</source>
        <translation>waypoints</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="315"/>
        <source>Upload waypoints finished!</source>
        <translation>¡La carga de waypoints terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="357"/>
        <source>Download waypoints finished!</source>
        <translation>¡La descarga de waypoints terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="371"/>
        <source>tracks</source>
        <translation>tracks</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="393"/>
        <source>Upload tracks finished!</source>
        <translation>¡La carga de tracks terminó!</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="434"/>
        <source>Download tracks finished!</source>
        <translation>¡La descarga de tracks terminó!</translation>
    </message>
    <message>
        <source>TwoNav: Upload tracks is not implemented.</source>
        <translation type="obsolete">TwoNav: la subida de tracks no está implementada.</translation>
    </message>
    <message>
        <source>TwoNav: Download tracks is not implemented.</source>
        <translation type="obsolete">TwoNav: la descarga de tracks no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="440"/>
        <source>TwoNav: Upload routes is not implemented.</source>
        <translation>TwoNav: la subida de rutas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="446"/>
        <source>TwoNav: Download routes is not implemented.</source>
        <translation>TwoNav: la descarga de rutas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="452"/>
        <source>TwoNav: Upload maps is not implemented.</source>
        <translation>TwoNav: la subida de mapas no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="458"/>
        <source>TwoNav: Download screenshots is not implemented.</source>
        <translation>TwoNav: la descarga de capturas de pantalla no está implementada.</translation>
    </message>
    <message>
        <location filename="../CDeviceTwoNav.cpp" line="659"/>
        <location filename="../CDeviceTwoNav.cpp" line="669"/>
        <location filename="../CDeviceTwoNav.cpp" line="1013"/>
        <location filename="../CDeviceTwoNav.cpp" line="1023"/>
        <source>Only support lon/lat WGS 84 format.</source>
        <translation>Sólo se soporta el formato lon/lat WGS 84.</translation>
    </message>
</context>
<context>
    <name>CDiary</name>
    <message>
        <location filename="../CDiary.cpp" line="366"/>
        <source>Diary</source>
        <translation>Diario</translation>
    </message>
</context>
<context>
    <name>CDiaryDB</name>
    <message>
        <source>Diary</source>
        <translation type="obsolete">Diario</translation>
    </message>
</context>
<context>
    <name>CDiaryEdit</name>
    <message>
        <location filename="../CDiaryEdit.cpp" line="77"/>
        <source>&amp;Bold</source>
        <translation>&amp;Negrita</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="86"/>
        <source>&amp;Italic</source>
        <translation>&amp;Cursiva</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="95"/>
        <source>&amp;Underline</source>
        <translation>&amp;Subrayado</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="106"/>
        <source>&amp;Color...</source>
        <translation>&amp;Color...</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="120"/>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="124"/>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="128"/>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="132"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="136"/>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="225"/>
        <source>Diary modified...</source>
        <translation>Diario modificado...</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="225"/>
        <source>The diary is modified. Do you want to save it?</source>
        <translation>El diario se ha modificado. ¿Quiere guardarlo?</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="265"/>
        <source>Failed...</source>
        <translation>Falló...</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="265"/>
        <source>Failed to save diary to database. Probably because it was not created from a database project.</source>
        <translation>Fallo al guardar el diario en la base de datos. Probablemente porque no se creó desde un proyecto de base de datos.</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="312"/>
        <source>Print Diary</source>
        <translation>Imprimir el Diario</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="535"/>
        <source>Diary - %1 *</source>
        <translation>Diario - %1 *</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="539"/>
        <source>Diary - %1</source>
        <translation>Diario - %1</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="660"/>
        <source>Add your own text here...</source>
        <translation>Añada su propio texto aquí...</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="672"/>
        <source>Waypoints</source>
        <translation>Waypoints</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="680"/>
        <location filename="../CDiaryEdit.cpp" line="718"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="681"/>
        <location filename="../CDiaryEdit.cpp" line="719"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="710"/>
        <source>Tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <location filename="../CDiaryEdit.cpp" line="765"/>
        <source>&lt;b&gt;Owner:&lt;/b&gt; %1 &lt;b&gt;Size:&lt;/b&gt; %2 &lt;b&gt;Difficulty:&lt;/b&gt; %3 &lt;b&gt;Terrain:&lt;/b&gt; %4</source>
        <translation>&lt;b&gt;Propietario:&lt;/b&gt; %1 &lt;b&gt;Tamaño:&lt;/b&gt; %2 &lt;b&gt;Dificultad:&lt;/b&gt; %3 &lt;b&gt;Terreno:&lt;/b&gt; %4</translation>
    </message>
</context>
<context>
    <name>CDiaryEditWidget</name>
    <message>
        <source>&amp;Bold</source>
        <translation type="obsolete">&amp;Negrita</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation type="obsolete">&amp;Cursiva</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation type="obsolete">&amp;Subrayado</translation>
    </message>
    <message>
        <source>&amp;Left</source>
        <translation type="obsolete">&amp;Izquierda</translation>
    </message>
    <message>
        <source>C&amp;enter</source>
        <translation type="obsolete">C&amp;entrar</translation>
    </message>
    <message>
        <source>&amp;Right</source>
        <translation type="obsolete">&amp;Derecha</translation>
    </message>
    <message>
        <source>&amp;Justify</source>
        <translation type="obsolete">&amp;Justificar</translation>
    </message>
    <message>
        <source>&amp;Color...</source>
        <translation type="obsolete">&amp;Color...</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="obsolete">&amp;Deshacer</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="obsolete">&amp;Rehacer</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="obsolete">Cor&amp;tar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="obsolete">&amp;Copiar</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="obsolete">&amp;Pegar</translation>
    </message>
    <message>
        <source>&lt;h1&gt;Default Title&lt;/h1&gt;</source>
        <translation type="obsolete">&lt;h1&gt;Titulo Predeterminado&lt;/h1&gt;</translation>
    </message>
    <message>
        <source>&lt;h1&gt;%1&lt;/h1&gt;</source>
        <translation type="obsolete">&lt;h1&gt;%1&lt;/h1&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;This is an automated diary.&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Esto es un diario automático.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos; style=&apos;width: 16px;&apos;&gt;&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos; style=&apos;width: 16px;&apos;&gt;&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Time&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Hora&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Pos.&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Pos.&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Name&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Nombre&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Elevation&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Altitud&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Distance&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Distancia&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Comment&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Comentario&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos; style=&apos;width: 20px;&apos;&gt;&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos; style=&apos;width: 20px;&apos;&gt;&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Start&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Comenzar&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Stop&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Detener&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Length&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Longitud&lt;/th&gt;</translation>
    </message>
    <message>
        <source>&lt;th align=&apos;left&apos;&gt;Speed&lt;/th&gt;</source>
        <translation type="obsolete">&lt;th align=&apos;left&apos;&gt;Velocidad&lt;/th&gt;</translation>
    </message>
    <message>
        <source>Diary Wizard</source>
        <translation type="obsolete">Asistente para el diario</translation>
    </message>
    <message>
        <source>The wizard will replace the current text by it&apos;s own. Do you want to proceed?</source>
        <translation type="obsolete">El asistente sustituirá el texto actual por el suyo. ¿Desea continuar?</translation>
    </message>
</context>
<context>
    <name>CDlgConfig</name>
    <message>
        <location filename="../CDlgConfig.cpp" line="127"/>
        <source>QLandkarte M</source>
        <translation>QLandkarte M</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="128"/>
        <source>Garmin</source>
        <translation>Garmin</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="129"/>
        <source>Garmin Mass Storage</source>
        <translation>Almacenamiento Masivo de Garmin</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="130"/>
        <source>Magellan</source>
        <translation>Magellan</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="131"/>
        <source>TwoNav</source>
        <translation>TwoNav</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="132"/>
        <source>NMEA</source>
        <translation>NMEA</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="156"/>
        <source>Pass something like &quot;COM1&quot; or &quot;\\.\COM13&quot; or &quot;\\.\com13&quot; for serial Garmin devices or NMEA devices. For Garmin USB devices leave blank.</source>
        <translation>Introduzca algo del estilo de &quot;COM1:&quot; o &quot;\\.\COM13&quot; o &quot;\\.\com13&quot; para dispositivos NMEA o Garmin de puerto serie. Para dispositivos Garmin USB, dejar en blanco.</translation>
    </message>
    <message>
        <source>Mikrokopter</source>
        <translation type="obsolete">Mikrokopter</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="144"/>
        <source>GPSD</source>
        <translation>GPSD</translation>
    </message>
    <message>
        <source>Pass something like &quot;COM1:&quot; or &quot;\\.\COM13&quot; or &quot;\\.\com13&quot; for serial Garmin devices or NMEA devices. For Garmin USB devices leave blank.</source>
        <translation type="obsolete">Introduzca algo del estilo de &quot;COM1:&quot; o &quot;\\.\COM13&quot; para dispositivos NMEA o Garmin de puerto serie. Para dispositivos Garmin USB, dejar en blanco.</translation>
    </message>
    <message>
        <source>Pass something like &quot;COM1:&quot; or &quot;\\.\COM13&quot; for serial Garmin devices or NMEA devices. For Garmin USB devices leave blank.</source>
        <translation type="obsolete">Introduzca algo del estilo de &quot;COM1:&quot; o &quot;\\.\COM13&quot; para dispositivos NMEA o Garmin de puerto serie. Para dispositivos Garmin USB, dejar en blanco.</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="398"/>
        <location filename="../CDlgConfig.cpp" line="402"/>
        <source>No plugins found. I expect them in: %1</source>
        <translation>No se encontraron plugins. Los esperaba encontrar en: %1</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="438"/>
        <location filename="../CDlgConfig.cpp" line="464"/>
        <source>Open Directory</source>
        <translation>Abrir Directorio</translation>
    </message>
    <message>
        <location filename="../CDlgConfig.cpp" line="73"/>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CDlgConfig3D</name>
    <message>
        <location filename="../CDlgConfig3D.cpp" line="29"/>
        <source>fine</source>
        <translation>máxima</translation>
    </message>
    <message>
        <location filename="../CDlgConfig3D.cpp" line="30"/>
        <source>medium</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../CDlgConfig3D.cpp" line="31"/>
        <source>coarse</source>
        <translation>mínima</translation>
    </message>
</context>
<context>
    <name>CDlgConvertToTrack</name>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="28"/>
        <source>none</source>
        <translation>ninguno</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="29"/>
        <source>10 m</source>
        <translation>10 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="30"/>
        <source>20 m</source>
        <translation>20 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="31"/>
        <source>30 m</source>
        <translation>30 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="32"/>
        <source>50 m</source>
        <translation>50 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="33"/>
        <source>100 m</source>
        <translation>100 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="34"/>
        <source>200 m</source>
        <translation>200 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="35"/>
        <source>300 m</source>
        <translation>300 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="36"/>
        <source>500 m</source>
        <translation>500 m</translation>
    </message>
    <message>
        <location filename="../CDlgConvertToTrack.cpp" line="37"/>
        <source>1 km</source>
        <translation>1 km</translation>
    </message>
</context>
<context>
    <name>CDlgCropMap</name>
    <message>
        <location filename="../CDlgCropMap.cpp" line="197"/>
        <source>*** done ***
</source>
        <translation>*** hecho ***
</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="200"/>
        <source>Warnings. See &quot;Details&quot; for more information.
</source>
        <translation>Atención. Vea &quot;Detalles&quot; para más información.
</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="204"/>
        <location filename="../CDlgCropMap.cpp" line="234"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="212"/>
        <source>Step %1/%2,</source>
        <translation>Paso %1/%2,</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="225"/>
        <source>!!! failed !!!
</source>
        <translation>¡¡¡ falló !!!
</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="227"/>
        <source>Failed. See &quot;Details&quot; for more information.</source>
        <translation>Falló. Vea &quot;Detalles&quot; para más información.</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="247"/>
        <source>
Canceled by user&apos;s request.
</source>
        <translation>
Cancelado a petición del usuario.
</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="265"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>CDlgDeviceExportPath</name>
    <message>
        <location filename="../CDlgDeviceExportPath.cpp" line="28"/>
        <source>Where should I place all %1?</source>
        <translation>¿Dónde debería poner todo %1?</translation>
    </message>
</context>
<context>
    <name>CDlgEditFolder</name>
    <message>
        <location filename="../CDlgEditFolder.cpp" line="34"/>
        <source>Group</source>
        <translation>Grupo</translation>
    </message>
    <message>
        <location filename="../CDlgEditFolder.cpp" line="35"/>
        <source>Project</source>
        <translation>Proyecto</translation>
    </message>
    <message>
        <location filename="../CDlgEditFolder.cpp" line="36"/>
        <source>Other data</source>
        <translation>Otros datos</translation>
    </message>
</context>
<context>
    <name>CDlgEditMapLevel</name>
    <message>
        <location filename="../CDlgEditMapLevel.cpp" line="85"/>
        <location filename="../CDlgEditMapLevel.cpp" line="89"/>
        <location filename="../CDlgEditMapLevel.cpp" line="129"/>
        <location filename="../CDlgEditMapLevel.cpp" line="133"/>
        <source>Select &lt;b&gt;all&lt;/b&gt; files for that level.</source>
        <translation>Seleccionar &lt;b&gt;todos&lt;/b&gt; los archivos para este nivel.</translation>
    </message>
</context>
<context>
    <name>CDlgEditWpt</name>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="289"/>
        <location filename="../CDlgEditWpt.cpp" line="294"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="294"/>
        <source>You must provide a waypoint position.</source>
        <translation>Debe proporcionar una posición de waypoint.</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="333"/>
        <source>(proj.)</source>
        <translation>(proj.)</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="367"/>
        <source>Select image file</source>
        <translation>Seleccionar archivo de imagen</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="378"/>
        <location filename="../CDlgEditWpt.cpp" line="621"/>
        <source>Add comment ...</source>
        <translation>Añadir comentario ...</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="378"/>
        <location filename="../CDlgEditWpt.cpp" line="621"/>
        <source>comment</source>
        <translation>comentario</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="441"/>
        <source>no image</source>
        <translation>sin imagen</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="464"/>
        <source>Edit link ...</source>
        <translation>Editar enlace ...</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="464"/>
        <source>Link: &apos;http://...&apos;</source>
        <translation>Enlace: &apos;http://...&apos;</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="468"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="486"/>
        <source>Select output file</source>
        <translation>Seleccionar archivo de salida</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="509"/>
        <location filename="../CDlgEditWpt.cpp" line="510"/>
        <location filename="../CDlgEditWpt.cpp" line="513"/>
        <source>%1
</source>
        <translation>%1
</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="654"/>
        <source>Delete images...</source>
        <translation>Borrar imágenes...</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="654"/>
        <source>Remove all other images first?</source>
        <translation>¿Eliminar el resto de imágenes primero?</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="773"/>
        <source>No spoilers...</source>
        <translation>Sin spoilers...</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="773"/>
        <source>No spoilers found.</source>
        <translation>No se encontraron spoilers.</translation>
    </message>
    <message>
        <location filename="../CDlgEditWpt.cpp" line="289"/>
        <source>You must provide a waypoint identifier.</source>
        <translation>Debe proporcionar un identificador de waypoint.</translation>
    </message>
</context>
<context>
    <name>CDlgExport</name>
    <message>
        <location filename="../CDlgExport.cpp" line="54"/>
        <source>Waypoints</source>
        <translation>Waypoints</translation>
    </message>
    <message>
        <location filename="../CDlgExport.cpp" line="58"/>
        <source>Tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <location filename="../CDlgExport.cpp" line="62"/>
        <source>Routes</source>
        <translation>Rutas</translation>
    </message>
</context>
<context>
    <name>CDlgImportImages</name>
    <message>
        <location filename="../CDlgImportImages.cpp" line="143"/>
        <source>Select path...</source>
        <translation>Seleccionar directorio...</translation>
    </message>
</context>
<context>
    <name>CDlgLoadOnlineMap</name>
    <message>
        <location filename="../CDlgLoadOnlineMap.cpp" line="205"/>
        <source>Open Directory</source>
        <translation>Abrir Directorio</translation>
    </message>
</context>
<context>
    <name>CDlgMapOSMConfig</name>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nombre</translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="obsolete">Ruta</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="obsolete">Clave</translation>
    </message>
    <message>
        <source>Built-in maps</source>
        <translation type="obsolete">Mapas de serie</translation>
    </message>
    <message>
        <source>Custom maps</source>
        <translation type="obsolete">Mapas personalizados</translation>
    </message>
</context>
<context>
    <name>CDlgMapWmsConfig</name>
    <message>
        <location filename="../CDlgMapWmsConfig.cpp" line="37"/>
        <source>File: %1</source>
        <translation>Archivo: %1</translation>
    </message>
</context>
<context>
    <name>CDlgProjWizzard</name>
    <message>
        <location filename="../CDlgProjWizzard.cpp" line="59"/>
        <source>north</source>
        <translation>norte</translation>
    </message>
    <message>
        <location filename="../CDlgProjWizzard.cpp" line="60"/>
        <source>south</source>
        <translation>sur</translation>
    </message>
    <message>
        <location filename="../CDlgProjWizzard.cpp" line="217"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CDlgProjWizzard.cpp" line="217"/>
        <source>The value
&apos;%1&apos;
is not a valid coordinate system definition:
%2</source>
        <translation>El valor
&apos;%1&apos;
no es una definición válida de sistema de coordenadas:
%2</translation>
    </message>
</context>
<context>
    <name>CDlgProxy</name>
    <message>
        <location filename="../CDlgProxy.cpp" line="39"/>
        <source>&lt;qt&gt;Connect to proxy &quot;%1&quot; using:&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;Conexión al proxy &quot;%1&quot; utilizando:&lt;/qt&gt;</translation>
    </message>
</context>
<context>
    <name>CDlgScreenshot</name>
    <message>
        <location filename="../CDlgScreenshot.cpp" line="64"/>
        <source>Select output file</source>
        <translation>Seleccionar archivo de salida</translation>
    </message>
</context>
<context>
    <name>CDlgSetupGarminIcons</name>
    <message>
        <location filename="../CDlgSetupGarminIcons.cpp" line="81"/>
        <source>reset icon</source>
        <translation>restaurar icono</translation>
    </message>
    <message>
        <location filename="../CDlgSetupGarminIcons.cpp" line="87"/>
        <source>select icon</source>
        <translation>seleccionar icono</translation>
    </message>
    <message>
        <location filename="../CDlgSetupGarminIcons.cpp" line="146"/>
        <source>Select icon ...</source>
        <translation>Seleccionar icono ...</translation>
    </message>
    <message>
        <location filename="../CDlgSetupGarminIcons.cpp" line="245"/>
        <source>Format Error</source>
        <translation>Error de formato</translation>
    </message>
    <message>
        <location filename="../CDlgSetupGarminIcons.cpp" line="245"/>
        <source>: Bad icon format</source>
        <translation>: Formato de icono erróneo</translation>
    </message>
    <message>
        <location filename="../CDlgSetupGarminIcons.cpp" line="277"/>
        <source>Device Link Error</source>
        <translation>Error al enlazar el dispositivo</translation>
    </message>
</context>
<context>
    <name>CDlgTrackFilter</name>
    <message>
        <location filename="../CDlgTrackFilter.cpp" line="87"/>
        <source>Smooth profile (Median filter, %1 tabs)</source>
        <translation>Suavizar perfil (Filtro mediana, %1 puntos)</translation>
    </message>
    <message>
        <location filename="../CDlgTrackFilter.cpp" line="149"/>
        <location filename="../CDlgTrackFilter.cpp" line="219"/>
        <location filename="../CDlgTrackFilter.cpp" line="275"/>
        <source>Filter track...</source>
        <translation>Filtrar track ...</translation>
    </message>
    <message>
        <location filename="../CDlgTrackFilter.cpp" line="149"/>
        <location filename="../CDlgTrackFilter.cpp" line="219"/>
        <location filename="../CDlgTrackFilter.cpp" line="275"/>
        <source>Abort filter</source>
        <translation>Abortar filtrado</translation>
    </message>
</context>
<context>
    <name>CGarminExport</name>
    <message>
        <source>Select ouput path...</source>
        <translation type="obsolete">Seleccionar el directorio de salida...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="60"/>
        <source>Select output path...</source>
        <translation>Seleccionar ruta de salida...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="73"/>
        <source>Creating image from maps:
</source>
        <translation>Creando imagen a partir de los mapas:
</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="89"/>
        <source>Map: %1</source>
        <translation>Mapa: %1</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="93"/>
        <source>Map: %1 (Key: %2)</source>
        <translation>Mapa: %1 (Clave: %2)</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="111"/>
        <location filename="../CGarminExport.cpp" line="141"/>
        <source>    %1 (%2 MB)</source>
        <translation>%1 (%2 MB)</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="231"/>
        <source>Failed to read: </source>
        <translation>Fallo al leer:</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="349"/>
        <source>Failed to open: </source>
        <translation>Fallo al abrir:</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="360"/>
        <location filename="../CGarminExport.cpp" line="364"/>
        <source>Bad file format: </source>
        <translation>Formato de archivo erróneo:</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="401"/>
        <source>contains a duplicate internal filename. Skipped!</source>
        <translation>contiene un nombre de fichero interno duplicado. ¡Se ignoró!</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="437"/>
        <source>Failed to read file structure: </source>
        <translation>Fallo al leer la estructura del archivo:</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="621"/>
        <source>FAT entries: %1 (of %2) Failed!</source>
        <translation>Entradas FAT: %1 (de %2) ¡Error!</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="622"/>
        <location filename="../CGarminExport.cpp" line="632"/>
        <location filename="../CGarminExport.cpp" line="642"/>
        <source>Too many tiles.</source>
        <translation>Demasiadas teselas.</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="626"/>
        <source>FAT entries: %1 (of %2) </source>
        <translation>Entradas FAT: %1 (de %2)</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="631"/>
        <source>Block count: %1 (of %2) Failed!</source>
        <translation>Cuenta de bloques: %1 (of %2) ¡Falló!</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="636"/>
        <source>Block count: %1 (of %2)</source>
        <translation>Cuenta de bloques: %1 (of %2)</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="641"/>
        <source>File size: %1 MB (of %2 MB) Failed!</source>
        <translation>Tamaño del archivo: %1 MB (de %2 MB) ¡Error!</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="646"/>
        <source>File size: %1 MB (of %2 MB)</source>
        <translation>Tamaño del archivo: %1 MB (de %2 MB)</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="661"/>
        <source>Initialize %1</source>
        <translation>Inicializar %1</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="671"/>
        <source>Write header...</source>
        <translation>Escribir cabecera...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="817"/>
        <source>Copy tile data...</source>
        <translation>Copiar datos de la tesela...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="823"/>
        <source>    Copy %1...</source>
        <translation>    Copiar %1...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="853"/>
        <source>Copy typ files...</source>
        <translation>Copiar archivos TYP...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="874"/>
        <source>Write map lookup table...</source>
        <translation>Escribiendo tabla de descripción del mapa...</translation>
    </message>
    <message>
        <location filename="../CGarminExport.cpp" line="885"/>
        <source>Abort due to errors.</source>
        <translation>Se abortó debido a errores.</translation>
    </message>
</context>
<context>
    <name>CGarminIndex</name>
    <message>
        <location filename="../CGarminIndex.cpp" line="142"/>
        <source>Create index... %1</source>
        <translation>Crear índice... %1</translation>
    </message>
    <message>
        <location filename="../CGarminIndex.cpp" line="402"/>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
</context>
<context>
    <name>CGarminTile</name>
    <message>
        <location filename="../CGarminTile.cpp" line="58"/>
        <source>Failed to read: </source>
        <translation>Fallo al leer: </translation>
    </message>
    <message>
        <location filename="../CGarminTile.cpp" line="105"/>
        <source>Failed to open: </source>
        <translation>Fallo al abrir: </translation>
    </message>
    <message>
        <location filename="../CGarminTile.cpp" line="138"/>
        <location filename="../CGarminTile.cpp" line="142"/>
        <source>Bad file format: </source>
        <translation>Formato de archivo erróneo: </translation>
    </message>
    <message>
        <location filename="../CGarminTile.cpp" line="233"/>
        <source>Failed to read file structure: </source>
        <translation>Fallo al leer la estructura del archivo: </translation>
    </message>
    <message>
        <location filename="../CGarminTile.cpp" line="270"/>
        <source>File is NT format. QLandkarte GT is unable to read map files with NT format: </source>
        <translation>El archivo está en formato NT. QLandkarte GT aún no puede leer archivos de mapa en formato NT: </translation>
    </message>
    <message>
        <source>File is NT format. Unable to read: </source>
        <translation type="obsolete">Archivo en formato NT. Imposible abrir: </translation>
    </message>
    <message>
        <location filename="../CGarminTile.cpp" line="392"/>
        <source>File contains locked / encypted data. Garmin does not want you to use this file with any other software than the one supplied by Garmin.</source>
        <translation>El archivo contiene datos bloqueados / cifrados. Garmin no quiere que usted use este archivo con programas distintos a los que ellos proporcionan.</translation>
    </message>
</context>
<context>
    <name>CGeoDB</name>
    <message>
        <location filename="../CGeoDB.cpp" line="100"/>
        <source>Manage your Geo Data Base</source>
        <translation>Gestione su Base de Geo Datos</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="104"/>
        <location filename="../CGeoDB.cpp" line="836"/>
        <location filename="../CGeoDB.cpp" line="895"/>
        <source>Workspace</source>
        <translation>Espacio de trabajo</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="106"/>
        <source>All items you see on the map.</source>
        <translation>Todos los elementos que ve en el mapa.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="111"/>
        <location filename="../CGeoDB.cpp" line="844"/>
        <source>Waypoints</source>
        <translation>Waypoints</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="118"/>
        <location filename="../CGeoDB.cpp" line="848"/>
        <source>Tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="125"/>
        <location filename="../CGeoDB.cpp" line="852"/>
        <source>Routes</source>
        <translation>Rutas</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="132"/>
        <location filename="../CGeoDB.cpp" line="856"/>
        <source>Overlays</source>
        <translation>Superposiciones</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="139"/>
        <source>Map Selections</source>
        <translation>Selecciones de Mapas</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="146"/>
        <location filename="../CGeoDB.cpp" line="1184"/>
        <source>Lost &amp; Found</source>
        <translation>Objetos perdidos</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="149"/>
        <source>All items that lost their parent folder as you deleted it.</source>
        <translation>Todos los elementos sin carpeta padre por haberla borrado.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="153"/>
        <source>Database</source>
        <translation>Base de datos</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="157"/>
        <source>All your data grouped by folders.</source>
        <translation>Todos sus datos agrupados por carpetas.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="208"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="209"/>
        <source>Add diary</source>
        <translation>Añadir diario</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="210"/>
        <source>Show/hide diary</source>
        <translation>Mostrar/ocultar diario</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="211"/>
        <source>Delete diary</source>
        <translation>Borrar diario</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="212"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="213"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="215"/>
        <location filename="../CGeoDB.cpp" line="221"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="216"/>
        <location filename="../CGeoDB.cpp" line="222"/>
        <location filename="../CGeoDB.cpp" line="226"/>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="217"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="230"/>
        <source>Add to database</source>
        <translation>Añadir a la base de datos</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="231"/>
        <source>Save changes</source>
        <translation>Guardar cambios</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="232"/>
        <source>Check-out as copy</source>
        <translation>Guardar como copia</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="694"/>
        <source>Migrating database from version 8 to 9.</source>
        <translation>Migrando la base de datos de la versión 8 a la 9.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3626"/>
        <source>Delete diary...</source>
        <translation>Borrar diario...</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3626"/>
        <source>Do you really want to delete the diary?</source>
        <translation>¿Realmente quiere borrar el diario?</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3923"/>
        <source>Export data to...</source>
        <translation>Exportar datos a...</translation>
    </message>
    <message>
        <source>Mirgrating database from version 4 to 5.</source>
        <translation type="obsolete">Migrando la base de datos de la versión 4 a la 5.</translation>
    </message>
    <message>
        <source>Mirgrating database from version 5 to 6.</source>
        <translation type="obsolete">Migrando la base de datos de la versión 5 a la 6.</translation>
    </message>
    <message>
        <source>Mirgrating database from version 6 to 7.</source>
        <translation type="obsolete">Migrando la base de datos de la versión 6 a la 7.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="764"/>
        <source>Loading workspace. Please wait.</source>
        <translation>Cargando espacio de trabajo. Por favor espere.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="860"/>
        <source>Map Selection</source>
        <translation>Selección de Mapa</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="948"/>
        <source>Update workspace.</source>
        <translation>Actualizar espacio de trabajo.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="1380"/>
        <location filename="../CGeoDB.cpp" line="3887"/>
        <source>Loading items from database.</source>
        <translation>Cargando elementos desde la base de datos.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="1944"/>
        <source>Saving workspace. Please wait.</source>
        <translation>Guardando espacio de trabajo. Por favor espere.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="2808"/>
        <source>Delete folder...</source>
        <translation>Borrar carpeta...</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="2968"/>
        <location filename="../CGeoDB.cpp" line="3164"/>
        <source>Delete items.</source>
        <translation>Borrar elementos.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3012"/>
        <source>Copy items.</source>
        <translation>Copiar elementos.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3067"/>
        <location filename="../CGeoDB.cpp" line="3127"/>
        <source>Move items.</source>
        <translation>Mover elementos.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3203"/>
        <source>Add items to database.</source>
        <translation>Añadir elementos a la base de datos.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="3337"/>
        <source>Save items.</source>
        <translation>Guardar elementos.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="214"/>
        <location filename="../CGeoDB.cpp" line="223"/>
        <location filename="../CGeoDB.cpp" line="227"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="489"/>
        <source>Migrating database from version 4 to 5.</source>
        <translation>Migrando la base de datos de la versión 4 a la 5.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="540"/>
        <source>Migrating database from version 5 to 6.</source>
        <translation>Migrando la base de datos de la versión 5 a la 6.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="597"/>
        <source>Migrating database from version 6 to 7.</source>
        <translation>Migrando la base de datos de la versión 6 a la 7.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="662"/>
        <source>Migrating database from version 7 to 8.</source>
        <translation>Migrando la base de datos de la versión 7 a la 8.</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="2808"/>
        <source>You are sure you want to delete &apos;%1&apos; and all items below?</source>
        <translation>¿Seguro que quiere borrar &apos;%1&apos; y todos los elementos siguientes?</translation>
    </message>
    <message>
        <location filename="../CGeoDB.cpp" line="1180"/>
        <source>Lost &amp; Found (%1)</source>
        <translation>Objetos perdidos (%1)</translation>
    </message>
</context>
<context>
    <name>CGpx</name>
    <message>
        <location filename="../CGpx.cpp" line="159"/>
        <source>bad application</source>
        <translation>Aplicación errónea</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="164"/>
        <source>File exists ...</source>
        <translation>El archivo existe ...</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="165"/>
        <source>The file exists and it has not been created by QLandkarte GT. If you press &apos;yes&apos; all data in this file will be lost. Even if this file contains GPX data, QLandkarte GT might not load and store all elements of this file. Those elements will be lost. I recommend to use another file. &lt;b&gt;Do you really want to overwrite the file?&lt;/b&gt;</source>
        <translation>El archivo existe y no lo ha creado QLandkarte GT. Si pulsa &apos;Sí&apos; todos los datos de este fichero se perderán. Incluso si este archivo contiene datos GPX, QLandkarte GT podría no cargar y guardar todos los elementos de este archivo. Esos elementos se perderán. Se recomienda usar otro archivo &lt;b&gt;¿Seguro que desea sobreescribir el archivo?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="181"/>
        <source>Failed to create %1</source>
        <translation>Falló la creación de %1</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="190"/>
        <source>Failed to write %1</source>
        <translation>Falló la escritura de %1</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="202"/>
        <source>Failed to open: </source>
        <translation>No se pudo abrir: </translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="218"/>
        <source>Not a GPX file: </source>
        <translation>No es un archivo GPX:</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="222"/>
        <source>GPX schema violation: no &quot;creator&quot; attribute.</source>
        <translation>Violación del esquema GPX: no existe el atributo &quot;creator&quot;.</translation>
    </message>
    <message>
        <location filename="../CGpx.cpp" line="211"/>
        <source>Failed to read: %1
line %2, column %3:
 %4</source>
        <translation>No se pudo leer: %1
linea %2, columna %3:
 %4</translation>
    </message>
</context>
<context>
    <name>CGridDB</name>
    <message>
        <location filename="../CGridDB.cpp" line="51"/>
        <source>Grid</source>
        <translation>Rejilla</translation>
    </message>
    <message>
        <location filename="../CGridDB.cpp" line="97"/>
        <source>Configure grid color and projection.
Cur. proj.: %1</source>
        <translation>Configurar color y proyección de la rejilla.
Proyección actual: %1</translation>
    </message>
    <message>
        <source>Use &apos;Setup -&gt; Grid...&apos; to setup color and projection.
Cur. proj.: %1</source>
        <translation type="obsolete">Utilice &apos;Preferencias -&gt; Rejilla...&apos; para asignar color y proyección.
Proyección actual: %1</translation>
    </message>
</context>
<context>
    <name>CImageSelect</name>
    <message>
        <location filename="../CImageSelect.cpp" line="52"/>
        <location filename="../CImageSelect.cpp" line="83"/>
        <source>leave right</source>
        <translation>salir a la derecha</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="53"/>
        <location filename="../CImageSelect.cpp" line="84"/>
        <source>leave left</source>
        <translation>salir a la izquierda</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="54"/>
        <location filename="../CImageSelect.cpp" line="55"/>
        <location filename="../CImageSelect.cpp" line="58"/>
        <location filename="../CImageSelect.cpp" line="59"/>
        <location filename="../CImageSelect.cpp" line="62"/>
        <location filename="../CImageSelect.cpp" line="63"/>
        <location filename="../CImageSelect.cpp" line="74"/>
        <location filename="../CImageSelect.cpp" line="85"/>
        <location filename="../CImageSelect.cpp" line="86"/>
        <location filename="../CImageSelect.cpp" line="89"/>
        <location filename="../CImageSelect.cpp" line="90"/>
        <location filename="../CImageSelect.cpp" line="93"/>
        <location filename="../CImageSelect.cpp" line="94"/>
        <location filename="../CImageSelect.cpp" line="105"/>
        <source>straight on</source>
        <translation>continuar recto</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="56"/>
        <location filename="../CImageSelect.cpp" line="87"/>
        <source>turn right</source>
        <translation>girar a la derecha</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="57"/>
        <location filename="../CImageSelect.cpp" line="88"/>
        <source>turn left</source>
        <translation>girar a la izquierda</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="60"/>
        <location filename="../CImageSelect.cpp" line="68"/>
        <location filename="../CImageSelect.cpp" line="91"/>
        <location filename="../CImageSelect.cpp" line="99"/>
        <source>hard right turn</source>
        <translation>giro brusco a la derecha</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="61"/>
        <location filename="../CImageSelect.cpp" line="69"/>
        <location filename="../CImageSelect.cpp" line="92"/>
        <location filename="../CImageSelect.cpp" line="100"/>
        <source>hard left turn</source>
        <translation>giro brusco a la izquierda</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="64"/>
        <location filename="../CImageSelect.cpp" line="70"/>
        <location filename="../CImageSelect.cpp" line="95"/>
        <location filename="../CImageSelect.cpp" line="101"/>
        <source>go left</source>
        <translation>ir a la izquierda</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="65"/>
        <location filename="../CImageSelect.cpp" line="71"/>
        <location filename="../CImageSelect.cpp" line="96"/>
        <location filename="../CImageSelect.cpp" line="102"/>
        <source>go right</source>
        <translation>ir a la derecha</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="66"/>
        <location filename="../CImageSelect.cpp" line="97"/>
        <source>take right</source>
        <translation>tomar derecha</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="67"/>
        <location filename="../CImageSelect.cpp" line="98"/>
        <source>take left</source>
        <translation>tomar izquierda</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="72"/>
        <location filename="../CImageSelect.cpp" line="103"/>
        <source>turn right @x-ing</source>
        <translation>girar a la derecha en cruce</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="73"/>
        <location filename="../CImageSelect.cpp" line="104"/>
        <source>turn left @x-ing</source>
        <translation>girar a la izquierda en cruce</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="75"/>
        <location filename="../CImageSelect.cpp" line="106"/>
        <source>u-turn right</source>
        <translation>giro en U a la derecha</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="76"/>
        <location filename="../CImageSelect.cpp" line="107"/>
        <source>u-turn left</source>
        <translation>giro en U a la izquierda</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="77"/>
        <location filename="../CImageSelect.cpp" line="108"/>
        <source>river</source>
        <translation>río</translation>
    </message>
    <message>
        <location filename="../CImageSelect.cpp" line="78"/>
        <location filename="../CImageSelect.cpp" line="109"/>
        <source>attention</source>
        <translation>atención</translation>
    </message>
</context>
<context>
    <name>CLiveLogDB</name>
    <message>
        <location filename="../CLiveLogDB.cpp" line="82"/>
        <source>LiveLog</source>
        <translation>Grabación en vivo</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="166"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="209"/>
        <source>2D (%1)</source>
        <translation>2D (%1)</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="213"/>
        <source>3D (%1)</source>
        <translation>3D (%1)</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="217"/>
        <source>DR (%1)</source>
        <translation>DR (%1)</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="224"/>
        <location filename="../CLiveLogDB.cpp" line="234"/>
        <location filename="../CLiveLogDB.cpp" line="244"/>
        <location filename="../CLiveLogDB.cpp" line="254"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="264"/>
        <source>%1%2 T</source>
        <translation>%1%2 T</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="309"/>
        <source>GPS signal low (%1)</source>
        <translation>Señal de GPS débil (%1)</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="322"/>
        <source>GPS connection failed</source>
        <translation>Falló la conexión con el GPS</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="326"/>
        <source>GPS connection established</source>
        <translation>Conexión con el GPS restablecida</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="330"/>
        <source>GPS connection receiving %1 bytes</source>
        <translation>Conexión con el GPS recibiendo %1 bytes</translation>
    </message>
    <message>
        <source>±%1 m</source>
        <translation type="obsolete">±%1 m</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>%1° T</source>
        <translation type="obsolete">%1° T</translation>
    </message>
    <message>
        <source>GPS signal low</source>
        <translation type="obsolete">Señal GPS débil</translation>
    </message>
    <message>
        <location filename="../CLiveLogDB.cpp" line="334"/>
        <source>GPS off</source>
        <translation>GPS apagado</translation>
    </message>
</context>
<context>
    <name>CLiveLogToolWidget</name>
    <message>
        <location filename="../CLiveLogToolWidget.cpp" line="31"/>
        <source>Live Log</source>
        <translation>Grabación en vivo</translation>
    </message>
</context>
<context>
    <name>CMainWindow</name>
    <message>
        <location filename="../CMainWindow.cpp" line="109"/>
        <source>Map</source>
        <translation>Mapa</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="244"/>
        <source>&lt;b&gt;GPS Device:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Dispositivo GPS:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="268"/>
        <source>quadratic zoom</source>
        <translation>zoom exponencial</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="517"/>
        <source>Clear all...</source>
        <translation>Eliminar todo...</translation>
    </message>
    <message>
        <source>This will erase all project data like waypoints and tracks.</source>
        <translation type="obsolete">Esto eliminará todos los datos del proyecto, tales como waypoints y tracks.</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="565"/>
        <source>Load most recent...</source>
        <translation>Abrir archivos recientes...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="575"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="576"/>
        <source>Load Map</source>
        <translation>Cargar Mapa</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="577"/>
        <source>Load Online Map</source>
        <translation>Cargar Mapa Online</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="579"/>
        <source>Load Geo Data</source>
        <translation>Cargar Datos Geográficos</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="580"/>
        <source>Save Geo Data</source>
        <translation>Guardar Datos Geográficos</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="581"/>
        <source>Export Geo Data</source>
        <translation>Exportar Datos Geográficos</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="582"/>
        <source>Add Geo Data</source>
        <translation>Añadir Datos Geográficos</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="585"/>
        <source>Device Screenshot ...</source>
        <translation>Capturar pantalla del dispositivo ...</translation>
    </message>
    <message>
        <source>Save as image ...</source>
        <translation type="obsolete">Guardar imagen como ...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="587"/>
        <source>Print Map ...</source>
        <translation>Imprimir Mapa ...</translation>
    </message>
    <message>
        <source>Print Diary ...</source>
        <translation type="obsolete">Imprimir Diario ...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="594"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="642"/>
        <source>&amp;Setup</source>
        <translation>&amp;Preferencias</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="646"/>
        <source>&amp;General</source>
        <translation>&amp;General</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="659"/>
        <source>&amp;Help</source>
        <translation>Ay&amp;uda</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="664"/>
        <source>About &amp;QLandkarte GT</source>
        <translation>Acerca de &amp;QLandkarte GT</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="702"/>
        <source>Select map...</source>
        <translation>Seleccionar mapa...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1313"/>
        <source>&lt;div style=&apos;float: left;&apos;&gt;&lt;b&gt;Workspace Summary (&lt;a href=&apos;Clear&apos;&gt;clear&lt;/a&gt; workspace):&lt;/b&gt;&lt;/div&gt;</source>
        <translation>&lt;div style=&apos;float: left;&apos;&gt;&lt;b&gt;Resumen del área de trabajo (&lt;a href=&apos;Clear&apos;&gt;limpiar&lt;/a&gt; área de trabajo):&lt;/b&gt;&lt;/div&gt;</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1432"/>
        <source>Garmin Mass Storage</source>
        <translation>Almacenamiento Masivo de Garmin</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1434"/>
        <source>TwoNav</source>
        <translation>TwoNav</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1435"/>
        <source>NMEA</source>
        <translation>NMEA</translation>
    </message>
    <message>
        <source>Mikrokopter</source>
        <translation type="obsolete">Mikrokopter</translation>
    </message>
    <message>
        <source>Select input file</source>
        <translation type="obsolete">Seleccionar archivo de entrada</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="926"/>
        <source>Convert error</source>
        <translation>Error de conversión</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="945"/>
        <location filename="../CMainWindow.cpp" line="1179"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="984"/>
        <source>Save geo data?</source>
        <translation>¿Guardar datos geográficos?</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="985"/>
        <source>The loaded data has been modified.
Do you want to save your changes?</source>
        <translation>Se han modificado los datos cargados.
¿Desea guardar los cambios ?</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1017"/>
        <location filename="../CMainWindow.cpp" line="1050"/>
        <location filename="../CMainWindow.cpp" line="1268"/>
        <source>Select output file</source>
        <translation>Seleccionar archivo de salida</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1217"/>
        <source>Failed ...</source>
        <translation>Falló...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1217"/>
        <source>Failed to start OCM.</source>
        <translation>Fallo al inicial OCM.</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1251"/>
        <source>Print Map</source>
        <translation>Imprimir Mapa</translation>
    </message>
    <message>
        <source>&lt;div style=&apos;float: left;&apos;&gt;&lt;b&gt;Project Summary (&lt;a href=&apos;Clear&apos;&gt;clear&lt;/a&gt; project):&lt;/b&gt;&lt;/div&gt;</source>
        <translation type="obsolete">&lt;div style=&apos;float: left;&apos;&gt;&lt;b&gt;Resumen del proyecto (&lt;a href=&apos;Clear&apos;&gt;limpiar&lt;/a&gt; el proyecto):&lt;/b&gt;&lt;/div&gt;</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1321"/>
        <source>Currently there is %1 &lt;a href=&apos;Waypoints&apos;&gt;waypoint&lt;/a&gt;, </source>
        <translation>Actualmente hay %1 &lt;a href=&apos;Waypoints&apos;&gt;waypoint&lt;/a&gt;, </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1325"/>
        <source>Currently there are %1 &lt;a href=&apos;Waypoints&apos;&gt;waypoints&lt;/a&gt;, </source>
        <translation>Actualmente hay %1 &lt;a href=&apos;Waypoints&apos;&gt;waypoints&lt;/a&gt;, </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1330"/>
        <source>There are no waypoints, </source>
        <translation>No hay waypoints, </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1372"/>
        <source> %1 &lt;a href=&apos;Overlay&apos;&gt;overlay&lt;/a&gt;. </source>
        <translation>%1 &lt;a href=&apos;Overlay&apos;&gt;superposición&lt;/a&gt;. </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1376"/>
        <source> %1 &lt;a href=&apos;Overlay&apos;&gt;overlays&lt;/a&gt;. </source>
        <translation>%1 &lt;a href=&apos;Overlay&apos;&gt;superposiciones&lt;/a&gt;. </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1381"/>
        <source>no overlays. </source>
        <translation>sin superposiciones. </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1433"/>
        <source>Magellan</source>
        <translation>Magellan</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1571"/>
        <source>QLandkarte GT can query for new versions on start-up. If there is a new version available, it will display a short notice in the statusbar. To query for a new version QLandkarte GT has to connect to the server

http://www.qlandkarte.org/webservice/qlandkartegt.php

It won&apos;t transmit any private data other than needed for requesting a HTML page.

If you want QLandkarte GT to do this query now and in the future press &apos;Ok&apos;. Else press &apos;No&apos;.

You won&apos;t be bugged a second time unless you erase QLandkarte&apos;s configuration data.</source>
        <translation>QLandkarte GT puede comprobar si hay nueva versión al inicio. Si hay alguna nueva versión disponible, mostrará un pequeño aviso en la barra de estado. Para comprobar si hay una nueva versión QLandkarte GT se debe conectar al servidor:

http://www.qlandkarte.org/webservice/qlandkartegt.php

No transmitirá ninguna información privada más que la necesaria para solicitar una página HTML.

Si quiere que QLandkarteGT haga esta solicitud ahora y en el futuro, pulse &apos;Aceptar&apos;. En otro caso, pulse &apos;No&apos;.

No será molestado una segunda vez a menos que borre los datos de configuración de QLandkarte.</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1584"/>
        <source>Query for new version...</source>
        <translation>Comprobar nueva versión...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1621"/>
        <source>New QLandkarte GT %1 available</source>
        <translation>Nueva versión QLandkarte GT %1 disponible</translation>
    </message>
    <message>
        <source>A &lt;a href=&apos;Diary&apos;&gt;diary&lt;/a&gt; is loaded.</source>
        <translation type="obsolete">Un &lt;a href=&apos;Diary&apos;&gt;diario&lt;/a&gt; está cargado.</translation>
    </message>
    <message>
        <source>The diary (&lt;a href=&apos;Diary&apos;&gt;new&lt;/a&gt;) is empty.</source>
        <translation type="obsolete">El (&lt;a href=&apos;Diary&apos;&gt;nuevo&lt;/a&gt;) diario está vacío.</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1430"/>
        <source>QLandkarte M</source>
        <translation>QLandkarte M</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1437"/>
        <source>GPSD</source>
        <translation>GPSD</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1338"/>
        <source> %1 &lt;a href=&apos;Tracks&apos;&gt;track&lt;/a&gt;, </source>
        <translation> %1 &lt;a href=&apos;Tracks&apos;&gt;track&lt;/a&gt;, </translation>
    </message>
    <message>
        <source>Profiling</source>
        <translation type="obsolete">Profiling</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="517"/>
        <source>This will erase all workspace data like waypoints and tracks.</source>
        <translation>Esto eliminará todos los datos del área de trabajo, como waypoints y tracks.</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="586"/>
        <source>Save map as image ...</source>
        <translation>Guardar mapa como imagen ...</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="590"/>
        <source>Toggle toolview</source>
        <translation>Activar vista de herramientas</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="600"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="637"/>
        <source>Mor&amp;e</source>
        <translation>&amp;Más</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="obsolete">Rejilla</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="660"/>
        <source>http://FAQ</source>
        <translation>http://FAQ</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="661"/>
        <source>http://Help</source>
        <translation>http://Ayuda</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="662"/>
        <source>http://Support</source>
        <translation>http://Soporte</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="758"/>
        <location filename="../CMainWindow.cpp" line="809"/>
        <source>Select input files</source>
        <translation>Seleccionar archivos de entrada</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1342"/>
        <source> %1 &lt;a href=&apos;Tracks&apos;&gt;tracks&lt;/a&gt;, </source>
        <translation> %1 &lt;a href=&apos;Tracks&apos;&gt;tracks&lt;/a&gt;, </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1347"/>
        <source>no tracks, </source>
        <translation>sin tracks, </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1355"/>
        <source> %1 &lt;a href=&apos;Routes&apos;&gt;route&lt;/a&gt; and </source>
        <translation>%1 &lt;a href=&apos;Routes&apos;&gt;ruta&lt;/a&gt; y </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1359"/>
        <source> %1 &lt;a href=&apos;Routes&apos;&gt;routes&lt;/a&gt; and </source>
        <translation>%1 &lt;a href=&apos;Routes&apos;&gt;routes&lt;/a&gt; y </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="1364"/>
        <source>no routes and </source>
        <translation>sin rutas y </translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="605"/>
        <source>&amp;Map</source>
        <translation>&amp;Mapa</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="610"/>
        <source>&amp;Waypoint</source>
        <translation>&amp;Waypoint</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="615"/>
        <source>&amp;Track</source>
        <translation>&amp;Track</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="620"/>
        <source>&amp;Route</source>
        <translation>&amp;Ruta</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="625"/>
        <source>&amp;Live Log</source>
        <translation>&amp;Registro en vivo</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="630"/>
        <source>&amp;Overlay</source>
        <translation>&amp;Superposición</translation>
    </message>
    <message>
        <source>&amp;more</source>
        <translation type="obsolete">Má&amp;s</translation>
    </message>
    <message>
        <location filename="../CMainWindow.cpp" line="883"/>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CMap3D</name>
    <message>
        <location filename="../CMap3D.cpp" line="145"/>
        <source>3D / 2D</source>
        <translation>3D / 2D</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="150"/>
        <source>FPV / Rot.</source>
        <translation>FPV / Rot.</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="155"/>
        <source>Reset Light</source>
        <translation>Reiniciar luz</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="158"/>
        <source>Track on map</source>
        <translation>Ver Track en el Mapa</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="163"/>
        <source>POV on track</source>
        <translation>Ver PDV en el Mapa</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="180"/>
        <source>Help 3d</source>
        <translation>Ayuda 3D</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="439"/>
        <source>:/skybox/%1.bmp</source>
        <translation>:/skybox/%1.bmp</translation>
    </message>
    <message>
        <location filename="../CMap3D.cpp" line="1785"/>
        <source>Config</source>
        <translation>Configuración</translation>
    </message>
</context>
<context>
    <name>CMap3DWidget</name>
    <message>
        <location filename="../CMap3DWidget.cpp" line="167"/>
        <source>Flat / 3D Mode</source>
        <translation>Modo de Vuelo / 3D</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="172"/>
        <source>Show Track</source>
        <translation>Mostrar Track</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="177"/>
        <source>Track on Map</source>
        <translation>Ver Track en el Mapa</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="182"/>
        <source>Inc. Elevation</source>
        <translation>Aumentar elevación</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="185"/>
        <source>Dec. Elevation</source>
        <translation>Reducir Elevación</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="188"/>
        <source>Reset Elevation</source>
        <translation>Reiniciar Altura</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="191"/>
        <source>Reset light source</source>
        <translation>Reiniciar fuente de luz</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="328"/>
        <source>Add Waypoint ...</source>
        <translation>Añadir Waypoint ...</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="332"/>
        <source>Copy Pos. Waypoint</source>
        <translation>Copiar Pos. Waypoint</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="333"/>
        <source>Edit Waypoint...</source>
        <translation>Editar Waypoint...</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="335"/>
        <source>Delete Waypoint</source>
        <translation>Eliminar Waypoint</translation>
    </message>
    <message>
        <location filename="../CMap3DWidget.cpp" line="911"/>
        <source>:/skybox/%1.bmp</source>
        <translation>:/skybox/%1.bmp</translation>
    </message>
</context>
<context>
    <name>CMapCropStateCrop</name>
    <message>
        <location filename="../CDlgCropMap.cpp" line="370"/>
        <source>Cut area from files...</source>
        <translation>Recortar área de archivos...</translation>
    </message>
</context>
<context>
    <name>CMapCropStateOptimize</name>
    <message>
        <location filename="../CDlgCropMap.cpp" line="420"/>
        <source>Optimize file...</source>
        <translation>Optimizar archivo...</translation>
    </message>
    <message>
        <location filename="../CDlgCropMap.cpp" line="433"/>
        <source>nothing to do
</source>
        <translation>nada que hacer
</translation>
    </message>
</context>
<context>
    <name>CMapDB</name>
    <message>
        <location filename="../CMapDB.cpp" line="71"/>
        <source>--- No map ---</source>
        <translation>--- Sin mapa ---</translation>
    </message>
    <message>
        <source>--- OSM ---</source>
        <translation type="obsolete">--- OSM ---</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="524"/>
        <location filename="../CMapDB.cpp" line="1026"/>
        <location filename="../CMapDB.cpp" line="1070"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="524"/>
        <source>Only vector maps are valid overlays.</source>
        <translation>Solamente los mapas vectoriales son capas válidas.</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="953"/>
        <source>Map 3D...</source>
        <translation>Mapa 3D ...</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="941"/>
        <source>Edit Map</source>
        <translation>Editar Mapa</translation>
    </message>
    <message>
        <source>--- Tile Server ---</source>
        <translation type="obsolete">--- Servidor de Teselas ---</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="150"/>
        <source>Crash detected....</source>
        <translation>Detectado bloqueo....</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="150"/>
        <source>QLandkarte GT was terminated with a crash. This is really bad. A common reason for that is a bad map. Do you really want to load the last map?</source>
        <translation>QLandkarte GT terminó con un bloqueo. Esto es realmente malo. Una razón común para eso es un mapa erróneo. ¿Quiere realmente cargar el último mapa?</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="968"/>
        <source>Search Map</source>
        <translation>Buscar Mapa</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="982"/>
        <source>Sorry...</source>
        <translation>Lo siento...</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="982"/>
        <source>You can&apos;t select subareas from single file maps. Create a collection with F1-&gt;F6.</source>
        <translation>No puede seleccionar áreas de un solo archivo de mapas. Cree una colección con F1-&gt;F6.</translation>
    </message>
    <message>
        <location filename="../CMapDB.cpp" line="1070"/>
        <source>This map does not support this feature.</source>
        <translation>Este mapa no soporta esta característica.</translation>
    </message>
    <message>
        <source>You can&apos;t select subareas from single file maps.</source>
        <translation type="obsolete">No puede selecionar áreas a partir de un solo archivo de mapas.</translation>
    </message>
</context>
<context>
    <name>CMapDEM</name>
    <message>
        <location filename="../CMapDEM.cpp" line="115"/>
        <location filename="../CMapDEM.cpp" line="126"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapDEM.cpp" line="116"/>
        <source>Failed to load file: %1

</source>
        <translation>No se pudo cargar el archivo: %1</translation>
    </message>
    <message>
        <location filename="../CMapDEM.cpp" line="127"/>
        <source>Failed to load file: %1</source>
        <translation>No se pudo cargar el archivo: %1</translation>
    </message>
</context>
<context>
    <name>CMapDEMSlopeSetup</name>
    <message>
        <location filename="../CMapDEMSlopeSetup.cpp" line="104"/>
        <source>Grade %1</source>
        <translation>Grado %1</translation>
    </message>
</context>
<context>
    <name>CMapEditWidget</name>
    <message>
        <location filename="../CMapEditWidget.cpp" line="54"/>
        <source>Convert a TIFF into GeoTiff by geo referencing it.</source>
        <translation>Convertir un TIFF en GeoTiff georreferenciándolo.</translation>
    </message>
    <message>
        <location filename="../CMapEditWidget.cpp" line="66"/>
        <source>&lt;b style=&apos;color: red;&apos;&gt;Can&apos;t find the GDAL tools in your path. Make sure you have Installed GDAL and all related command line applications.&lt;/b&gt;</source>
        <translation>&lt;b style=&apos;color: red;&apos;&gt;No se encontraron las herramientas GDAL en ruta de comandos. Asegúrese de tener instalada la libreria GDAL y todos los comandos relacionados..&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../CMapEditWidget.cpp" line="70"/>
        <source>Fine tune offset of referenced file.</source>
        <translation>Ajuste fino del desplazamiento del archivo referenciado.</translation>
    </message>
    <message>
        <source>Create a GDAL WMS definition file.</source>
        <translation type="obsolete">Crear archivo de definicion GDAL WMS.</translation>
    </message>
    <message>
        <location filename="../CMapEditWidget.cpp" line="50"/>
        <source>Create map collection from existing geo-referenced files.</source>
        <translation>Crear conjunto de mapas a partir de archivos georreferenciados existentes.</translation>
    </message>
    <message>
        <location filename="../CMapEditWidget.cpp" line="41"/>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CMapExportStateCombineFiles</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1115"/>
        <source>Combine files for each level...</source>
        <translation>Cobinar archivos para cada nivel...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateConvColor</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1177"/>
        <source>Reduce color bands to 3 (RGB)...</source>
        <translation>Reducir bandas de color a 3 (RGB)...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateCutFiles</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1045"/>
        <source>Cut area from files...</source>
        <translation>Recortar área de archivos...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateGCM</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1370"/>
        <source>Create Garmin Custom Map...</source>
        <translation>Crear un Mapa Personalizado de Garmin...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateJNX</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1430"/>
        <source>Create Garmin JNX Map...</source>
        <translation>Crear un mapa JNX de Garmin...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateOptimize</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1304"/>
        <source>Optimize files...</source>
        <translation>Optimizar archivos...</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1317"/>
        <source>nothing to do
</source>
        <translation>nada que hacer
</translation>
    </message>
</context>
<context>
    <name>CMapExportStateRMAP</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1543"/>
        <source>Create TwoNav RMAP...</source>
        <translation>Crear TwoNav RMAP...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateRMP</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1599"/>
        <source>Create Magellan RMP Map...</source>
        <translation>Crear mapa Magellan RMP...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateReadTileCache</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1483"/>
        <source>Create GeoTiff from map cache...</source>
        <translation>Crear GeoTiff a partir de la caché de mapa...</translation>
    </message>
</context>
<context>
    <name>CMapExportStateReproject</name>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="1237"/>
        <source>Re-project files...</source>
        <translation>Reproyectar archivos...</translation>
    </message>
</context>
<context>
    <name>CMapGeoTiff</name>
    <message>
        <location filename="../CMapGeoTiff.cpp" line="58"/>
        <location filename="../CMapGeoTiff.cpp" line="72"/>
        <location filename="../CMapGeoTiff.cpp" line="97"/>
        <location filename="../CMapGeoTiff.cpp" line="127"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapGeoTiff.cpp" line="58"/>
        <location filename="../CMapGeoTiff.cpp" line="72"/>
        <source>Failed to load file: %1</source>
        <translation>Falló la carga del archivo: %1</translation>
    </message>
    <message>
        <location filename="../CMapGeoTiff.cpp" line="97"/>
        <source>File must be 8 bit palette or gray indexed.</source>
        <translation>El archivo debe tener una paleta de color de 8 bits o ser en escala de grises indexada.</translation>
    </message>
    <message>
        <location filename="../CMapGeoTiff.cpp" line="127"/>
        <source>No georeference information found.</source>
        <translation>No se encontró información de georreferenciación.</translation>
    </message>
    <message>
        <location filename="../CMapGeoTiff.cpp" line="203"/>
        <source>Overzoom x%1</source>
        <translation>Súper zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapGeoTiff.cpp" line="207"/>
        <source>Zoom level x%1</source>
        <translation>Nivel de zoom x%1</translation>
    </message>
    <message>
        <source>quadratic zoom</source>
        <translation type="obsolete">Zoom exponencial</translation>
    </message>
</context>
<context>
    <name>CMapJnx</name>
    <message>
        <source>Parameter</source>
        <translation type="obsolete">Parámetro</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Valor</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="229"/>
        <source>Product ID</source>
        <translation>ID de producto</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="230"/>
        <source>Top/Left</source>
        <translation>Superior/Izquierda</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="231"/>
        <source>Bottom/Right</source>
        <translation>Inferior/Derecha</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="251"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="252"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="253"/>
        <source>Z-Order</source>
        <translation>Z-Order</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="300"/>
        <source>Level</source>
        <translation>Nivel</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="300"/>
        <source>#Tiles</source>
        <translation>#Teselas</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="300"/>
        <source>Scale</source>
        <translation>Escala</translation>
    </message>
    <message>
        <location filename="../CMapJnx.cpp" line="300"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
</context>
<context>
    <name>CMapOSM</name>
    <message>
        <source>Overzoom x%1</source>
        <translation type="obsolete">Súper zoom x%1</translation>
    </message>
    <message>
        <source>Zoom level x%1</source>
        <translation type="obsolete">Nivel de zoom x%1</translation>
    </message>
    <message>
        <source>%1 %2</source>
        <translation type="obsolete">%1 %2</translation>
    </message>
    <message>
        <source>Map has been created by %1 under Creative Commons Attribution-ShareAlike 2.0 license</source>
        <translation type="obsolete">El mapa lo ha creado %1 bajo una licencia Creative Commons Attribution-ShareAlike 2.0</translation>
    </message>
    <message>
        <source>and has been downloaded from: %1</source>
        <translation type="obsolete">y se ha descargado desde: %1</translation>
    </message>
</context>
<context>
    <name>CMapQMAP</name>
    <message>
        <location filename="../CMapQMAP.cpp" line="61"/>
        <source>Quadratic zoom %1</source>
        <translation>Zoom exponencial %1</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="61"/>
        <source>enabled</source>
        <translation>activado</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="61"/>
        <source>disabled</source>
        <translation>desactivado</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="62"/>
        <source>Map Level</source>
        <translation>Nivel de Mapa</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="62"/>
        <source>Zoom Level</source>
        <translation>Nivel de Zoom</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="62"/>
        <source>Files</source>
        <translation>Archivos</translation>
    </message>
    <message>
        <source>Parameter</source>
        <translation type="obsolete">Parámetro</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="obsolete">Valor</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="94"/>
        <source>Top/Left</source>
        <translation>Superior/Izquierda</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="95"/>
        <source>Bottom/Right</source>
        <translation>Inferior/Derecha</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="116"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="119"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <source>quadratic zoom</source>
        <translation type="obsolete">zoom exponencial</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="255"/>
        <source>Overzoom x%1</source>
        <translation>Súper zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapQMAP.cpp" line="259"/>
        <source>Zoom level x%1</source>
        <translation>Nivel de zoom x%1</translation>
    </message>
</context>
<context>
    <name>CMapQMAPExport</name>
    <message>
        <source>Select ouput path...</source>
        <translation type="obsolete">Seleccionar el directorio de salida...</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="620"/>
        <source>Error ...</source>
        <translation>Error ...</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="519"/>
        <source>
Canceled by user&apos;s request.
</source>
        <translation>
Cancelado a petición del usuario.
</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="136"/>
        <location filename="../CMapQMAPExport.cpp" line="137"/>
        <source>Please enter a string</source>
        <translation>Por favor introduzca una cadena</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="386"/>
        <source>Select copyright notice...</source>
        <translation>Seleccione el aviso de copyright...</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="386"/>
        <source>text file (*.txt)</source>
        <translation>fichero de texto (*.txt)</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="535"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="550"/>
        <source>Unknown map format.</source>
        <translation>Formato de mapa desconocido.</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="620"/>
        <source>Failed to read %1</source>
        <translation>Fallo al leer %1</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="941"/>
        <source>*** done ***
</source>
        <translation>*** hecho ***
</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="944"/>
        <source>Warnings. See &quot;Details&quot; for more information.
</source>
        <translation>Atención. Vea &quot;Detalles&quot; para más información.
</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="948"/>
        <location filename="../CMapQMAPExport.cpp" line="979"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="956"/>
        <source>Step %1/%2,</source>
        <translation>Paso %1/%2,</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="957"/>
        <location filename="../CMapQMAPExport.cpp" line="985"/>
        <source>Job %1/%2 - </source>
        <translation>Trabajo %1/%2 - </translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="970"/>
        <source>!!! failed !!!
</source>
        <translation>¡¡¡ falló !!!
</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="972"/>
        <source>Failed. See &quot;Details&quot; for more information.</source>
        <translation>Falló. Vea &quot;Detalles&quot; para más información.</translation>
    </message>
    <message>
        <location filename="../CMapQMAPExport.cpp" line="991"/>
        <source>Select output path...</source>
        <translation>Seleccionar ruta de salida...</translation>
    </message>
    <message>
        <source>--- finished ---
</source>
        <translation type="obsolete">--- finalizado ---
</translation>
    </message>
    <message>
        <source>Compress data to  %1
</source>
        <translation type="obsolete">Comprimir datos en  %1
</translation>
    </message>
</context>
<context>
    <name>CMapRaster</name>
    <message>
        <location filename="../CMapRaster.cpp" line="42"/>
        <location filename="../CMapRaster.cpp" line="54"/>
        <location filename="../CMapRaster.cpp" line="61"/>
        <location filename="../CMapRaster.cpp" line="84"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapRaster.cpp" line="42"/>
        <location filename="../CMapRaster.cpp" line="54"/>
        <source>Failed to load file: %1</source>
        <translation>Fallo al cargar el archivo: %1</translation>
    </message>
    <message>
        <location filename="../CMapRaster.cpp" line="61"/>
        <location filename="../CMapRaster.cpp" line="84"/>
        <source>File must be 8 bit palette or gray indexed.</source>
        <translation>El archivo debe tener una paleta de color de 8 bits o ser en escala de grises indexada.</translation>
    </message>
    <message>
        <location filename="../CMapRaster.cpp" line="216"/>
        <source>Overzoom x%1</source>
        <translation>Súper zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapRaster.cpp" line="220"/>
        <source>Zoom level x%1</source>
        <translation>Nivel de zoom x%1</translation>
    </message>
</context>
<context>
    <name>CMapRmap</name>
    <message>
        <location filename="../CMapRmap.cpp" line="51"/>
        <location filename="../CMapRmap.cpp" line="60"/>
        <location filename="../CMapRmap.cpp" line="128"/>
        <location filename="../CMapRmap.cpp" line="145"/>
        <location filename="../CMapRmap.cpp" line="166"/>
        <location filename="../CMapRmap.cpp" line="188"/>
        <location filename="../CMapRmap.cpp" line="210"/>
        <location filename="../CMapRmap.cpp" line="238"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="51"/>
        <source>This is not a TwoNav RMAP file.</source>
        <translation>Este no es un archivo TwoNav RMAP.</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="60"/>
        <source>Unknown sub-format.</source>
        <translation>Subformato desconocido.</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="128"/>
        <source>Unknown version.</source>
        <translation>Versión desconocida.</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="145"/>
        <location filename="../CMapRmap.cpp" line="166"/>
        <location filename="../CMapRmap.cpp" line="188"/>
        <location filename="../CMapRmap.cpp" line="210"/>
        <source>Failed to read reference point.</source>
        <translation>Falló al leer el punto de referencia.</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="238"/>
        <source>Unknown projection and datum (%1%2).</source>
        <translation>Proyección y datum desconocido (%1%2).</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="638"/>
        <source>Overzoom x%1</source>
        <translation>Súper zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapRmap.cpp" line="642"/>
        <source>Zoom level x%1</source>
        <translation>Nivel de zoom x%1</translation>
    </message>
</context>
<context>
    <name>CMapRmp</name>
    <message>
        <location filename="../CMapRmp.cpp" line="180"/>
        <location filename="../CMapRmp.cpp" line="197"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapRmp.cpp" line="180"/>
        <source>Failed to open: %1.</source>
        <translation>Fallo al abrir %1.</translation>
    </message>
    <message>
        <location filename="../CMapRmp.cpp" line="197"/>
        <source>This is not a Magellan RMP file: %1</source>
        <translation>Este no es un archivo Magellan RMP: %1</translation>
    </message>
</context>
<context>
    <name>CMapSearchThread</name>
    <message>
        <location filename="../CMapSearchThread.cpp" line="68"/>
        <source>Start...</source>
        <translation>Iniciar...</translation>
    </message>
    <message>
        <location filename="../CMapSearchThread.cpp" line="89"/>
        <source>Error. This only works on a *.qmap map collection.</source>
        <translation>Error. Esto sólo funciona con un conjunto de mapas *.qmap.</translation>
    </message>
    <message>
        <location filename="../CMapSearchThread.cpp" line="124"/>
        <source>Canceled!</source>
        <translation>¡Cancelado!</translation>
    </message>
    <message>
        <location filename="../CMapSearchThread.cpp" line="147"/>
        <source>Parsing...</source>
        <translation>Analizando...</translation>
    </message>
    <message>
        <location filename="../CMapSearchThread.cpp" line="154"/>
        <source>Done! Found %1 items.</source>
        <translation>¡Finalizado! Encontrados %1 elementos.</translation>
    </message>
</context>
<context>
    <name>CMapSearchWidget</name>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="95"/>
        <location filename="../CMapSearchWidget.cpp" line="248"/>
        <location filename="../CMapSearchWidget.cpp" line="267"/>
        <source>No mask selected.</source>
        <translation>No se ha seleccionado máscara.</translation>
    </message>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="101"/>
        <source>Symbols</source>
        <translation>Símbolos</translation>
    </message>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="149"/>
        <source>%2 %1</source>
        <translation>%2 %1</translation>
    </message>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="199"/>
        <source>Missing name...</source>
        <translation>Falta el nombre...</translation>
    </message>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="199"/>
        <source>Please provide a symbol name to save the symbol.</source>
        <translation>Por favor añada un nombre al símbolo para guardarlo.</translation>
    </message>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="279"/>
        <source>no mask</source>
        <translation>sin máscara</translation>
    </message>
    <message>
        <location filename="../CMapSearchWidget.cpp" line="331"/>
        <source>No area selected.</source>
        <translation>No se ha seleccionado área.</translation>
    </message>
    <message>
        <source>Found %1 items</source>
        <translation type="obsolete">Encontrados %1 elementos</translation>
    </message>
</context>
<context>
    <name>CMapSelectionRaster</name>
    <message>
        <location filename="../CMapSelectionRaster.cpp" line="234"/>
        <source>Tiles: #%1</source>
        <translation>Teselas: #%1</translation>
    </message>
</context>
<context>
    <name>CMapTDB</name>
    <message>
        <location filename="../CMapTDB.cpp" line="315"/>
        <source>POI labels</source>
        <translation>Etiquetas de puntos de interés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="321"/>
        <location filename="../CMapTDB.cpp" line="550"/>
        <location filename="../CMapTDB.cpp" line="673"/>
        <location filename="../CMapTDB.cpp" line="754"/>
        <source>Night</source>
        <translation>Noche</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="327"/>
        <source>Detail  5</source>
        <translation>Detalles  5</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="328"/>
        <source>Detail  4</source>
        <translation>Detalles  4</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="329"/>
        <source>Detail  3</source>
        <translation>Detalles  3</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="330"/>
        <source>Detail  2</source>
        <translation>Detalles  2</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="331"/>
        <source>Detail  1</source>
        <translation>Detalles  1</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="332"/>
        <source>Detail  0</source>
        <translation>Detalles  0</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="333"/>
        <source>Detail -1</source>
        <translation>Detalles -1</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="334"/>
        <source>Detail -2</source>
        <translation>Detalles -2</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="335"/>
        <source>Detail -3</source>
        <translation>Detalles -3</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="336"/>
        <source>Detail -4</source>
        <translation>Detalles -4</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="337"/>
        <source>Detail -5</source>
        <translation>Detalles -5</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="487"/>
        <source>Level: %1 Bits: %2 On basmap: %3</source>
        <translation>Nivel: %1 Bits: %2 En mapa base: %3</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="505"/>
        <source>missing</source>
        <translation>falta</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="547"/>
        <location filename="../CMapTDB.cpp" line="670"/>
        <location filename="../CMapTDB.cpp" line="751"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="548"/>
        <location filename="../CMapTDB.cpp" line="671"/>
        <location filename="../CMapTDB.cpp" line="752"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="549"/>
        <location filename="../CMapTDB.cpp" line="672"/>
        <location filename="../CMapTDB.cpp" line="753"/>
        <source>Day</source>
        <translation>Día</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="965"/>
        <source>Unspecified</source>
        <translation>No especificado</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="966"/>
        <source>French</source>
        <translation>Francés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="967"/>
        <source>German</source>
        <translation>Alemán</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="968"/>
        <source>Dutch</source>
        <translation>Holandés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="969"/>
        <source>English</source>
        <translation>Inglés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="970"/>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="971"/>
        <source>Finnish</source>
        <translation>Finlandés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="972"/>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="973"/>
        <source>Spanish</source>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="974"/>
        <source>Basque</source>
        <translation>Euskera</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="975"/>
        <source>Catalan</source>
        <translation>Catalán</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="976"/>
        <source>Galician</source>
        <translation>Gallego</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="977"/>
        <source>Welsh</source>
        <translation>Galés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="978"/>
        <source>Gaelic</source>
        <translation>Gaélico</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="979"/>
        <source>Danish</source>
        <translation>Danés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="980"/>
        <source>Norwegian</source>
        <translation>Noruego</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="981"/>
        <source>Portuguese</source>
        <translation>Portugués</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="982"/>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="983"/>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="984"/>
        <source>Croatian</source>
        <translation>Croata</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="985"/>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="986"/>
        <source>Polish</source>
        <translation>Polaco</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="987"/>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="988"/>
        <source>Greek</source>
        <translation>Griego</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="989"/>
        <source>Slovenian</source>
        <translation>Esloveno</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="990"/>
        <source>Russian</source>
        <translation>Ruso</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="991"/>
        <source>Estonian</source>
        <translation>Estonio</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="992"/>
        <source>Latvian</source>
        <translation>Letón</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="993"/>
        <source>Romanian</source>
        <translation>Rumano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="994"/>
        <source>Albanian</source>
        <translation>Albanés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="995"/>
        <source>Bosnian</source>
        <translation>Bosnio</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="996"/>
        <source>Lithuanian</source>
        <translation>Lituano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="997"/>
        <source>Serbian</source>
        <translation>Serbio</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="998"/>
        <source>Macedonian</source>
        <translation>Macedonio</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="999"/>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1056"/>
        <source>Major highway</source>
        <translation>Autopista/Autovía</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1057"/>
        <source>Principal highway</source>
        <translation>Carretera Nacional</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1058"/>
        <source>Other highway</source>
        <translation>Carretera autonómica de 1º orden</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1059"/>
        <source>Arterial road</source>
        <translation>Carretera autonómica 2º orden</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1060"/>
        <source>Collector road</source>
        <translation>Carretera</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1061"/>
        <source>Residential street</source>
        <translation>Calle residencial</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1062"/>
        <source>Alley/Private road</source>
        <translation>Callejón/Camino Privado</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1063"/>
        <source>Highway ramp, low speed</source>
        <translation>Salida autopista</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1064"/>
        <source>Highway ramp, high speed</source>
        <translation>Acceso autopista</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1065"/>
        <source>Unpaved road</source>
        <translation>Pista sin asfaltar</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1066"/>
        <source>Major highway connector</source>
        <translation>Intersección carretera nacional</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1067"/>
        <source>Roundabout</source>
        <translation>Rotonda</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1068"/>
        <source>Railroad</source>
        <translation>Ferrocarril</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1069"/>
        <source>Shoreline</source>
        <translation>Costa</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1070"/>
        <source>Trail</source>
        <translation>Sendero</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1071"/>
        <source>Stream</source>
        <translation>Arroyo</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1072"/>
        <source>Time zone</source>
        <translation>Zona horaria</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1073"/>
        <location filename="../CMapTDB.cpp" line="1074"/>
        <source>Ferry</source>
        <translation>Ferry</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1075"/>
        <source>State/province border</source>
        <translation>Límite Comunidad/Provincia</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1076"/>
        <source>County/parish border</source>
        <translation>Límite comarca/parroquia</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1077"/>
        <source>International border</source>
        <translation>Frontera internacional</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1078"/>
        <source>River</source>
        <translation>Río</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1079"/>
        <source>Minor land contour</source>
        <translation>Curva de nivel menor</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1080"/>
        <source>Intermediate land contour</source>
        <translation>Curva de nivel intermedia</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1081"/>
        <source>Major land contour</source>
        <translation>Curva de nivel maestra</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1082"/>
        <source>Minor depth contour</source>
        <translation>Curva batimétrica menor</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1172"/>
        <source>Cemetery</source>
        <translation>Cementerio</translation>
    </message>
    <message>
        <source>Minor deph contour</source>
        <translation type="obsolete">Curva batimétrica menor</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1083"/>
        <source>Intermediate depth contour</source>
        <translation>Curva batimétrica intermedia</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1084"/>
        <source>Major depth contour</source>
        <translation>Curva batimétrica maestra</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1085"/>
        <source>Intermittent stream</source>
        <translation>Corriente no permanente</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1086"/>
        <location filename="../CMapTDB.cpp" line="1168"/>
        <source>Airport runway</source>
        <translation>Pista de aterrizaje</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1087"/>
        <source>Pipeline</source>
        <translation>Tubería</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1088"/>
        <source>Powerline</source>
        <translation>Línea eléctrica</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1089"/>
        <source>Marine boundary</source>
        <translation>Línea de costa</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1090"/>
        <source>Hazard boundary</source>
        <translation>Límite de peligro</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1155"/>
        <source>Large urban area (&amp;gt;200K)</source>
        <translation>Población grande (&amp;gt;200K)</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1156"/>
        <source>Small urban area (&amp;lt;200K)</source>
        <translation>Población pequeña (&amp;lt;200K)</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1157"/>
        <source>Rural housing area</source>
        <translation>Área rural habitada</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1158"/>
        <source>Military base</source>
        <translation>Base militar</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1159"/>
        <source>Parking lot</source>
        <translation>Aparcamiento (en superficie)</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1160"/>
        <source>Parking garage</source>
        <translation>Aparcamiento (bajo techo)</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1161"/>
        <source>Airport</source>
        <translation>Aeropuerto</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1162"/>
        <source>Shopping center</source>
        <translation>Centro de compras</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1163"/>
        <source>Marina</source>
        <translation>Puerto deportivo</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1164"/>
        <source>University/College</source>
        <translation>Universidad</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1165"/>
        <source>Hospital</source>
        <translation>Hospital</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1166"/>
        <source>Industrial complex</source>
        <translation>Complejo industrial</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1167"/>
        <source>Reservation</source>
        <translation>Reserva natural</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1169"/>
        <source>Man-made area</source>
        <translation>Área construida por el hombre</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1170"/>
        <source>Sports complex</source>
        <translation>Complejo deportivo</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1171"/>
        <source>Golf course</source>
        <translation>Campo de golf</translation>
    </message>
    <message>
        <source>Cemetary</source>
        <translation type="obsolete">Cementerio</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1173"/>
        <location filename="../CMapTDB.cpp" line="1174"/>
        <location filename="../CMapTDB.cpp" line="1175"/>
        <source>National park</source>
        <translation>Parque nacional</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1176"/>
        <source>City park</source>
        <translation>Parque urbano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1177"/>
        <location filename="../CMapTDB.cpp" line="1178"/>
        <location filename="../CMapTDB.cpp" line="1179"/>
        <source>State park</source>
        <translation>Parque estatal</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1180"/>
        <source>Forest</source>
        <translation>Bosque</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1181"/>
        <source>Ocean</source>
        <translation>Océano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1182"/>
        <location filename="../CMapTDB.cpp" line="1184"/>
        <location filename="../CMapTDB.cpp" line="1194"/>
        <source>Blue (unknown)</source>
        <translation>Azul (desconocido)</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1183"/>
        <source>Sea</source>
        <translation>Mar</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1185"/>
        <location filename="../CMapTDB.cpp" line="1186"/>
        <location filename="../CMapTDB.cpp" line="1193"/>
        <source>Large lake</source>
        <translation>Lago grande</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1187"/>
        <location filename="../CMapTDB.cpp" line="1188"/>
        <source>Medium lake</source>
        <translation>Lago mediano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1189"/>
        <location filename="../CMapTDB.cpp" line="1190"/>
        <source>Small lake</source>
        <translation>Lago pequeño</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1191"/>
        <location filename="../CMapTDB.cpp" line="1192"/>
        <source>Major lake</source>
        <translation>Lago principal</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1195"/>
        <source>Major River</source>
        <translation>Río principal</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1196"/>
        <source>Large River</source>
        <translation>Río grande</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1197"/>
        <source>Medium River</source>
        <translation>Río Mediano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1198"/>
        <source>Small River</source>
        <translation>Río Pequeño</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1201"/>
        <source>Intermittent water</source>
        <translation>Curso intermitente de agua</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1202"/>
        <source>Wetland/Swamp</source>
        <translation>Humedales/Pantano</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1203"/>
        <source>Glacier</source>
        <translation>Glaciar</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1204"/>
        <source>Orchard/Plantation</source>
        <translation>Huerto/Plantación</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1205"/>
        <source>Scrub</source>
        <translation>Matorral</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1206"/>
        <source>Tundra</source>
        <translation>Tundra</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1207"/>
        <source>Flat</source>
        <translation>Llanura</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1208"/>
        <source>???</source>
        <translation>¿¿¿???</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1227"/>
        <source>No basemap projection. That shouldn&apos;t happen.</source>
        <translation>No hay proyección para el mapa base. Eso no debería ocurrir.</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1481"/>
        <source>&lt;p&gt;&lt;b&gt;However ...&lt;/b&gt;&lt;/p&gt;&lt;p&gt;as I can read the basemap, and the information from the *tdb file,&lt;br&gt;I am able to let you select the map tiles for upload. To do this I&lt;br/&gt;need the unlock key (25 digits) for this map, as it has to be uploaded&lt;br/&gt;to the unit together with the map.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Sin embargo ...&lt;/b&gt;como puedo leer el mapa base y la información del archivo *tdb,&lt;br&gt;puedo dejarle seleccionar las teselas del mapa que cargar. Para hacer esto&lt;br/&gt;necesito la clave de desbloqueo (25 dígitos) para este mapa, ya que tiene que ser cargada en el aparato junto con el mapa.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1507"/>
        <source>&lt;p&gt;Failed to load file:&lt;/p&gt;&lt;p&gt;%1&lt;/p&gt;&lt;p&gt;However, if the basemap is still old format I am able to let you select the map tiles for upload&lt;/p&gt;</source>
        <translation>&lt;p&gt;Fallo al leer el archivo:&lt;/p&gt;&lt;p&gt;%1&lt;/p&gt;&lt;p&gt;Sin embargo, si el mapa base todavía tiene un formato antiguo puedo dejarle seleccionar las teselas del mapa que cargar&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="3525"/>
        <source>none</source>
        <translation>ninguno</translation>
    </message>
    <message>
        <source>No big endian..</source>
        <translation type="obsolete">Pas de big endian..</translation>
    </message>
    <message>
        <source>*tdb import has not been ported to big endian architectures, yet.</source>
        <translation type="obsolete">La importaciónde archivos *TDB no ha sido portada a las arquitecturas big endian, todavia.</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1359"/>
        <source>Select Base Map for </source>
        <translation>Seleccionar el mapa base para </translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1478"/>
        <location filename="../CMapTDB.cpp" line="1506"/>
        <location filename="../CMapTDB.cpp" line="1521"/>
        <location filename="../CMapTDB.cpp" line="1541"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="1480"/>
        <source>However ...</source>
        <translation>Sin embargo ...</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;However ...&lt;/b&gt;&lt;/p&gt;&lt;p&gt;as I can read the basemap, and the information from the *tdb file,&lt;br/&gt;I am able to let you select the map tiles for upload. To do this I&lt;br/&gt;need the unlock key (25 digits) for this map, as it has to be uploaded&lt;br/&gt;to the unit together with the map.&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;b&gt;Sin embargo ...&lt;/b&gt;&lt;/p&gt;&lt;p&gt;como puedo leer el mapa principal y el archivo de información *.tdb,&lt;br/&gt;puedo dejarle seleccionar las teselas del mapa para cargar. Para hacer esto&lt;br/&gt;necesito el codigo de desbloqueo (25 digitos) para este mapa, puesto que se tiene que cargar&lt;br/&gt;en la unidad junto con el mapa.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>details %1</source>
        <translation type="obsolete">detalles %1</translation>
    </message>
    <message>
        <source>details +%1</source>
        <translation type="obsolete">detalles +%1</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="3054"/>
        <location filename="../CMapTDB.cpp" line="3062"/>
        <location filename="../CMapTDB.cpp" line="3066"/>
        <location filename="../CMapTDB.cpp" line="3071"/>
        <location filename="../CMapTDB.cpp" line="3118"/>
        <location filename="../CMapTDB.cpp" line="3126"/>
        <location filename="../CMapTDB.cpp" line="3130"/>
        <location filename="../CMapTDB.cpp" line="3135"/>
        <source>Point of Interest</source>
        <translation>Punto de interés</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="3261"/>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="3420"/>
        <location filename="../CMapTDB.cpp" line="3429"/>
        <location filename="../CMapTDB.cpp" line="3436"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <source>Warning...</source>
        <translation type="obsolete">Peligro...</translation>
    </message>
    <message>
        <source>This is a typ file with unknown polygon encoding. Please report!</source>
        <translation type="obsolete">Esto es un archivo TYP con codificación de poligonos desconocida, ¡Por favor comuniquelo!</translation>
    </message>
    <message>
        <source>This is a typ file with unknown polyline encoding. Please report!</source>
        <translation type="obsolete">Esto es un archivo TYP con codificación de lineas desconocida, ¡Por favor comuniquelo!</translation>
    </message>
    <message>
        <source>This is a typ file with unknown point encoding. Please report!</source>
        <translation type="obsolete">Esto es un archivo TYP con codificación de puntos desconocida, ¡Por favor comuniquelo!</translation>
    </message>
    <message>
        <location filename="../CMapTDB.cpp" line="457"/>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CMapTms</name>
    <message>
        <location filename="../CMapTms.cpp" line="144"/>
        <location filename="../CMapTms.cpp" line="154"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="144"/>
        <source>Failed to open %1</source>
        <translation>Fallo al abrir %1</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="154"/>
        <source>Failed to read: %1
line %2, column %3:
 %4</source>
        <translation>Falló al leer: %1
línea %2, columna %3:
 %4</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="410"/>
        <source>Overzoom x%1</source>
        <translation>Súper zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="414"/>
        <source>Zoom level x%1</source>
        <translation>Nivel de zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="436"/>
        <location filename="../CMapTms.cpp" line="440"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="436"/>
        <source>Copyright notice is missing.</source>
        <translation>Falta el aviso de copyright.</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="624"/>
        <source>Map loaded.</source>
        <translation>Mapa cargado.</translation>
    </message>
    <message>
        <location filename="../CMapTms.cpp" line="630"/>
        <source>Wait for %1 tiles.</source>
        <translation>Esperar por %1 teselas.</translation>
    </message>
</context>
<context>
    <name>CMapToolWidget</name>
    <message>
        <location filename="../CMapToolWidget.cpp" line="45"/>
        <source>Maps</source>
        <translation>Mapas</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="50"/>
        <source>Reload map...</source>
        <translation>Recargar mapa...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="51"/>
        <source>Add DEM...</source>
        <translation>Añadir archivo de alturas (DEM)...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="52"/>
        <source>Del. DEM...</source>
        <translation>Borrar archivo de alturas (DEM)...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="53"/>
        <source>Info/Config</source>
        <translation>Información/Configuración</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="54"/>
        <location filename="../CMapToolWidget.cpp" line="71"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Add url...</source>
        <translation type="obsolete">Añadir url...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="55"/>
        <source>Add TMS map...</source>
        <translation>Añadir mapa TMS...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="70"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="79"/>
        <source>Stream</source>
        <translation>Stream</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="81"/>
        <source>Raster</source>
        <translation>Raster</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="83"/>
        <source>Vector</source>
        <translation>Vector</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="137"/>
        <source>BirdsEye/JNX</source>
        <translation>BirdsEye/JNX</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="142"/>
        <source>TwoNav/RMAP</source>
        <translation>TwoNav/RMAP</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="147"/>
        <source>Magellan/RMP</source>
        <translation>Magellan/RMP</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="152"/>
        <source>map stack/QMAP</source>
        <translation>pila de mapas/QMAP</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="158"/>
        <source>Garmin/TDB/IMG</source>
        <translation>Garmin/TDB/IMG</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="163"/>
        <source>tile server</source>
        <translation>servidor de teselas</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="168"/>
        <source>map server</source>
        <translation>servidor de mapa</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="173"/>
        <source>various projections</source>
        <translation>varias proyecciones</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="184"/>
        <source>selected map</source>
        <translation>mapa seleccionado</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="190"/>
        <source>use a single click to deactivate map as overlay</source>
        <translation>utilice un click simple para desactivar mapa como superposición</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="196"/>
        <source>use a single click to activate map as overlay</source>
        <translation>utilice un click simple para activar mapa como superposición</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="494"/>
        <source>Error export maps...</source>
        <translation>Error al exportar los mapas...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="494"/>
        <source>You need to have the GDAL toolchain installed in your path.</source>
        <translation>Necesita tener instaladas las herramientas GDAL en su ruta de comandos.</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="514"/>
        <source>Select DEM file...</source>
        <translation>Seleccionar archivo de alturas (DEM)...</translation>
    </message>
    <message>
        <location filename="../CMapToolWidget.cpp" line="514"/>
        <source>16bit Srtm Data (*.tif *.tiff *.hgt *.blx *.vrt)</source>
        <translation>Datos SRTM de 16bit (*.tif *.tiff *.hgt *.blx *.vrt)</translation>
    </message>
    <message>
        <source>16bit Srtm Data (*.tif *.tiff *.hgt *.blx)</source>
        <translation type="obsolete">Datos SRTM de 16 bit (*-tif *.tiff *.hgt *.blx)</translation>
    </message>
    <message>
        <source>16bit Srtm Data (*.tif *.tiff *.hgt)</source>
        <translatorcomment>Fuente: wikipedia
SRTM = acrónimo en inglés de la &quot;Misión topográfica Radar Shuttle&quot;. Es una misión para obtener un modelo digital de elevación de la zona del globo terráqueo entre 56 °S a 60 °N, de modo que genere una completa base de cartas topográficas digitales de alta resolución de la Tierra.</translatorcomment>
        <translation type="obsolete">Datos SRTM de 16bits (*.tif *.tiff *.hgt)</translation>
    </message>
    <message>
        <source>16bit GeoTiff (*.tif)</source>
        <translation type="obsolete">16bit GeoTiff (*.tif)</translation>
    </message>
    <message>
        <source>Configure</source>
        <translation type="obsolete">Configurar</translation>
    </message>
</context>
<context>
    <name>CMapWMS</name>
    <message>
        <source>Error...</source>
        <translation type="obsolete">Error...</translation>
    </message>
    <message>
        <source>Failed to load file: %1</source>
        <translation type="obsolete">Fallo al cargar el archivo: %1</translation>
    </message>
    <message>
        <source>No georeference information found.</source>
        <translation type="obsolete">No se encontró información de georreferenciación.</translation>
    </message>
    <message>
        <source>Overzoom x%1</source>
        <translation type="obsolete">Súper zoom x%1</translation>
    </message>
    <message>
        <source>Zoom level x%1</source>
        <translation type="obsolete">Nivel de zoom x%1</translation>
    </message>
</context>
<context>
    <name>CMapWms</name>
    <message>
        <location filename="../CMapWms.cpp" line="63"/>
        <location filename="../CMapWms.cpp" line="73"/>
        <location filename="../CMapWms.cpp" line="123"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="63"/>
        <source>Failed to open %1</source>
        <translation>Fallo al abrir %1</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="73"/>
        <source>Failed to read: %1
line %2, column %3:
 %4</source>
        <translation>No se pudo leer: %1
línea %2, columna %3:
 %4</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="123"/>
        <source>Unknown projection %1</source>
        <translation>Proyección desconocida %1</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="463"/>
        <source>Overzoom x%1</source>
        <translation>Súper zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="467"/>
        <source>Zoom level x%1</source>
        <translation>Nivel de zoom x%1</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="489"/>
        <location filename="../CMapWms.cpp" line="493"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="489"/>
        <source>Copyright notice is missing. Use &lt;copyright&gt; tag in &lt;service&gt; secton to supply a copyright notice.</source>
        <translation>Falta el aviso de copyright. Utilice la etiqueta &lt;copyright&gt; en la sección &lt;service&gt; para proporcionar el aviso de copyright.</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="649"/>
        <source>Map loaded.</source>
        <translation>Mapa cargado.</translation>
    </message>
    <message>
        <location filename="../CMapWms.cpp" line="655"/>
        <source>Wait for %1 tiles.</source>
        <translation>Esperar por %1 teselas.</translation>
    </message>
</context>
<context>
    <name>CMegaMenu</name>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>&lt;b&gt;Main ...&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Menu principal ...&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Main (More) ...&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Menu principal (Plus) ...&lt;/b&gt;</translation>
    </message>
    <message>
        <source>From Images...</source>
        <translation type="obsolete">A partir d&apos;images...</translation>
    </message>
    <message>
        <location filename="../CMegaMenu.cpp" line="78"/>
        <source>%1 ...</source>
        <translation>%1 ...</translation>
    </message>
</context>
<context>
    <name>CMenus</name>
    <message>
        <location filename="../CMenus.cpp" line="102"/>
        <source>ActionGroup %1 not defined. Please fix.</source>
        <translation>Grupo de acción %1 no definido. Por favor arréglelo.</translation>
    </message>
    <message>
        <location filename="../CMenus.cpp" line="190"/>
        <location filename="../CMenus.cpp" line="204"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../CMenus.cpp" line="191"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="../CMenus.cpp" line="205"/>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
</context>
<context>
    <name>CMouseMoveMap</name>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="105"/>
        <location filename="../CMouseMoveMap.cpp" line="149"/>
        <source>Move map</source>
        <translation>Mover Mapa</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="203"/>
        <source>Reload Map</source>
        <translation>Recargar mapa</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="210"/>
        <source>Copy Pos. Waypoint</source>
        <translation>Copiar Pos. Waypoint</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="211"/>
        <source>Edit Waypoint ...</source>
        <translation>Editar Waypoint...</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="215"/>
        <source>Move Waypoint</source>
        <translation>Desplazar Waypoint</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="220"/>
        <source>Delete Waypoint</source>
        <translation>Eliminar Waypoint</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="226"/>
        <source>Add Waypoint ...</source>
        <translation>Añadir Waypoint ...</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="232"/>
        <source>Open Pos. with Google Maps</source>
        <translation>Abrir Posición en Google Maps</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="233"/>
        <source>Copy Pos. Trackpoint</source>
        <translation>Copiar Posición del punto del track</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="234"/>
        <source>Edit Track ...</source>
        <translation>Editar track...</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="235"/>
        <source>Split Track ...</source>
        <translation>Dividir track...</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="249"/>
        <source>Grid: %1</source>
        <translation>Rejilla: %1</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="254"/>
        <source>Grid: N %1m E %2m</source>
        <translation>Rejilla: N %1m E %2m</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="265"/>
        <source>Map: N %1m E %2m</source>
        <translation>Mapa: N %1m E %2m</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="288"/>
        <source>Crop: set pos. 1</source>
        <translation>Recortar: asignar pos. 1</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="295"/>
        <source>Crop map: %1x%2 w:%3 h:%4</source>
        <translation>Recortar mapa: %1x%2 anchura:%3 altura:%4</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="337"/>
        <location filename="../CMouseMoveMap.cpp" line="352"/>
        <source>N %1m E %2m</source>
        <translation>N %1m E %2m</translation>
    </message>
    <message>
        <location filename="../CMouseMoveMap.cpp" line="284"/>
        <source>Pixel %1x%2 (%3)</source>
        <translation>Píxel %1x%2 (%3)</translation>
    </message>
    <message>
        <source>Pos1 -&gt; Pos %1x%2 w:%3 h:%4</source>
        <translation type="obsolete">Pos1 -&gt; Pos %1x%2 anchura:%3 altura:%4</translation>
    </message>
    <message>
        <source>Set as Pos1</source>
        <translation type="obsolete">Asignar como Pos1</translation>
    </message>
</context>
<context>
    <name>CMouseRefPoint</name>
    <message>
        <location filename="../CMouseRefPoint.cpp" line="193"/>
        <location filename="../CMouseRefPoint.cpp" line="194"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
    <message>
        <location filename="../CMouseRefPoint.cpp" line="394"/>
        <source>Pixel %1x%2</source>
        <translation>Píxel %1x%2</translation>
    </message>
    <message>
        <location filename="../CMouseRefPoint.cpp" line="402"/>
        <source>Pos1 -&gt; Pos %1x%2 w:%3 h:%4</source>
        <translation>Pos1 -&gt; Pos %1x%2 anchura:%3 altura:%4</translation>
    </message>
    <message>
        <location filename="../CMouseRefPoint.cpp" line="406"/>
        <source>Set as Pos1</source>
        <translation>Asignar como Pos1</translation>
    </message>
</context>
<context>
    <name>CMouseSelMap</name>
    <message>
        <location filename="../CMouseSelMap.cpp" line="288"/>
        <source>Select all tiles</source>
        <translation>Seleccionar todas las teselas</translation>
    </message>
    <message>
        <location filename="../CMouseSelMap.cpp" line="289"/>
        <source>Select no tiles</source>
        <translation>No seleccionar teselas</translation>
    </message>
</context>
<context>
    <name>COsmTilesHash</name>
    <message>
        <source>Tile %1 was loaded from %2 days old File. Reloading ...</source>
        <translatorcomment>La tesela %1 se descargó desde un archivo de hace %2 días. Recargando ...</translatorcomment>
        <translation type="obsolete">La tesela %1 fue descargada de %2 dias antiguedad del archivo. Recargando ...</translation>
    </message>
    <message>
        <source>The recieved data is not an valid image. Maybe it isn&apos;t an image ...</source>
        <translation type="obsolete">Los datos recibidos no son una imagen válida. Tal vez no sea una imagen...</translation>
    </message>
</context>
<context>
    <name>COverlayArea</name>
    <message>
        <location filename="../COverlayArea.cpp" line="57"/>
        <source>Area %1</source>
        <translation>Área %1</translation>
    </message>
    <message>
        <location filename="../COverlayArea.cpp" line="982"/>
        <source>Overlay</source>
        <translation>Superponer</translation>
    </message>
    <message>
        <location filename="../COverlayArea.cpp" line="988"/>
        <source>Edit...</source>
        <translation>Editar...</translation>
    </message>
    <message>
        <location filename="../COverlayArea.cpp" line="990"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
</context>
<context>
    <name>COverlayAreaEditWidget</name>
    <message>
        <location filename="../COverlayAreaEditWidget.cpp" line="110"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>COverlayDB</name>
    <message>
        <location filename="../COverlayDB.cpp" line="666"/>
        <source>Overlay</source>
        <translation>Superponer</translation>
    </message>
    <message>
        <location filename="../COverlayDB.cpp" line="672"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../COverlayDB.cpp" line="725"/>
        <source>Static text</source>
        <translation>Texto estático</translation>
    </message>
    <message>
        <location filename="../COverlayDB.cpp" line="734"/>
        <source>Geo ref. text</source>
        <translation>Texto Georreferenciado</translation>
    </message>
</context>
<context>
    <name>COverlayDistance</name>
    <message>
        <location filename="../COverlayDistance.cpp" line="159"/>
        <source>Length: %1 %2</source>
        <translation>Longitud: %1 %2</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="172"/>
        <source>%1:</source>
        <translation>%1:</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1091"/>
        <source>Revert</source>
        <translation>Revertir</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1093"/>
        <source>Make Track</source>
        <translation>Crear Track</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1090"/>
        <source>Edit...</source>
        <translation>Editar...</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="65"/>
        <source>Tour %1</source>
        <translation>Tour %1</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1096"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1099"/>
        <source>Show Bullets</source>
        <translation>Mostrar Puntos</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1250"/>
        <source>Overlay</source>
        <translation>Superponer</translation>
    </message>
    <message>
        <location filename="../COverlayDistance.cpp" line="1094"/>
        <source>Make Route</source>
        <translation>Crear Ruta</translation>
    </message>
</context>
<context>
    <name>COverlayDistanceEditWidget</name>
    <message>
        <location filename="../COverlayDistanceEditWidget.cpp" line="59"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>COverlayText</name>
    <message>
        <location filename="../COverlayText.cpp" line="71"/>
        <source>no text</source>
        <translation>Sin texto</translation>
    </message>
</context>
<context>
    <name>COverlayToolWidget</name>
    <message>
        <location filename="../COverlayToolWidget.cpp" line="37"/>
        <source>Draw</source>
        <translation>Dibujar</translation>
    </message>
    <message>
        <location filename="../COverlayToolWidget.cpp" line="149"/>
        <source>Zoom to fit</source>
        <translation>Ajustar zoom</translation>
    </message>
    <message>
        <source>&lt;----&gt;</source>
        <translation type="obsolete">&lt;----&gt;</translation>
    </message>
    <message>
        <location filename="../COverlayToolWidget.cpp" line="150"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
</context>
<context>
    <name>CPlot</name>
    <message>
        <source>vertical zoom</source>
        <translation type="obsolete">ampliación vertical</translation>
    </message>
    <message>
        <source>reset zoom</source>
        <translation type="obsolete">reiniciar el zoom</translation>
    </message>
    <message>
        <location filename="../CPlot.cpp" line="546"/>
        <source>No or bad data.</source>
        <translation>Sin datos o erróneos.</translation>
    </message>
    <message>
        <location filename="../CPlot.cpp" line="1128"/>
        <source>Vertical zoom</source>
        <translation>Ampliación vertical</translation>
    </message>
    <message>
        <location filename="../CPlot.cpp" line="1132"/>
        <source>Reset zoom</source>
        <translation>Reiniciar zoom</translation>
    </message>
    <message>
        <location filename="../CPlot.cpp" line="1135"/>
        <source>Save...</source>
        <translation>Guardar...</translation>
    </message>
    <message>
        <location filename="../CPlot.cpp" line="1138"/>
        <source>Add Waypoint...</source>
        <translation>Añadir Waypoint...</translation>
    </message>
    <message>
        <location filename="../CPlot.cpp" line="1165"/>
        <source>Select output file</source>
        <translation>Seleccionar archivo de salida</translation>
    </message>
</context>
<context>
    <name>CResources</name>
    <message>
        <location filename="../CResources.cpp" line="376"/>
        <source>No device.</source>
        <translation>Dispositivo no encontrado.</translation>
    </message>
    <message>
        <location filename="../CResources.cpp" line="376"/>
        <source>You have to select a device in Setup-&gt;Config-&gt;Device &amp; Xfer</source>
        <translation>Debe seleccionar un dispositivo en:
Preferencias-&gt;General-&gt;Dispositivo &amp; Transferencia</translation>
    </message>
</context>
<context>
    <name>CRoute</name>
    <message>
        <source>Route</source>
        <translation type="obsolete">Ruta</translation>
    </message>
    <message>
        <location filename="../CRoute.cpp" line="416"/>
        <source>
length: %1 %2</source>
        <translation>
longitud: %1 %2</translation>
    </message>
    <message>
        <location filename="../CRoute.cpp" line="424"/>
        <source>
time: %1:</source>
        <translation>
hora: %1:</translation>
    </message>
    <message>
        <location filename="../CRoute.cpp" line="428"/>
        <source>
time: </source>
        <translation>
hora:</translation>
    </message>
</context>
<context>
    <name>CRouteDB</name>
    <message>
        <location filename="../CRouteDB.cpp" line="65"/>
        <source>Route%1</source>
        <translation>Ruta%1</translation>
    </message>
    <message>
        <location filename="../CRouteDB.cpp" line="197"/>
        <source>Unnamed</source>
        <translation>Sin nombrar</translation>
    </message>
</context>
<context>
    <name>CRouteToolWidget</name>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="55"/>
        <source>Routes</source>
        <translation>Rutas</translation>
    </message>
    <message>
        <source>
length: %1 %2</source>
        <translation type="obsolete">
longitud: %1 %2</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="87"/>
        <location filename="../CRouteToolWidget.cpp" line="129"/>
        <source>Fastest</source>
        <translation>Más Rápida</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="88"/>
        <location filename="../CRouteToolWidget.cpp" line="130"/>
        <source>Shortest</source>
        <translation>Más corta</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="89"/>
        <location filename="../CRouteToolWidget.cpp" line="131"/>
        <source>Bicycle</source>
        <translation>Bicicleta</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="90"/>
        <source>Mountain bike</source>
        <translation>Bicicleta de montaña</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="91"/>
        <source>Bicycle racer</source>
        <translation>Carrera en bici</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="92"/>
        <source>Bicycle safest</source>
        <translation>Bicicleta con seguridad</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="93"/>
        <source>Bicycle route</source>
        <translation>Ruta en bicicleta</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="94"/>
        <location filename="../CRouteToolWidget.cpp" line="133"/>
        <source>Pedestrian</source>
        <translation>A pie</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="96"/>
        <source>English</source>
        <translation>Inglés</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="97"/>
        <location filename="../CRouteToolWidget.cpp" line="140"/>
        <source>German</source>
        <translation>Alemán</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="98"/>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="99"/>
        <source>Czech</source>
        <translation>Checo</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="100"/>
        <location filename="../CRouteToolWidget.cpp" line="138"/>
        <source>Dutch</source>
        <translation>Holandés</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="101"/>
        <source>Croatian</source>
        <translation>Croata</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="102"/>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="103"/>
        <source>Dutch (belgium)</source>
        <translation>Holandés (Bélgica)</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="104"/>
        <location filename="../CRouteToolWidget.cpp" line="143"/>
        <source>Spanish</source>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="105"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="106"/>
        <source>Finnish</source>
        <translation>Finlandés</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="107"/>
        <location filename="../CRouteToolWidget.cpp" line="139"/>
        <source>French</source>
        <translation>Francés</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="108"/>
        <location filename="../CRouteToolWidget.cpp" line="141"/>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="109"/>
        <source>Portuguese (brazil)</source>
        <translation>Portugués (Brasil)</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="110"/>
        <source>Romanian</source>
        <translation>Rumano</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="111"/>
        <source>Russian</source>
        <translation>Ruso</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="112"/>
        <source>Svenska</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="113"/>
        <location filename="../CRouteToolWidget.cpp" line="137"/>
        <source>Danish</source>
        <translation>Danés</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="114"/>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="115"/>
        <source>Catalan</source>
        <translation>Catalán</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="116"/>
        <source>Japanese</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="117"/>
        <location filename="../CRouteToolWidget.cpp" line="142"/>
        <source>Norwegian</source>
        <translation>Noruego</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="118"/>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="119"/>
        <source>Norwegian-bokmal</source>
        <translation>Noruego-bokmal</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="120"/>
        <source>de - Rhenish</source>
        <translation>de - Rhenish</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="121"/>
        <source>de - Op Platt</source>
        <translation>de - Op Platt</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="122"/>
        <source>de - Berlin dialect</source>
        <translation>de - dialecto de Berlin</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="123"/>
        <source>de - Swabian</source>
        <translation>de - Swabian</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="124"/>
        <source>de - Ruhrpott</source>
        <translation>de - Ruhrpott</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="125"/>
        <source>de - great Austrian dialect</source>
        <translation>de - dialecto del gran Austria</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="126"/>
        <source>de - Bavarian</source>
        <translation>de - Bavarian</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="132"/>
        <source>Pedestrian/pub. transp.</source>
        <translation>A pie/transporte público</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="135"/>
        <source>US English</source>
        <translation>Inglés Americano</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="136"/>
        <source>British English</source>
        <translation>Inglés Británico</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="144"/>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="321"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="322"/>
        <source>Calc. route</source>
        <translation>Calcular ruta</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="324"/>
        <source>Make Overlay</source>
        <translation>Crear Capa</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="325"/>
        <source>Make Track</source>
        <translation>Crear Track</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="327"/>
        <source>Zoom to fit</source>
        <translation>Ajustar zoom</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="328"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="329"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="592"/>
        <location filename="../CRouteToolWidget.cpp" line="620"/>
        <location filename="../CRouteToolWidget.cpp" line="633"/>
        <location filename="../CRouteToolWidget.cpp" line="836"/>
        <source>Failed...</source>
        <translation>Falló...</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="592"/>
        <location filename="../CRouteToolWidget.cpp" line="620"/>
        <location filename="../CRouteToolWidget.cpp" line="633"/>
        <source>Bad response from server:
%1</source>
        <translation>Respuesta errónea desde el servidor:
%1</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="692"/>
        <source>created from route</source>
        <translation>creado a partir de la ruta</translation>
    </message>
    <message>
        <location filename="../CRouteToolWidget.cpp" line="836"/>
        <source>Route request timed out. Please try again later.</source>
        <translation>La petición de la ruta caducó. Por favor, inténtelo de nuevo más tarde.</translation>
    </message>
</context>
<context>
    <name>CSearchDB</name>
    <message>
        <location filename="../CSearchDB.cpp" line="78"/>
        <location filename="../CSearchDB.cpp" line="218"/>
        <source>Unknown host.</source>
        <translation>Máquina desconocida.</translation>
    </message>
    <message>
        <location filename="../CSearchDB.cpp" line="240"/>
        <source>Unknown response</source>
        <translation>Respuesta desconocida</translation>
    </message>
    <message>
        <location filename="../CSearchDB.cpp" line="247"/>
        <source>Error: </source>
        <translation>Error: </translation>
    </message>
    <message>
        <location filename="../CSearchDB.cpp" line="65"/>
        <source>start searching...</source>
        <translation>comenzar a buscar...</translation>
    </message>
    <message>
        <source>Bad number of return parameters</source>
        <translation type="obsolete">Número de parámetros de retorno erróneo</translation>
    </message>
    <message>
        <source>Success.</source>
        <translation type="obsolete">Éxito.</translation>
    </message>
    <message>
        <source>Failed. Reason unknown.</source>
        <translation type="obsolete">Falló. Motivo desconocido.</translation>
    </message>
    <message>
        <source>Failed. Missing query string.</source>
        <translation type="obsolete">Falló. Falta la cadena de búsqueda.</translation>
    </message>
    <message>
        <source>Failed. No location found.</source>
        <translation type="obsolete">Falló. Ubicación no encontrada.</translation>
    </message>
    <message>
        <source>Failed. No location because of legal matters.</source>
        <translation type="obsolete">Falló. Sin ubicación debido a temas legales.</translation>
    </message>
    <message>
        <source>Failed. Bad API key.</source>
        <translation type="obsolete">Falló. Clave API incorrecta.</translation>
    </message>
    <message>
        <location filename="../CSearchDB.cpp" line="231"/>
        <location filename="../CSearchDB.cpp" line="296"/>
        <location filename="../CSearchDB.cpp" line="364"/>
        <source>finished</source>
        <translation>finalizado</translation>
    </message>
    <message>
        <source>Failed...</source>
        <translation type="obsolete">Falló...</translation>
    </message>
    <message>
        <source>Bad response from server:
%1</source>
        <translation type="obsolete">Respuesta errónea desde el servidor:
%1</translation>
    </message>
    <message>
        <source>failed</source>
        <translation type="obsolete">falló</translation>
    </message>
    <message>
        <location filename="../CSearchDB.cpp" line="351"/>
        <source>no result</source>
        <translation>sin resultados</translation>
    </message>
</context>
<context>
    <name>CSearchToolWidget</name>
    <message>
        <location filename="../CSearchToolWidget.cpp" line="46"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../CSearchToolWidget.cpp" line="49"/>
        <source>Copy Position</source>
        <translation>Copiar Posición</translation>
    </message>
    <message>
        <location filename="../CSearchToolWidget.cpp" line="50"/>
        <source>Add Waypoint ...</source>
        <translation>Añadir Waypoint ...</translation>
    </message>
    <message>
        <location filename="../CSearchToolWidget.cpp" line="51"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../CSearchToolWidget.cpp" line="55"/>
        <source>OpenRouteService</source>
        <translation>OpenRouteService</translation>
    </message>
    <message>
        <location filename="../CSearchToolWidget.cpp" line="57"/>
        <source>Google</source>
        <translation>Google</translation>
    </message>
</context>
<context>
    <name>CTextEditWidget</name>
    <message>
        <location filename="../CTextEditWidget.cpp" line="68"/>
        <source>&amp;Bold</source>
        <translation>&amp;Negrita</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="77"/>
        <source>&amp;Italic</source>
        <translation>&amp;Cursiva</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="86"/>
        <source>&amp;Underline</source>
        <translation>&amp;Subrayado</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="98"/>
        <source>&amp;Left</source>
        <translation>&amp;Izquierda</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="102"/>
        <source>C&amp;enter</source>
        <translation>C&amp;entrar</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="106"/>
        <source>&amp;Right</source>
        <translation>&amp;Derecha</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="110"/>
        <source>&amp;Justify</source>
        <translation>&amp;Justificar</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="117"/>
        <source>&amp;Color...</source>
        <translation>&amp;Color...</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="152"/>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="156"/>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="160"/>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="164"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../CTextEditWidget.cpp" line="168"/>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
</context>
<context>
    <name>CTrack</name>
    <message>
        <location filename="../CTrack.cpp" line="1878"/>
        <source>
length: %1 %2</source>
        <translation>
longitud: %1 %2</translation>
    </message>
    <message>
        <source>, points: %1</source>
        <translation type="obsolete">, puntos: %1</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="790"/>
        <source>Slope [°]</source>
        <translation>Pendiente [°]</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="791"/>
        <source>Elevation [m]</source>
        <translation>Altura [m]</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="792"/>
        <source>Speed [km/h]</source>
        <translation>Velocidad [km/h]</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="812"/>
        <source>solid</source>
        <translation>sólido</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="813"/>
        <source>slope</source>
        <translation>pendiente</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="814"/>
        <source>elevation</source>
        <translation>altura</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="815"/>
        <source>speed</source>
        <translation>velocidad</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1879"/>
        <source>, points: %1 (%2)</source>
        <translation>, puntos: %1 (%2)</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1889"/>
        <source>
time: %1:</source>
        <translation>
hora: %1:</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1893"/>
        <source>
time: </source>
        <translation>
hora:</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1897"/>
        <location filename="../CTrack.cpp" line="1915"/>
        <source>, speed: %1 %2</source>
        <translation>, velocidad: %1 %2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1907"/>
        <source>
moving: %1:</source>
        <translation>
en movimiento: %1:</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1911"/>
        <source>
moving: </source>
        <translation>
en movimiento: </translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1918"/>
        <source>
start: %1</source>
        <translation>
inicio: %1</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1918"/>
        <location filename="../CTrack.cpp" line="1919"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1919"/>
        <source>
end: %1</source>
        <translation>
final: %1</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1924"/>
        <source>
%1%2 %3, %4%5 %6</source>
        <translation>
%1%2 %3, %4%5 %6</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1984"/>
        <source>%5 %4 %1:%2:%3 (%6%)</source>
        <translation>%5 %4 %1:%2:%3 (%6%)</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1985"/>
        <source> .. (%6%) %1:%2:%3 %4 %5</source>
        <translation> .. (%6%) %1:%2:%3 %4 %5</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1990"/>
        <source> .. (%5%) %1:%2:%3 %4</source>
        <translation> .. (%5%) %1:%2:%3 %4</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2007"/>
        <source> .. (%3%) %1%2 %4 %5</source>
        <translation> .. (%3%) %1%2 %4 %5</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2010"/>
        <source> .. (%3%) %1%2 %4</source>
        <translation> .. (%3%) %1%2 %4</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2024"/>
        <source>slope: %1°</source>
        <translation>pendiente: %1°</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2031"/>
        <source>speed: %1%2</source>
        <translation>velocidad: %1%2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2471"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2471"/>
        <source>This track has no valid start timestamp. Use the &apos;Date/Time&apos; track filter to set one.</source>
        <translation>Este track no tiene una fecha y hora de comienzo válidas. Utilice el filtro de tracks Fecha/Hora para establecerlas.</translation>
    </message>
    <message>
        <source> | (%6%) %1:%2:%3 %4 %5</source>
        <translation type="obsolete"> | (%6%) %1:%2:%3 %4 %5</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="1988"/>
        <source>%4 %1:%2:%3 (%5%)</source>
        <translation>%4 %1:%2:%3 (%5%)</translation>
    </message>
    <message>
        <source> | (%5%) %1:%2:%3 %4</source>
        <translation type="obsolete"> | (%5%) %1:%2:%3 %4</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2003"/>
        <source>%4 %1%2 (%3%)</source>
        <translation>%4 %1%2 (%3%)</translation>
    </message>
    <message>
        <source> | (%3%) %1%2 %4</source>
        <translation type="obsolete"> | (%3%) %1%2 %4</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2018"/>
        <source>elevation: %1%2</source>
        <translation>altura: %1%2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2041"/>
        <source>heart rate: %1bpm</source>
        <translation>pulso: %1ppm</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2051"/>
        <source>cadence: %1rpm</source>
        <translation>cadencia: %1rpm</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2084"/>
        <source>Start</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2090"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2124"/>
        <location filename="../CTrack.cpp" line="2126"/>
        <location filename="../CTrack.cpp" line="2140"/>
        <source> %3 %1 %2</source>
        <translation> %3 %1 %2</translation>
    </message>
    <message>
        <source>%4 %3 %1:%2h (%5%)</source>
        <translation type="obsolete">%4 %3 %1:%2h (%5%)</translation>
    </message>
    <message>
        <source> | (%5%) %1:%2h %3 %4</source>
        <translation type="obsolete"> | (%5%) %1:%2h %3 %4</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2000"/>
        <source>%5 %4 %1%2 (%3%)</source>
        <translation>%5 %4 %1%2 (%3%)</translation>
    </message>
    <message>
        <source> | (%3%) %1%2 %4 %5</source>
        <translation type="obsolete"> | (%3%) %1%2 %4 %5</translation>
    </message>
    <message>
        <source>elevation: %1 %2</source>
        <translation type="obsolete">altura: %1 %2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2066"/>
        <source>
 %1: %2 </source>
        <translation>
 %1: %2 </translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2128"/>
        <source> %3 %1 %2 </source>
        <translation> %3 %1 %2 </translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2138"/>
        <source>| %3 %1 %2</source>
        <translation>| %3 %1 %2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2142"/>
        <source> %1 %2</source>
        <translation> %1 %2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2143"/>
        <source> %1 :%2</source>
        <translation> %1 :%2</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2218"/>
        <source>You are trying to find waypoints along a track with %1 waypoints and a track of size %2. This can be a very time consuming operation. Go on?

Your selection will be stored in the track&apos;s data. You can save it along with the data. To change the selection use the checkbox in the track edit dialog.</source>
        <translation>Está intentando encontrar waypoints a lo largo de un track con %1 waypoints y un tamaño de %2 puntos. Esto puede llevar mucho tiempo. ¿Continúa?

La selección se almacenará en los datos del track. Puede guardarla junto con los datos. Para modificar la selección utilice la casilla de verificación en el menú de edición del track.</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="2225"/>
        <source>Warning...</source>
        <translation>Atención...</translation>
    </message>
</context>
<context>
    <name>CTrackDB</name>
    <message>
        <location filename="../CTrackDB.cpp" line="634"/>
        <source>Track%1</source>
        <translation>Track%1</translation>
    </message>
    <message>
        <location filename="../CTrackDB.cpp" line="1199"/>
        <source>Hmax=%1%2</source>
        <translation>Hmax=%1%2</translation>
    </message>
    <message>
        <location filename="../CTrackDB.cpp" line="1204"/>
        <source>Hmin=%1%2</source>
        <translation>Hmin=%1%2</translation>
    </message>
    <message>
        <location filename="../CTrackDB.cpp" line="1209"/>
        <source>Vmax=%1%2</source>
        <translation>Vmax=%1%2</translation>
    </message>
    <message>
        <location filename="../CTrackDB.cpp" line="1231"/>
        <source>Failed...</source>
        <translation>Falló...</translation>
    </message>
    <message>
        <location filename="../CTrackDB.cpp" line="1231"/>
        <source>Failed to copy track. You must select a track or track points of a track.</source>
        <translation>Fallo al copiar el track. Debe seleccionar un track o puntos de uno.</translation>
    </message>
    <message>
        <location filename="../CTrackDB.cpp" line="1323"/>
        <source>_rev</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CTrackEditWidget</name>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="749"/>
        <location filename="../CTrackEditWidget.cpp" line="759"/>
        <location filename="../CTrackEditWidget.cpp" line="774"/>
        <location filename="../CTrackEditWidget.cpp" line="776"/>
        <location filename="../CTrackEditWidget.cpp" line="778"/>
        <location filename="../CTrackEditWidget.cpp" line="784"/>
        <location filename="../CTrackEditWidget.cpp" line="1689"/>
        <location filename="../CTrackEditWidget.cpp" line="1732"/>
        <location filename="../CTrackEditWidget.cpp" line="1759"/>
        <location filename="../CTrackEditWidget.cpp" line="1760"/>
        <location filename="../CTrackEditWidget.cpp" line="1765"/>
        <location filename="../CTrackEditWidget.cpp" line="1768"/>
        <location filename="../CTrackEditWidget.cpp" line="1773"/>
        <location filename="../CTrackEditWidget.cpp" line="1778"/>
        <location filename="../CTrackEditWidget.cpp" line="1867"/>
        <location filename="../CTrackEditWidget.cpp" line="1871"/>
        <location filename="../CTrackEditWidget.cpp" line="1874"/>
        <location filename="../CTrackEditWidget.cpp" line="1879"/>
        <location filename="../CTrackEditWidget.cpp" line="1884"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1344"/>
        <source>Remove track points ...</source>
        <translation>Eliminar puntos del track...</translation>
    </message>
    <message>
        <source>You are about to remove purged track points permanently. If you press &apos;yes&apos;, all information will be lost.</source>
        <translation type="obsolete">Está a punto de eliminar permanentemente los puntos borrados del track. Si pulsa &apos;Sí&apos; toda la información se perderá.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1058"/>
        <source>Trainee</source>
        <translatorcomment>Aprendiz , recluta. ? Creo que se refiere a alguien que entrena, datos de pulsómetro,etc (Forerunners, Edge, etc.)</translatorcomment>
        <translation>Deportista</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="967"/>
        <location filename="../CTrackEditWidget.cpp" line="994"/>
        <source>Speed/Dist.</source>
        <translation>Velocidad/Dist.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="182"/>
        <source>Split</source>
        <translation>Dividir</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="499"/>
        <source>no extensions elements in this file</source>
        <translation>archivo sin elementos de extensión</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="974"/>
        <location filename="../CTrackEditWidget.cpp" line="1005"/>
        <source>Dist./Time</source>
        <translation>Dist./Tiempo</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="979"/>
        <location filename="../CTrackEditWidget.cpp" line="1016"/>
        <source>Profile/Dist.</source>
        <translation>Altura/Dist.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1031"/>
        <source>Speed/Time</source>
        <translation>Velocidad/Tiempo</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1043"/>
        <source>Profile/Time</source>
        <translation>Altura/Tiempo</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1345"/>
        <source>You are about to remove hidden track points permanently. If you press &apos;yes&apos;, all information will be lost.</source>
        <translation>Está a punto de eliminar permanentemente los puntos ocultos del track. Si pulsa &apos;Sí&apos;, se perderá la información.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1636"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1637"/>
        <source>Prox.</source>
        <translation>Prox.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1638"/>
        <source>Pic.</source>
        <translation>Imagen.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1639"/>
        <source>Elevation</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1640"/>
        <source>To Next</source>
        <translation>Al Siguiente</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1685"/>
        <location filename="../CTrackEditWidget.cpp" line="1687"/>
        <location filename="../CTrackEditWidget.cpp" line="1692"/>
        <location filename="../CTrackEditWidget.cpp" line="1694"/>
        <location filename="../CTrackEditWidget.cpp" line="1696"/>
        <location filename="../CTrackEditWidget.cpp" line="1698"/>
        <location filename="../CTrackEditWidget.cpp" line="1908"/>
        <location filename="../CTrackEditWidget.cpp" line="1910"/>
        <location filename="../CTrackEditWidget.cpp" line="1924"/>
        <location filename="../CTrackEditWidget.cpp" line="1926"/>
        <location filename="../CTrackEditWidget.cpp" line="1928"/>
        <location filename="../CTrackEditWidget.cpp" line="1930"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1771"/>
        <location filename="../CTrackEditWidget.cpp" line="1776"/>
        <location filename="../CTrackEditWidget.cpp" line="1877"/>
        <location filename="../CTrackEditWidget.cpp" line="1882"/>
        <source>%1 %2 </source>
        <translation>%1 %2 </translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1787"/>
        <location filename="../CTrackEditWidget.cpp" line="1792"/>
        <location filename="../CTrackEditWidget.cpp" line="1893"/>
        <location filename="../CTrackEditWidget.cpp" line="1898"/>
        <source>%1:%2 h</source>
        <translation>%1:%2 h</translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="obsolete">Info</translation>
    </message>
    <message>
        <source>Ele. wpt/trk</source>
        <translation type="obsolete">Alt. wpt/trk</translation>
    </message>
    <message>
        <source>to Last</source>
        <translation type="obsolete">al Anterior</translation>
    </message>
    <message>
        <source>to Next</source>
        <translation type="obsolete">al Siguiente</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1641"/>
        <source>Total</source>
        <translation>Total</translation>
    </message>
    <message>
        <source>Name
Proximity</source>
        <translation type="obsolete">Nombre
Proximidad</translation>
    </message>
    <message>
        <source>Picture</source>
        <translation type="obsolete">Imagen</translation>
    </message>
    <message>
        <source>to Next Dist./Time
Asc./Desc.</source>
        <translation type="obsolete">al Siguiente Dist./Tiempo
Asc./Desc.</translation>
    </message>
    <message>
        <source>Total Dist./Time
Asc./Desc.</source>
        <translation type="obsolete">Total Dist./Time
Asc./Desc.</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1642"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1645"/>
        <source>wpt</source>
        <translation>wpt</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1648"/>
        <source>trk</source>
        <translation>trk</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1682"/>
        <source>Start</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <source>-/%1 %2</source>
        <translation type="obsolete">-/%1 %2</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1700"/>
        <source>Start of track.</source>
        <translation>Inicio del track.</translation>
    </message>
    <message>
        <source>%1 %2 %3</source>
        <translation type="obsolete">%1 %2 %3</translation>
    </message>
    <message>
        <source>%1
%2</source>
        <translation type="obsolete">%1
%2</translation>
    </message>
    <message>
        <source>%3 %1:%2 h</source>
        <translation type="obsolete">%3 %1:%2 h</translation>
    </message>
    <message>
        <source>%1%2 %3 </source>
        <translation type="obsolete">%1%2 %3 </translation>
    </message>
    <message>
        <source>%1%2 %3</source>
        <translation type="obsolete">%1%2 %3</translation>
    </message>
    <message>
        <source>%1/%2 %3</source>
        <translation type="obsolete">%1/%2 %3</translation>
    </message>
    <message>
        <source>%1 %2
%3</source>
        <translation type="obsolete">%1 %2
%3</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1905"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <location filename="../CTrackEditWidget.cpp" line="1941"/>
        <source>End of track.</source>
        <translation>Fin del track.</translation>
    </message>
</context>
<context>
    <name>CTrackFilterWidget</name>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="178"/>
        <source>Edit name...</source>
        <translation>Editar nombre...</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="179"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="400"/>
        <location filename="../CTrackFilterWidget.cpp" line="1136"/>
        <source>Filter name ...</source>
        <translation>Nombre del filtro...</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="400"/>
        <location filename="../CTrackFilterWidget.cpp" line="1136"/>
        <source>Please enter a name for the filter list to store.</source>
        <translation>Por favor, introduzca un nombre para almacenar la lista de filtros.</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="422"/>
        <source>Delete track filter...</source>
        <translation>Borrar filtro del track...</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="422"/>
        <source>Do you really want to delete &apos;%1&apos;?</source>
        <translation>¿Realmente quiere borrar &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="694"/>
        <source>Reset</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="730"/>
        <source> (local)</source>
        <translation> (local)</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="730"/>
        <source> (remote)</source>
        <translation> (remoto)</translation>
    </message>
    <message>
        <location filename="../CTrackFilterWidget.cpp" line="1300"/>
        <location filename="../CTrackFilterWidget.cpp" line="1386"/>
        <location filename="../CTrackFilterWidget.cpp" line="1467"/>
        <location filename="../CTrackFilterWidget.cpp" line="1498"/>
        <location filename="../CTrackFilterWidget.cpp" line="1539"/>
        <location filename="../CTrackFilterWidget.cpp" line="1591"/>
        <location filename="../CTrackFilterWidget.cpp" line="1631"/>
        <location filename="../CTrackFilterWidget.cpp" line="1683"/>
        <location filename="../CTrackFilterWidget.cpp" line="1722"/>
        <location filename="../CTrackFilterWidget.cpp" line="1775"/>
        <location filename="../CTrackFilterWidget.cpp" line="1814"/>
        <location filename="../CTrackFilterWidget.cpp" line="1870"/>
        <source>Abort filter</source>
        <translation>Cancelar filtrado</translation>
    </message>
</context>
<context>
    <name>CTrackStatDistanceWidget</name>
    <message>
        <location filename="../CTrackStatDistanceWidget.cpp" line="32"/>
        <source>time [h]</source>
        <translation>tiempo [h]</translation>
    </message>
    <message>
        <location filename="../CTrackStatDistanceWidget.cpp" line="33"/>
        <source>distance [m]</source>
        <translation>distancia [m]</translation>
    </message>
</context>
<context>
    <name>CTrackStatExtensionWidget</name>
    <message>
        <location filename="../CTrackStatExtensionWidget.cpp" line="106"/>
        <source>time [h]</source>
        <translation>tiempo [h]</translation>
    </message>
</context>
<context>
    <name>CTrackStatProfileWidget</name>
    <message>
        <location filename="../CTrackStatProfileWidget.cpp" line="36"/>
        <source>distance [m]</source>
        <translation>distancia [m]</translation>
    </message>
    <message>
        <location filename="../CTrackStatProfileWidget.cpp" line="43"/>
        <source>alt. [m]</source>
        <translation>alt. [m]</translation>
    </message>
    <message>
        <location filename="../CTrackStatProfileWidget.cpp" line="82"/>
        <source>distance [%1]</source>
        <translation>distancia [%1]</translation>
    </message>
    <message>
        <location filename="../CTrackStatProfileWidget.cpp" line="88"/>
        <source>alt. [%1]</source>
        <translation>alt. [%1]</translation>
    </message>
    <message>
        <location filename="../CTrackStatProfileWidget.cpp" line="40"/>
        <location filename="../CTrackStatProfileWidget.cpp" line="86"/>
        <source>time [h]</source>
        <translation>tiempo [h]</translation>
    </message>
</context>
<context>
    <name>CTrackStatSpeedWidget</name>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="33"/>
        <source>distance [m]</source>
        <translation>distancia [m]</translation>
    </message>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="39"/>
        <source>speed [km/h]</source>
        <translation>velocidad [km/h]</translation>
    </message>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="77"/>
        <source>distance [%1]</source>
        <translation>distancia [%1]</translation>
    </message>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="84"/>
        <source>speed [%1]</source>
        <translation>velocidad [%1]</translation>
    </message>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="149"/>
        <source>speed</source>
        <translation>velocidad</translation>
    </message>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="150"/>
        <source>med. speed</source>
        <translation>velocidad med.</translation>
    </message>
    <message>
        <location filename="../CTrackStatSpeedWidget.cpp" line="37"/>
        <location filename="../CTrackStatSpeedWidget.cpp" line="81"/>
        <source>time [h]</source>
        <translation>tiempo [h]</translation>
    </message>
</context>
<context>
    <name>CTrackStatTraineeWidget</name>
    <message>
        <location filename="../CTrackStatTraineeWidget.cpp" line="30"/>
        <source>distance [m]</source>
        <translation>distancia [m]</translation>
    </message>
    <message>
        <location filename="../CTrackStatTraineeWidget.cpp" line="66"/>
        <source>distance [%1]</source>
        <translation>distancia [%1]</translation>
    </message>
    <message>
        <location filename="../CTrackStatTraineeWidget.cpp" line="31"/>
        <location filename="../CTrackStatTraineeWidget.cpp" line="67"/>
        <source>heart rate [bpm]</source>
        <translation>pulsaciones [ppm]</translation>
    </message>
</context>
<context>
    <name>CTrackToolWidget</name>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="47"/>
        <source>Tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="58"/>
        <source>Edit...</source>
        <translation>Editar...</translation>
    </message>
    <message>
        <source>Filter...</source>
        <translation type="obsolete">Filtrar...</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="59"/>
        <source>Revert</source>
        <translation>Revertir</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="63"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="64"/>
        <source>Show Bullets</source>
        <translation>Mostrar Puntos</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="65"/>
        <source>Show Min/Max</source>
        <translation>Mostrar Mín/Máx</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="67"/>
        <source>Zoom to fit</source>
        <translation>Ajustar zoom</translation>
    </message>
    <message>
        <source>Deselect</source>
        <translation type="obsolete">No elegir</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="68"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>
length: %1 %2</source>
        <translation type="obsolete">
longitud: %1 %2</translation>
    </message>
    <message>
        <source>, points: %1</source>
        <translation type="obsolete">, puntos: %1</translation>
    </message>
    <message>
        <source>
time: %1:</source>
        <translation type="obsolete">
tiempo: %1:</translation>
    </message>
    <message>
        <source>
time: </source>
        <translation type="obsolete">
tiempo:</translation>
    </message>
    <message>
        <source>, speed: %1 %2</source>
        <translation type="obsolete">, velocidad: %1 %2</translation>
    </message>
    <message>
        <source>
start: %1</source>
        <translation type="obsolete">
inicar: %1</translation>
    </message>
    <message>
        <source>-</source>
        <translation type="obsolete">-</translation>
    </message>
    <message>
        <source>
end: %1</source>
        <translation type="obsolete">
final: %1</translation>
    </message>
    <message>
        <source>
%1%2 %3, %4%5 %6</source>
        <translation type="obsolete">
%1%2 %3, %4%5 %6</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="254"/>
        <location filename="../CTrackToolWidget.cpp" line="278"/>
        <source>Edit track ...</source>
        <translation>Editar track...</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="254"/>
        <location filename="../CTrackToolWidget.cpp" line="278"/>
        <location filename="../CTrackToolWidget.cpp" line="391"/>
        <source>You have to select a track first.</source>
        <translation>Primero debe seleccionar un track.</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="262"/>
        <location filename="../CTrackToolWidget.cpp" line="286"/>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="391"/>
        <source>Filter</source>
        <translation>Filtrar</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="61"/>
        <source>Make Overlay</source>
        <translation>Crear Capa</translation>
    </message>
    <message>
        <location filename="../CTrackToolWidget.cpp" line="356"/>
        <source>created from track</source>
        <translation>creado a partir de un track</translation>
    </message>
</context>
<context>
    <name>CWpt</name>
    <message>
        <location filename="../CWpt.cpp" line="522"/>
        <source>elevation: %1 %2</source>
        <translation>altura: %1 %2</translation>
    </message>
    <message>
        <location filename="../CWpt.cpp" line="528"/>
        <source>direction: %1%2</source>
        <translation>dirección: %1%2</translation>
    </message>
    <message>
        <location filename="../CWpt.cpp" line="536"/>
        <source>proximity: %1 %2</source>
        <translation>proximidad: %1 %2</translation>
    </message>
    <message>
        <location filename="../CWpt.cpp" line="555"/>
        <source>Parent: %1</source>
        <translation>Padre: %1</translation>
    </message>
    <message>
        <location filename="../CWpt.cpp" line="1143"/>
        <source>No additional information.</source>
        <translation>Sin información adicional.</translation>
    </message>
    <message>
        <location filename="../CWpt.cpp" line="1150"/>
        <source>&lt;div&gt;&lt;b&gt;Type:&lt;/b&gt; %1 &lt;b&gt;Container:&lt;/b&gt; %2 </source>
        <translation>&lt;div&gt;&lt;b&gt;Tipo:&lt;/b&gt; %1 &lt;b&gt;Contenedor:&lt;/b&gt; %2 </translation>
    </message>
    <message>
        <location filename="../CWpt.cpp" line="1151"/>
        <source>&lt;b&gt;D:&lt;/b&gt; %1 &lt;b&gt;T:&lt;/b&gt; %2 </source>
        <translation>&lt;b&gt;D:&lt;/b&gt; %1 &lt;b&gt;T:&lt;/b&gt; %2 </translation>
    </message>
</context>
<context>
    <name>CWptDB</name>
    <message>
        <location filename="../CWptDB.cpp" line="344"/>
        <source>Do you really want to delete the sticky waypoint &apos;%1&apos;</source>
        <translation>Realmente desea borrar el waypoint pegado &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="345"/>
        <source>Delete sticky waypoint ...</source>
        <translation>Borrar waypoint pegado ...</translation>
    </message>
    <message>
        <source>Select path...</source>
        <translation type="obsolete">Seleccionar directorio...</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="1341"/>
        <source>Read EXIF tags from pictures.</source>
        <translation>Leer datos EXIF de las imágenes.</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="1341"/>
        <location filename="../CWptDB.cpp" line="1397"/>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="1323"/>
        <location filename="../CWptDB.cpp" line="1325"/>
        <source>Missing libexif</source>
        <translation>Falta la librería libexif</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="1323"/>
        <source>Unable to find libexif-12.dll.</source>
        <translation>No se pudo encontrar libexif-12.dll.</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="1325"/>
        <source>Unable to find libexif.so.</source>
        <translation>No se pudo encontrar libexif.so.</translation>
    </message>
    <message>
        <location filename="../CWptDB.cpp" line="1397"/>
        <source>Reference pictures by timestamp.</source>
        <translation>Referenciar imágenes por marca de tiempo.</translation>
    </message>
</context>
<context>
    <name>CWptToolWidget</name>
    <message>
        <location filename="../CWptToolWidget.cpp" line="50"/>
        <source>Waypoints</source>
        <translation>Waypoints</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="61"/>
        <source>Copy Position</source>
        <translation>Copiar Posición</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="60"/>
        <source>Edit...</source>
        <translation>Editar...</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="64"/>
        <source>Icon ...</source>
        <translation>Icono ...</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="65"/>
        <source>Parent Waypoint ...</source>
        <translation>Waypoint padre ...</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="67"/>
        <source>Reset selection</source>
        <translation>Reiniciar Selección</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="69"/>
        <source>Show Names</source>
        <translation>Mostrar Nombres</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="71"/>
        <source>Zoom to fit</source>
        <translation>Ajustar zoom</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="72"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="73"/>
        <source>Delete non-selected</source>
        <translation>Borrar lo no seleccionado</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="74"/>
        <source>Delete by ...</source>
        <translation>Borrar por ...</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="101"/>
        <source>enter valid position</source>
        <translation>introducir posición válida</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="213"/>
        <source> (sticky)</source>
        <translation> (pegado)</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="63"/>
        <source>Proximity ...</source>
        <translation>Proximidad ...</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="415"/>
        <source>Distance [%1]</source>
        <translation>Distancia [%1]</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="432"/>
        <source>Proximity distance ...</source>
        <translation>Distancia de proximidad ...</translation>
    </message>
    <message>
        <location filename="../CWptToolWidget.cpp" line="66"/>
        <source>Make Route ...</source>
        <translation>Crear Ruta ...</translation>
    </message>
</context>
<context>
    <name>ICopyright</name>
    <message>
        <location filename="../ICopyright.ui" line="14"/>
        <source>Copyright...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="28"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="36"/>
        <source>QLandkarte GT</source>
        <translation>QLandkarte GT</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="43"/>
        <location filename="../ICopyright.ui" line="57"/>
        <location filename="../ICopyright.ui" line="71"/>
        <location filename="../ICopyright.ui" line="85"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="50"/>
        <source>QT Library</source>
        <translation>Librería QT</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="64"/>
        <source>GDAL Library</source>
        <translation>Librería GDAL</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="78"/>
        <source>Proj4 Library</source>
        <translation>Librería Proj4</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="128"/>
        <source>Formats</source>
        <translation>Formatos</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="134"/>
        <source>Formats supported by GDAL:</source>
        <translation>Formatos soportados por GDAL:</translation>
    </message>
    <message>
        <location filename="../ICopyright.ui" line="152"/>
        <source>GPL</source>
        <translation>GPL</translation>
    </message>
    <message utf8="true">
        <location filename="../ICopyright.ui" line="158"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;title&gt;GNU General Public License v3.0 - GNU Project - Free Software Foundation (FSF)&lt;/title&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:14px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Version 3, 29 June 2007 &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright © 2007 Free Software Foundation, Inc. &amp;lt;&lt;a href=&quot;http://fsf.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://fsf.org/&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Everyone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;preamble&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;P&lt;/span&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;reamble&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The GNU General Public License is a free, copyleft license for software and other kinds of works. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The licenses for most software and other practical works are designed to take away your freedom to share and change the works. By contrast, the GNU General Public License is intended to guarantee your freedom to share and change all versions of a program--to make sure it remains free software for all its users. We, the Free Software Foundation, use the GNU General Public License for most of our software; it applies also to any other work released this way by its authors. You can apply it to your programs, too. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When we speak of free software, we are referring to freedom, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for them if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs, and that you know you can do these things. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To protect your rights, we need to prevent others from denying you these rights or asking you to surrender the rights. Therefore, you have certain responsibilities if you distribute copies of the software, or if you modify it: responsibilities to respect the freedom of others. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must pass on to the recipients the same freedoms that you received. You must make sure that they, too, receive or can get the source code. And you must show them these terms so they know their rights. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Developers that use the GNU GPL protect your rights with two steps: (1) assert copyright on the software, and (2) offer you this License giving you legal permission to copy, distribute and/or modify it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For the developers&apos; and authors&apos; protection, the GPL clearly explains that there is no warranty for this free software. For both users&apos; and authors&apos; sake, the GPL requires that modified versions be marked as changed, so that their problems will not be attributed erroneously to authors of previous versions. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Some devices are designed to deny users access to install or run modified versions of the software inside them, although the manufacturer can do so. This is fundamentally incompatible with the aim of protecting users&apos; freedom to change the software. The systematic pattern of such abuse occurs in the area of products for individuals to use, which is precisely where it is most unacceptable. Therefore, we have designed this version of the GPL to prohibit the practice for those products. If such problems arise substantially in other domains, we stand ready to extend this provision to those domains in future versions of the GPL, as needed to protect the freedom of users. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Finally, every program is threatened constantly by software patents. States should not allow patents to restrict development and use of software on general-purpose computers, but in those that do, we wish to avoid the special danger that patents applied to a free program could make it effectively proprietary. To prevent this, the GPL assures that patents cannot be used to render the program non-free. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;terms&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;T&lt;/span&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;ERMS AND CONDITIONS&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section0&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Definitions.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;“This License” refers to version 3 of the GNU General Public License. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;“Copyright” also means copyright-like laws that apply to other kinds of works, such as semiconductor masks. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;“The Program” refers to any copyrightable work licensed under this License. Each licensee is addressed as “you”. “Licensees” and “recipients” may be individuals or organizations. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To “modify” a work means to copy from or adapt all or part of the work in a fashion requiring copyright permission, other than the making of an exact copy. The resulting work is called a “modified version” of the earlier work or a work “based on” the earlier work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A “covered work” means either the unmodified Program or a work based on the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To “propagate” a work means to do anything with it that, without permission, would make you directly or secondarily liable for infringement under applicable copyright law, except executing it on a computer or modifying a private copy. Propagation includes copying, distribution (with or without modification), making available to the public, and in some countries other activities as well. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To “convey” a work means any kind of propagation that enables other parties to make or receive copies. Mere interaction with a user through a computer network, with no transfer of a copy, is not conveying. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;An interactive user interface displays “Appropriate Legal Notices” to the extent that it includes a convenient and prominently visible feature that (1) displays an appropriate copyright notice, and (2) tells the user that there is no warranty for the work (except to the extent that warranties are provided), that licensees may convey the work under this License, and how to view a copy of this License. If the interface presents a list of user commands or options, such as a menu, a prominent item in the list meets this criterion. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section1&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Source Code.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The “source code” for a work means the preferred form of the work for making modifications to it. “Object code” means any non-source form of a work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A “Standard Interface” means an interface that either is an official standard defined by a recognized standards body, or, in the case of interfaces specified for a particular programming language, one that is widely used among developers working in that language. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The “System Libraries” of an executable work include anything, other than the work as a whole, that (a) is included in the normal form of packaging a Major Component, but which is not part of that Major Component, and (b) serves only to enable use of the work with that Major Component, or to implement a Standard Interface for which an implementation is available to the public in source code form. A “Major Component”, in this context, means a major essential component (kernel, window system, and so on) of the specific operating system (if any) on which the executable work runs, or a compiler used to produce the work, or an object code interpreter used to run it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The “Corresponding Source” for a work in object code form means all the source code needed to generate, install, and (for an executable work) run the object code and to modify the work, including scripts to control those activities. However, it does not include the work&apos;s System Libraries, or general-purpose tools or generally available free programs which are used unmodified in performing those activities but which are not part of the work. For example, Corresponding Source includes interface definition files associated with source files for the work, and the source code for shared libraries and dynamically linked subprograms that the work is specifically designed to require, such as by intimate data communication or control flow between those subprograms and other parts of the work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Corresponding Source need not include anything that users can regenerate automatically from other parts of the Corresponding Source. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Corresponding Source for a work in source code form is that same work. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section2&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Basic Permissions.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All rights granted under this License are granted for the term of copyright on the Program, and are irrevocable provided the stated conditions are met. This License explicitly affirms your unlimited permission to run the unmodified Program. The output from running a covered work is covered by this License only if the output, given its content, constitutes a covered work. This License acknowledges your rights of fair use or other equivalent, as provided by copyright law. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Conveying under any other circumstances is permitted solely under the conditions stated below. Sublicensing is not allowed; section 10 makes it unnecessary. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section3&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Protecting Users&apos; Legal Rights From Anti-Circumvention Law.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;No covered work shall be deemed part of an effective technological measure under any applicable law fulfilling obligations under article 11 of the WIPO copyright treaty adopted on 20 December 1996, or similar laws prohibiting or restricting circumvention of such measures. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When you convey a covered work, you waive any legal power to forbid circumvention of technological measures to the extent such circumvention is effected by exercising rights under this License with respect to the covered work, and you disclaim any intention to limit operation or modification of the work as a means of enforcing, against the work&apos;s users, your or third parties&apos; legal rights to forbid circumvention of technological measures. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section4&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;4&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Conveying Verbatim Copies.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may convey verbatim copies of the Program&apos;s source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice; keep intact all notices stating that this License and any non-permissive terms added in accord with section 7 apply to the code; keep intact all notices of the absence of any warranty; and give all recipients a copy of this License along with the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may charge any price or no price for each copy that you convey, and you may offer support or warranty protection for a fee. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section5&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;5&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Conveying Modified Source Versions.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may convey a work based on the Program, or the modifications to produce it from the Program, in the form of source code under the terms of section 4, provided that you also meet all of these conditions: &lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) The work must carry prominent notices stating that you modified it, and giving a relevant date. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) The work must carry prominent notices stating that it is released under this License and any conditions added under section 7. This requirement modifies the requirement in section 4 to “keep intact all notices”. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) You must license the entire work, as a whole, under this License to anyone who comes into possession of a copy. This License will therefore apply, along with any applicable section 7 additional terms, to the whole of the work, and all its parts, regardless of how they are packaged. This License gives no permission to license the work in any other way, but it does not invalidate such permission if you have separately received it. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) If the work has interactive user interfaces, each must display Appropriate Legal Notices; however, if the Program has interactive interfaces that do not display Appropriate Legal Notices, your work need not make them do so. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A compilation of a covered work with other separate and independent works, which are not by their nature extensions of the covered work, and which are not combined with it such as to form a larger program, in or on a volume of a storage or distribution medium, is called an “aggregate” if the compilation and its resulting copyright are not used to limit the access or legal rights of the compilation&apos;s users beyond what the individual works permit. Inclusion of a covered work in an aggregate does not cause this License to apply to the other parts of the aggregate. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section6&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;6&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Conveying Non-Source Forms.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may convey a covered work in object code form under the terms of sections 4 and 5, provided that you also convey the machine-readable Corresponding Source under the terms of this License, in one of these ways: &lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by the Corresponding Source fixed on a durable physical medium customarily used for software interchange. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Convey the object code in, or embodied in, a physical product (including a physical distribution medium), accompanied by a written offer, valid for at least three years and valid for as long as you offer spare parts or customer support for that product model, to give anyone who possesses the object code either (1) a copy of the Corresponding Source for all the software in the product that is covered by this License, on a durable physical medium customarily used for software interchange, for a price no more than your reasonable cost of physically performing this conveying of source, or (2) access to copy the Corresponding Source from a network server at no charge. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Convey individual copies of the object code with a copy of the written offer to provide the Corresponding Source. This alternative is allowed only occasionally and noncommercially, and only if you received the object code with such an offer, in accord with subsection 6b. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Convey the object code by offering access from a designated place (gratis or for a charge), and offer equivalent access to the Corresponding Source in the same way through the same place at no further charge. You need not require recipients to copy the Corresponding Source along with the object code. If the place to copy the object code is a network server, the Corresponding Source may be on a different server (operated by you or a third party) that supports equivalent copying facilities, provided you maintain clear directions next to the object code saying where to find the Corresponding Source. Regardless of what server hosts the Corresponding Source, you remain obligated to ensure that it is available for as long as needed to satisfy these requirements. &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Convey the object code using peer-to-peer transmission, provided you inform other peers where the object code and Corresponding Source of the work are being offered to the general public at no charge under subsection 6d. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A separable portion of the object code, whose source code is excluded from the Corresponding Source as a System Library, need not be included in conveying the object code work. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A “User Product” is either (1) a “consumer product”, which means any tangible personal property which is normally used for personal, family, or household purposes, or (2) anything designed or sold for incorporation into a dwelling. In determining whether a product is a consumer product, doubtful cases shall be resolved in favor of coverage. For a particular product received by a particular user, “normally used” refers to a typical or common use of that class of product, regardless of the status of the particular user or of the way in which the particular user actually uses, or expects or is expected to use, the product. A product is a consumer product regardless of whether the product has substantial commercial, industrial or non-consumer uses, unless such uses represent the only significant mode of use of the product. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;“Installation Information” for a User Product means any methods, procedures, authorization keys, or other information required to install and execute modified versions of a covered work in that User Product from a modified version of its Corresponding Source. The information must suffice to ensure that the continued functioning of the modified object code is in no case prevented or interfered with solely because modification has been made. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you convey an object code work under this section in, or with, or specifically for use in, a User Product, and the conveying occurs as part of a transaction in which the right of possession and use of the User Product is transferred to the recipient in perpetuity or for a fixed term (regardless of how the transaction is characterized), the Corresponding Source conveyed under this section must be accompanied by the Installation Information. But this requirement does not apply if neither you nor any third party retains the ability to install modified object code on the User Product (for example, the work has been installed in ROM). &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The requirement to provide Installation Information does not include a requirement to continue to provide support service, warranty, or updates for a work that has been modified or installed by the recipient, or for the User Product in which it has been modified or installed. Access to a network may be denied when the modification itself materially and adversely affects the operation of the network or violates the rules and protocols for communication across the network. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Corresponding Source conveyed, and Installation Information provided, in accord with this section must be in a format that is publicly documented (and with an implementation available to the public in source code form), and must require no special password or key for unpacking, reading or copying. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section7&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Additional Terms.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;“Additional permissions” are terms that supplement the terms of this License by making exceptions from one or more of its conditions. Additional permissions that are applicable to the entire Program shall be treated as though they were included in this License, to the extent that they are valid under applicable law. If additional permissions apply only to part of the Program, that part may be used separately under those permissions, but the entire Program remains governed by this License without regard to the additional permissions. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When you convey a copy of a covered work, you may at your option remove any additional permissions from that copy, or from any part of it. (Additional permissions may be written to require their own removal in certain cases when you modify the work.) You may place additional permissions on material, added by you to a covered work, for which you have or can give appropriate copyright permission. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Notwithstanding any other provision of this License, for material you add to a covered work, you may (if authorized by the copyright holders of that material) supplement the terms of this License with terms: &lt;/p&gt;
&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Disclaiming warranty or limiting liability differently from the terms of sections 15 and 16 of this License; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Requiring preservation of specified reasonable legal notices or author attributions in that material or in the Appropriate Legal Notices displayed by works containing it; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Prohibiting misrepresentation of the origin of that material, or requiring that modified versions of such material be marked in reasonable ways as different from the original version; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d) Limiting the use for publicity purposes of names of licensors or authors of the material; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;e) Declining to grant rights under trademark law for use of some trade names, trademarks, or service marks; or &lt;/li&gt;
&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f) Requiring indemnification of licensors and authors of that material by anyone who conveys the material (or modified versions of it) with contractual assumptions of liability to the recipient, for any liability that these contractual assumptions directly impose on those licensors and authors. &lt;/li&gt;&lt;/ul&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All other non-permissive additional terms are considered “further restrictions” within the meaning of section 10. If the Program as you received it, or any part of it, contains a notice stating that it is governed by this License along with a term that is a further restriction, you may remove that term. If a license document contains a further restriction but permits relicensing or conveying under this License, you may add to a covered work material governed by the terms of that license document, provided that the further restriction does not survive such relicensing or conveying. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you add terms to a covered work in accord with this section, you must place, in the relevant source files, a statement of the additional terms that apply to those files, or a notice indicating where to find the applicable terms. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Additional terms, permissive or non-permissive, may be stated in the form of a separately written license, or stated as exceptions; the above requirements apply either way. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section8&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Termination.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may not propagate or modify a covered work except as expressly provided under this License. Any attempt otherwise to propagate or modify it is void, and will automatically terminate your rights under this License (including any patent licenses granted under the third paragraph of section 11). &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;However, if you cease all violation of this License, then your license from a particular copyright holder is reinstated (a) provisionally, unless and until the copyright holder explicitly and finally terminates your license, and (b) permanently, if the copyright holder fails to notify you of the violation by some reasonable means prior to 60 days after the cessation. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Moreover, your license from a particular copyright holder is reinstated permanently if the copyright holder notifies you of the violation by some reasonable means, this is the first time you have received notice of violation of this License (for any work) from that copyright holder, and you cure the violation prior to 30 days after your receipt of the notice. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Termination of your rights under this section does not terminate the licenses of parties who have received copies or rights from you under this License. If your rights have been terminated and not permanently reinstated, you do not qualify to receive new licenses for the same material under section 10. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section9&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;9&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;. Acceptance Not Required for Having Copies.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You are not required to accept this License in order to receive or run a copy of the Program. Ancillary propagation of a covered work occurring solely as a consequence of using peer-to-peer transmission to receive a copy likewise does not require acceptance. However, nothing other than this License grants you permission to propagate or modify any covered work. These actions infringe copyright if you do not accept this License. Therefore, by modifying or propagating a covered work, you indicate your acceptance of this License to do so. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section10&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;0. Automatic Licensing of Downstream Recipients.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each time you convey a covered work, the recipient automatically receives a license from the original licensors, to run, modify and propagate that work, subject to this License. You are not responsible for enforcing compliance by third parties with this License. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;An “entity transaction” is a transaction transferring control of an organization, or substantially all assets of one, or subdividing an organization, or merging organizations. If propagation of a covered work results from an entity transaction, each party to that transaction who receives a copy of the work also receives whatever licenses to the work the party&apos;s predecessor in interest had or could give under the previous paragraph, plus a right to possession of the Corresponding Source of the work from the predecessor in interest, if the predecessor has it or can get it with reasonable efforts. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may not impose any further restrictions on the exercise of the rights granted or affirmed under this License. For example, you may not impose a license fee, royalty, or other charge for exercise of rights granted under this License, and you may not initiate litigation (including a cross-claim or counterclaim in a lawsuit) alleging that any patent claim is infringed by making, using, selling, offering for sale, or importing the Program or any portion of it. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section11&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1. Patents.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A “contributor” is a copyright holder who authorizes use under this License of the Program or a work on which the Program is based. The work thus licensed is called the contributor&apos;s “contributor version”. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A contributor&apos;s “essential patent claims” are all patent claims owned or controlled by the contributor, whether already acquired or hereafter acquired, that would be infringed by some manner, permitted by this License, of making, using, or selling its contributor version, but do not include claims that would be infringed only as a consequence of further modification of the contributor version. For purposes of this definition, “control” includes the right to grant patent sublicenses in a manner consistent with the requirements of this License. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each contributor grants you a non-exclusive, worldwide, royalty-free patent license under the contributor&apos;s essential patent claims, to make, use, sell, offer for sale, import and otherwise run, modify and propagate the contents of its contributor version. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In the following three paragraphs, a “patent license” is any express agreement or commitment, however denominated, not to enforce a patent (such as an express permission to practice a patent or covenant not to sue for patent infringement). To “grant” such a patent license to a party means to make such an agreement or commitment not to enforce a patent against the party. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you convey a covered work, knowingly relying on a patent license, and the Corresponding Source of the work is not available for anyone to copy, free of charge and under the terms of this License, through a publicly available network server or other readily accessible means, then you must either (1) cause the Corresponding Source to be so available, or (2) arrange to deprive yourself of the benefit of the patent license for this particular work, or (3) arrange, in a manner consistent with the requirements of this License, to extend the patent license to downstream recipients. “Knowingly relying” means you have actual knowledge that, but for the patent license, your conveying the covered work in a country, or your recipient&apos;s use of the covered work in a country, would infringe one or more identifiable patents in that country that you have reason to believe are valid. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If, pursuant to or in connection with a single transaction or arrangement, you convey, or propagate by procuring conveyance of, a covered work, and grant a patent license to some of the parties receiving the covered work authorizing them to use, propagate, modify or convey a specific copy of the covered work, then the patent license you grant is automatically extended to all recipients of the covered work and works based on it. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A patent license is “discriminatory” if it does not include within the scope of its coverage, prohibits the exercise of, or is conditioned on the non-exercise of one or more of the rights that are specifically granted under this License. You may not convey a covered work if you are a party to an arrangement with a third party that is in the business of distributing software, under which you make payment to the third party based on the extent of your activity of conveying the work, and under which the third party grants, to any of the parties who would receive the covered work from you, a discriminatory patent license (a) in connection with copies of the covered work conveyed by you (or copies made from those copies), or (b) primarily for and in connection with specific products or compilations that contain the covered work, unless you entered into that arrangement, or that patent license was granted, prior to 28 March 2007. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nothing in this License shall be construed as excluding or limiting any implied license or other defenses to infringement that may otherwise be available to you under applicable patent law. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section12&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;2. No Surrender of Others&apos; Freedom.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot convey a covered work so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not convey it at all. For example, if you agree to terms that obligate you to collect a royalty for further conveying from those to whom you convey the Program, the only way you could satisfy both those terms and this License would be to refrain entirely from conveying the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section13&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;3. Use with the GNU Affero General Public License.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Notwithstanding any other provision of this License, you have permission to link or combine any covered work with a work licensed under version 3 of the GNU Affero General Public License into a single combined work, and to convey the resulting work. The terms of this License will continue to apply to the part which is the covered work, but the special requirements of the GNU Affero General Public License, section 13, concerning interaction through a network will apply to the combination as such. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section14&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;4. Revised Versions of this License.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The Free Software Foundation may publish revised and/or new versions of the GNU General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each version is given a distinguishing version number. If the Program specifies that a certain numbered version of the GNU General Public License “or any later version” applies to it, you have the option of following the terms and conditions either of that numbered version or of any later version published by the Free Software Foundation. If the Program does not specify a version number of the GNU General Public License, you may choose any version ever published by the Free Software Foundation. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If the Program specifies that a proxy can decide which future versions of the GNU General Public License can be used, that proxy&apos;s public statement of acceptance of a version permanently authorizes you to choose that version for the Program. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Later license versions may give you additional or different permissions. However, no additional obligations are imposed on any author or copyright holder as a result of your choosing to follow a later version. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section15&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;5. Disclaimer of Warranty.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM “AS IS” WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section16&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;6. Limitation of Liability.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;section17&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot; font-size:medium; font-weight:600;&quot;&gt;7. Interpretation of Sections 15 and 16.&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If the disclaimer of warranty and limitation of liability provided above cannot be given local legal effect according to their terms, reviewing courts shall apply local law that most closely approximates an absolute waiver of all civil liability in connection with the Program, unless a warranty or assumption of liability accompanies a copy of the Program in return for a fee. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;END OF TERMS AND CONDITIONS &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a name=&quot;howto&quot;&gt;&lt;/a&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;H&lt;/span&gt;&lt;span style=&quot; font-size:large; font-weight:600;&quot;&gt;ow to Apply These Terms to Your New Programs&lt;/span&gt; &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you develop a new program, and you want it to be of the greatest possible use to the public, the best way to achieve this is to make it free software which everyone can redistribute and change under these terms. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To do so, attach the following notices to the program. It is safest to attach them to the start of each source file to most effectively state the exclusion of warranty; and each file should have at least the “copyright” line and a pointer to where the full notice is found. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    &amp;lt;one line to give the program&apos;s name and a brief idea of what it does.&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This program is free software: you can redistribute it and/or modify&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    it under the terms of the GNU General Public License as published by&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    the Free Software Foundation, either version 3 of the License, or&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    (at your option) any later version.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This program is distributed in the hope that it will be useful,&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    but WITHOUT ANY WARRANTY; without even the implied warranty of&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    GNU General Public License for more details.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    You should have received a copy of the GNU General Public License&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    along with this program.  If not, see &amp;lt;http://www.gnu.org/licenses/&amp;gt;. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Also add information on how to contact you by electronic and paper mail. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If the program does terminal interaction, make it output a short notice like this when it starts in an interactive mode: &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    &amp;lt;program&amp;gt;  Copyright (C) &amp;lt;year&amp;gt;  &amp;lt;name of author&amp;gt;&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w&apos;.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    This is free software, and you are welcome to redistribute it&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;    under certain conditions; type `show c&apos; for details. &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The hypothetical commands `show w&apos; and `show c&apos; should show the appropriate parts of the General Public License. Of course, your program&apos;s commands might be different; for a GUI interface, you would use an “about box”. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You should also get your employer (if you work as a programmer) or school, if any, to sign a “copyright disclaimer” for the program, if necessary. For more information on this, and how to apply and follow the GNU GPL, see &amp;lt;&lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/&lt;/span&gt;&lt;/a&gt;&amp;gt;. &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The GNU General Public License does not permit incorporating your program into proprietary programs. If your program is a subroutine library, you may consider it more useful to permit linking proprietary applications with the library. If this is what you want to do, use the GNU Lesser General Public License instead of this License. But first, please read &amp;lt;&lt;a href=&quot;http://www.gnu.org/philosophy/why-not-lgpl.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/philosophy/why-not-lgpl.html&lt;/span&gt;&lt;/a&gt;&amp;gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ICreateMapFineTune</name>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="20"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="26"/>
        <source>Input</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="46"/>
        <source>Open File</source>
        <translation>Abrir archivo</translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="53"/>
        <source>Output</source>
        <translation>Salida</translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="73"/>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="103"/>
        <location filename="../ICreateMapFineTune.ui" line="113"/>
        <location filename="../ICreateMapFineTune.ui" line="123"/>
        <location filename="../ICreateMapFineTune.ui" line="133"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="160"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../ICreateMapFineTune.ui" line="180"/>
        <source>Load a referenced file together with waypoints or tracks. You can move the map until it fits best all overlay elements. Finally you can save a copy of the file with the new offset.</source>
        <translation>Cargar un archivo georreferenciado junto con waypoints o tracks. Puede mover el mapa para un mejor ajuste de los elementos. Para terminar, puede guardar una copia del archivo con la nueva compensación.</translation>
    </message>
</context>
<context>
    <name>ICreateMapGeoTiff</name>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">EtiquetaTexto</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="46"/>
        <source>Input file:</source>
        <translation>Archivo de entrada:</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Reload file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Recargar archivo&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="94"/>
        <location filename="../ICreateMapGeoTiff.ui" line="131"/>
        <location filename="../ICreateMapGeoTiff.ui" line="155"/>
        <location filename="../ICreateMapGeoTiff.ui" line="327"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="109"/>
        <source>Output file:</source>
        <translation>Archivo de salida:</translation>
    </message>
    <message>
        <source>Projection</source>
        <translation type="obsolete">Proyección</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="321"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Projection Wizard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Asistente de Proyección&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="164"/>
        <source>Mode</source>
        <translation>Modo</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="obsolete">Abrir archivo</translation>
    </message>
    <message>
        <source>This dialog allows you to georeference map files in TIF format with a 8 bit color palette. As pre-requisite you need a set of reference points and the projection for those points. You will get best results if the projection of the points is also the projection of the map. In most cases this is mercator. It is recommended to shift the reference point to WGS84 datum, right from the beginning.

</source>
        <translation type="obsolete">Este dialogo permite añadir datos de referencia geográfica a mapas en formato .TIF con color a 8 bit. Como requisito previo usted necesita un sistema de puntos de referencia y la proyección para esos puntos. Consegirá los mejores resultados si la proyección de los puntos es también la del mapa. En la mayoría de los casos esta es marcator. Es recomendable para cambiar la referencia al datum WGS84, desde el principio.

</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="357"/>
        <source>label</source>
        <translation>etiqueta</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="362"/>
        <source>Coord.</source>
        <translation>Coord.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="367"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="372"/>
        <source>y</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="385"/>
        <source>Add Ref.</source>
        <translation>Añadir Ref.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="415"/>
        <source>Delete Ref.</source>
        <translation>Borrar Ref.</translation>
    </message>
    <message>
        <source>Step 3: Reference map</source>
        <translation type="obsolete">Paso 3: Mapa de referencia</translation>
    </message>
    <message>
        <source>Go on!</source>
        <translation type="obsolete">¡Seguir!</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="395"/>
        <source>Load Ref.</source>
        <translation>Cargar Ref.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="140"/>
        <source>Map projection</source>
        <translation>Proyección del Mapa</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="29"/>
        <source>Step1</source>
        <translation>Paso 1</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="298"/>
        <source>Step2</source>
        <translation>Paso 2</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="311"/>
        <source>Ref. projection</source>
        <translation>Ref. de proyección</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="191"/>
        <source>Overviews</source>
        <translation>Vista general</translation>
    </message>
    <message>
        <source>Step 1: Load raster map</source>
        <translation type="obsolete">Paso 1: Cargar mapa raster</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="78"/>
        <source>open input file</source>
        <translation>abrir archivo de entrada</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="91"/>
        <source>reload input file</source>
        <translation>recargar archivo de entrada</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="128"/>
        <source>select output file</source>
        <translation>seleccionar archivo de salida</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="152"/>
        <source>Projection Wizard</source>
        <translation>Asistente de proyección</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="200"/>
        <source>2x</source>
        <translation>2x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="207"/>
        <source>4x</source>
        <translation>4x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="214"/>
        <source>8x</source>
        <translation>8x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="221"/>
        <source>16x</source>
        <translation>16x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="228"/>
        <source>32x</source>
        <translation>32x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="254"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="513"/>
        <source>Process</source>
        <translation>Proceso</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="585"/>
        <source>Start process</source>
        <translation>Comenzar proceso</translation>
    </message>
    <message>
        <source>Step 2: Add reference points</source>
        <translation type="obsolete">Paso 2: Añadir puntos de referencia</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="453"/>
        <source>Use the n and b key to step between reference points while fine tuning the points on the map.</source>
        <translation>Utilice las teclas N y B para cambiar entre los puntos de referencia mientras optimiza los puntos sobre el mapa.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="405"/>
        <source>Save Ref.</source>
        <translation>Guardar Ref.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="425"/>
        <source>Grid Tool</source>
        <translation>Herramienta de Rejilla</translation>
    </message>
    <message utf8="true">
        <source>The next stage is to add known reference points. Simply add reference points to the map and enter their latitude / longitude (WGS84) or the easting and northing [m] in the table. Next you move the point to the correct location on the map.

coordinate formats: &quot;N49° 10.234 E12° 01.456&quot;, &quot;12.193172   46.575377&quot;, &quot;285000 5162000&quot;</source>
        <translation type="obsolete">El siguiente paso consiste en añadir puntos de referencia conocidos. Simplemente añada los puntos de referencia al mapa y escriba su latitud/longitud (WGS84) o este y norte [m] en la tabla. Después mueva el punto a la localización correcta en el mapa.

formato de las coordenadas: &quot;N49° 10.234 E12° 01.456&quot;, &quot;12.193172   46.575377&quot;, &quot;285000 5162000&quot;</translation>
    </message>
    <message>
        <source>Now QLandkarte GT will reference your file with the help of the GDAL tools. Watch the progress in the output browser.</source>
        <translation type="obsolete">Ahora QLandKarte GT creará referencias para su archivo con ayuda de las herraminentas GDAL. Vea el resultado en el navegador.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGeoTiff.ui" line="592"/>
        <source>Clear All</source>
        <translation>Eliminar todo</translation>
    </message>
</context>
<context>
    <name>ICreateMapGridTool</name>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Step 2a: Place reference points</source>
        <translation type="obsolete">Paso 2a: Situar puntos de referencia</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="88"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <source>The grid tool will place reference points with calculated longitude and latitude to the line crossings of a linear map grid. To do so you have to place the 4 initial reference points to the grid as shown in the example.

Altenatively you might have chosen to use already existing reference points. In this case you simply have to define the grid step size.</source>
        <translation type="obsolete">La herramienta situará los puntos de referencia con longitud y latitud sobra la rejilla. Para ello, debe colocar los 4 primeros puntos de referencia sobre la rejilla como muestra el ejemplo..

Como alternativa puede utilizar puntos de referencia ya existentes. En ese caso, le basta con definir el tamaño de la rejilla.</translation>
    </message>
    <message>
        <source>Step 2b: Add source projection</source>
        <translation type="obsolete">Paso 2b: Añadir proyección de origen</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="152"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="161"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Projection Wizard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Asistente de Proyección&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="181"/>
        <source>Easting</source>
        <translation>Este</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="188"/>
        <source>Northing</source>
        <translation>Norte</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="206"/>
        <source>x - spacing</source>
        <translation>Separación - x</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="227"/>
        <source>y - spacing</source>
        <translation>Separación - y</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="245"/>
        <source>Did you notice the orange rectangle at the border of your map? The calculated reference points will be inside this rectangle. You can move the lines with your mouse to limit the area. This comes very handy if you have maps with more than on UTM zone. You apply the grid tool to the one zone first. And in a second run to the other.</source>
        <translation>¿Se ha dado cuenta del rectángulo naranja en el borde de su mapa? Los puntos de referencia calculados estarán dentro de este rectángulo. Puede mover las líneas con el ratón para limitar el área. Esto es muy útil si tiene mapas con más de una zona UTM. Aplique primero la herramienta de rejilla en una de las zonas. Y en una segunda pasada a la otra.</translation>
    </message>
    <message>
        <source>Step 2c: Create grid</source>
        <translation type="obsolete">Paso 2c: Crear rejilla</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="136"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Next you might want to add a source projection to do a grid shift to WGS84. And you have to define the longitude and the latitude of the top left reference point. And the spacing between point 1 and 2, and 1 and 4.</source>
        <translation type="obsolete">A continuación, quizá quiera añadir una fuente de proyección para transformar la rejilla en WGS84. Y debe definir la longitud y la latitud del punto de referencia superior izquierdo. Y la separación entre los puntos 1 y 2, y 1 y 4.</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="360"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../ICreateMapGridTool.ui" line="353"/>
        <source>Ok</source>
        <translation>Validar</translation>
    </message>
    <message>
        <source>On ok, the grid tool will add equally spaced reference points over your map. Keep in mind to manually fine tune the location of each point to get good results.</source>
        <translation type="obsolete">Ya está, la herramienta de rejilla agregará puntos de referencia equidistantes sobre su mapa. Tenga en cuenta que es necesario ajustar manualmente para obtener buenos resultados.</translation>
    </message>
</context>
<context>
    <name>ICreateMapOSM</name>
    <message>
        <source>lon/lat
top/left</source>
        <translation type="obsolete">lon/lat
superior/izquierda</translation>
    </message>
    <message utf8="true">
        <source>e.g.  N59° 59.251 E010° 17.157 </source>
        <translation type="obsolete">e.g.  N59° 59.251 E010° 17.157 </translation>
    </message>
    <message>
        <source>map area</source>
        <translation type="obsolete">área del mapa</translation>
    </message>
    <message>
        <source>lon/lat
bottom/right</source>
        <translation type="obsolete">lon/lat
inferior/derecha</translation>
    </message>
    <message utf8="true">
        <source>e.g.  N59° 43.553 E010° 57.366 </source>
        <translation type="obsolete">e.g.  N59° 43.553 E010° 57.366 </translation>
    </message>
    <message>
        <source>map output path</source>
        <translation type="obsolete">directorio de salida del mapa</translation>
    </message>
    <message>
        <source>This is the path you normally load maps from.</source>
        <translation type="obsolete">Este es el direcctorio desde el cual cargará los mapas normalmente.</translation>
    </message>
    <message>
        <source>&lt;path&gt;</source>
        <translation type="obsolete">&lt;path&gt;</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>map name</source>
        <translation type="obsolete">nombre del mapa</translation>
    </message>
    <message>
        <source>A map will have several files. All files of a map will begin with this name.</source>
        <translation type="obsolete">Un mapa tendrá varios archivos. Todos los archivos de un mapa deberán empezar por el mismo nombre.</translation>
    </message>
    <message>
        <source>create</source>
        <translation type="obsolete">crear</translation>
    </message>
    <message>
        <source>Provide a short and descriptive comment. The map will be listed by that comment in QLandkarte M.</source>
        <translation type="obsolete">Añada una breve descripción. El mapa se mostrará con ese nombre en QLandkarte M.</translation>
    </message>
    <message>
        <source>comment</source>
        <translation type="obsolete">comentario</translation>
    </message>
</context>
<context>
    <name>ICreateMapQMAP</name>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <source>Step 1: Map definition</source>
        <translation type="obsolete">Paso 1: Definición del mapa</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="46"/>
        <source>map definition</source>
        <translation>definición del mapa</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="66"/>
        <source>comment</source>
        <translation>comentario</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="102"/>
        <source>Open existing *.qmap definition</source>
        <translation>Abrir un archivo *.qmap existente</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="105"/>
        <location filename="../ICreateMapQMAP.ui" line="115"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Create new *.qmap definition.</source>
        <translation type="obsolete">Crear un nuevo archivo *.qmap.</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="112"/>
        <source>Create new *.qmap definition</source>
        <translation>Crear un nuevo archivo *.qmap</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="144"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Step 2: Add maps</source>
        <translation type="obsolete">Paso 2: Añadir mapas</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="29"/>
        <source>Step1</source>
        <translation>Paso 1</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="191"/>
        <source>Step2</source>
        <translation>Paso 2</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="209"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="216"/>
        <source>Detail Layer</source>
        <translation>Capa de Detalle</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="221"/>
        <source>min. zoom</source>
        <translation>zoom mín.</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="226"/>
        <source>max. zoom</source>
        <translation>zoom máx.</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="231"/>
        <source>files</source>
        <translation>archivos</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="244"/>
        <source>add</source>
        <translation>añadir</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="254"/>
        <source>edit</source>
        <translation>editar</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="264"/>
        <source>del</source>
        <translation>borrar</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="274"/>
        <source>up</source>
        <translation>subir</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="284"/>
        <source>down</source>
        <translation>bajar</translation>
    </message>
    <message>
        <source>You can stack maps of different detail as layer. For each detail layer you can define the number of zoom levels. Several map files can be grouped into a detail layer. All map files in a layer must have the same projection and scale. You need at least one layer with one file.</source>
        <translation type="obsolete">Puede añadir mapas con distinto detalle como capas. Para cada capa de detalle puede definir el número de niveles de zoom. Varios ficheros pueden agruparse en una capa de detalle. Todos los mapas en una capa deben tener la misma proyección y escala. Usted necesita al menos una capa con un archivo.</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="347"/>
        <source>Summary</source>
        <translation>Resumen</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="388"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../ICreateMapQMAP.ui" line="76"/>
        <source>quadratic zoom</source>
        <translation>ampliación exponencial</translation>
    </message>
    <message>
        <source>You can edit or create QLandkarte GT map definition files (*.qmap). A map definition defines what files to show at a certain zoom level.The comment will be used to list the map collection as known map in the map tool view. You can choose between a linear or quadratic zoom level increment.
Once you created a map set you can attach DEM data to it via the context menu in the lefthand map tool view.</source>
        <translation type="obsolete">Usted puede modificar o crear ficheros de definición del mapa (*.qmap). Un fichero de definición define los ficheros que deben mostrarse a los distintos niveles de zoom. El comentario se utilizará para indicar el mapa en la herramienta de vista de los mapas disponibles. Usted puede elegir entre un nivel de ampliación lineal o exponecial.
Una vez halla creado un mapa, usted puede adjuntar datos de altitud mediante un archivo DEM mediante el menú contextual de la izquierda de la herramienta mapas.</translation>
    </message>
</context>
<context>
    <name>ICreateMapWMS</name>
    <message>
        <location filename="../ICreateMapWMS.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="21"/>
        <source>Server:</source>
        <translation>Servidor:</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="31"/>
        <source>Load Capabilities</source>
        <translation>Cargar capacidades</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="52"/>
        <source>Title:</source>
        <translation>Título:</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="59"/>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="69"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="79"/>
        <source>Layers:</source>
        <translation>Capas:</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="96"/>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="112"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ICreateMapWMS.ui" line="134"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
</context>
<context>
    <name>IDevice</name>
    <message>
        <location filename="../IDevice.cpp" line="54"/>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
    <message>
        <location filename="../IDevice.cpp" line="68"/>
        <source>Download finished.</source>
        <translation>Descarga terminada.</translation>
    </message>
    <message>
        <location filename="../IDevice.cpp" line="90"/>
        <source>Upload finished.</source>
        <translation>Carga terminada.</translation>
    </message>
    <message>
        <location filename="../IDevice.cpp" line="96"/>
        <source>Sorry... </source>
        <translation>Lo siento...</translation>
    </message>
    <message>
        <location filename="../IDevice.cpp" line="96"/>
        <source>Your device does not support live log.</source>
        <translation>Su dispositivo no soporta la grabación en vivo.</translation>
    </message>
</context>
<context>
    <name>IDiaryEdit</name>
    <message>
        <location filename="../IDiaryEdit.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="25"/>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="31"/>
        <location filename="../IDiaryEdit.ui" line="45"/>
        <location filename="../IDiaryEdit.ui" line="52"/>
        <location filename="../IDiaryEdit.ui" line="59"/>
        <location filename="../IDiaryEdit.ui" line="66"/>
        <location filename="../IDiaryEdit.ui" line="73"/>
        <location filename="../IDiaryEdit.ui" line="87"/>
        <location filename="../IDiaryEdit.ui" line="94"/>
        <location filename="../IDiaryEdit.ui" line="101"/>
        <location filename="../IDiaryEdit.ui" line="108"/>
        <location filename="../IDiaryEdit.ui" line="128"/>
        <location filename="../IDiaryEdit.ui" line="138"/>
        <location filename="../IDiaryEdit.ui" line="151"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="125"/>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="135"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="145"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="182"/>
        <source>show profiles</source>
        <translation>mostrar perfiles</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="189"/>
        <source>show geocaches</source>
        <translation>mostrar geocaches</translation>
    </message>
    <message>
        <location filename="../IDiaryEdit.ui" line="209"/>
        <source>add map view  when printing</source>
        <translation>añadir vista del mapa al imprimir</translation>
    </message>
</context>
<context>
    <name>IDiaryEditWidget</name>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Create diary skeleton from current data.</source>
        <translation type="obsolete">Crear una estructura de Diario a partir de los datos actuales.</translation>
    </message>
</context>
<context>
    <name>IDlg3DHelp</name>
    <message>
        <location filename="../IDlg3DHelp.ui" line="14"/>
        <source>Help for 3D view...</source>
        <translation>Ayuda para la vista 3D...</translation>
    </message>
    <message>
        <location filename="../IDlg3DHelp.ui" line="20"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;How to control the 3D view&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;The view and the point of view (POV) are moved by several keys together with mouse movements. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;FPV/Rotate:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;There are two basic modes: The first person view (FPV) mode and the rotation mode. In FPV mode your POV is moving freely in the screen. In rotation mode your POV is circling around the map center.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Track mode:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;In track mode the POV is tied to a point within a selected track. You can use the &apos;w&apos; and &apos;s&apos; key to move along the track. You can use the mouse (left button pressed) to look around.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Mouse:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You can control your POV by mouse movements. You have to press the left mouse button while moving the mouse. Moving the mouse up and down will make your POV look up and down. Moving your map left and right will depend on the mode:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;FPV: you turn around your own axis. Rotate: you rotate the complete screen&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Mouse wheel:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You can zoom in and out from the sceen by the mouse wheel. If you keep the shift key pressed while scrolling you change the elevation of the 3D sceen only.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You can use the keyboard, too:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;strg + +: zoom in&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;strg + -: zoom out&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;shift + +: raise elevation&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;shift + -: lower elevation&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Keys:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;You can move your  POV in the sceen by key. This is independent of the chosen mode.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;w: move forward&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;s: move backward&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;a: strafe left&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;d: strafe right&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;shift + w: move up&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;shift + s: move down&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Light:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;To move the light source you have to press down the &apos;L&apos; key, the left mouse button and move the mouse.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;up: move light source north&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;down: move light source south&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;left: move light source west&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;right: move light source east&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Cómo regular la vista 3D&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;La visión y el punto de vista (PDV) son movidos por varias teclas junto con los movimientos del ratón. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;VPP/Rotar:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Hay dos modos básicos: El modo de vista en primera persona (VPP) y el modo rotación. En el modo VPP su PDV se está moviendo libremente en la pantalla. En el modo rotación su PDV está girando alrededor del centro del mapa.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Modo &quot;track&quot;:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;En el modo &quot;track&quot; su PDV se vincula al punto del track seleccionado. Usted puede usar las teclas &apos;w&apos; y &apos;s&apos; para desplazarse a lo largo del track. Puede utilizar el ratón (presionando el botón izquierdo) para mirar alrededor.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Ratón:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Usted puede controlar su PDV por los movimientos del ratón. Tiene que presionar el botón izquierdo mientras mueve el ratón. Moviendo el ratón arriba y abajo su PDV cambiará arriba y abajo. Moviendo el mapa izquierda y derecha dependerá del modo:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;VPP: usted cambia su propio eje. Rotar: usted gira toda la pantalla.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Rueda del ratón:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Puede acercar y alejar la imagen con la rueda del ratón. Si usted mantiene pulsada la tecla mayúsculas mientras que gira la rueda, cambia solamente la elevación de la vista 3D.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Puede utilizar también el teclado:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;strg + +: acercar&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;strg + -: alejar&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;mayúsculas + +: aumentar elevación&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;mayúsculas + -: disminuir elevación&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Teclas:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Usted puede mover su PDV sobre la pantalla con las teclas. Esto es independiente del modo elegido.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;w: mover adelante&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;s: mover atrás&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;a: mover izquierda&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;d: mover derecha&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;shift + w: mover arriba&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;shift + s: mover abajo&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Iluminación:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Para mover la fuente de luz tiene que presionar la tecla &apos;L&apos;, el botón izquierdo del ratón y moverlo.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;arriba: mover la fuente de luz al norte&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;abajo: mover la fuente de luz al sur&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;izquierda: mover la fuente de luz al oeste&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;derecha: mover la fuente de luz al este&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;How to control the 3D view&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;The view and the point of view (POV) are moved by several keys together with mouse movements. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;FPV/Rotate:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;There are two basic modes: The first person view (FPV) mode and the rotation mode. In FPV mode your POV is moving freely in the screen. In rotation mode your POV is circling around the map center.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Track mode:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;In track mode the POV is tied to a point within a selected track. You can use the &apos;w&apos; and &apos;s&apos; key to move along the track. You can use the mouse (left button pressed) to look around.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Mouse:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;You can control your POV by mouse movements. You have to press the left mouse button while moving the mouse. Moving the mouse up and down will make your POV look up and down. Moving your map left and right will depend on the mode:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;FPV: you turn around your own axis. Rotate: you rotate the complete screen&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Mouse wheel:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;You can zoom in and out from the sceen by the mouse wheel. If you keep the shift key pressed while scrolling you change the elevation of the 3D sceen only.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Keys:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;You can move your  POV in the sceen by key. This is independent of the chosen mode.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;w: move forward&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;s: move backward&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;a: strafe left&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;d: strafe right&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;shift + w: move up&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;shift + s: move down&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Light:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;To move the light source you have to press down the &apos;L&apos; key, the left mouse button and move the mouse.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;up: move light source north&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;down: move light source south&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;left: move light source west&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;right: move light source east&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Cómo regular la vista 3D&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;La visión y el punto de vista (PDV) son movidos por varias teclas junto con los movimientos del ratón. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;VPP/Rotar:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;Hay dos modos básicos: El modo de vista en primera persona (VPP) y el modo rotación. En el modo VPP su PDV se está moviendo libremente en la pantalla. En el modo rotación su PDV está girando alrededor del centro del mapa.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Modo &quot;track&quot;:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;En el modo &quot;track&quot; su PDV se vincula al punto del track seleccionado. Usted puede usar las teclas &apos;w&apos; y &apos;s&apos; para desplazarse a lo largo del track. Puede utilizar el ratón (presionando el botón izquierdo) para mirar alrededor.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Ratón:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;Usted puede controlar su PDV por los movimientos del ratón. Tiene que presionar el botón izquierdo mientras mueve el ratón. Moviendo el ratón arriba y abajo su PDV cambiará arriba y abajo. Moviendo el mapa izquierda y derecha dependerá del modo:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;VPP: usted cambia su propio eje. Rotar: usted gira toda la pantalla.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Rueda del ratón:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;Puede acercar y alejar la imagen con la rueda del ratón. Si usted mantiene pulsada la tecla mayúsculas mientras que gira la rueda, cambia solamente la elevación de la vista 3D.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Combinación de teclas:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;Usted puede mover su PDV sobre la pantalla con las teclas. Esto es independiente del modo elegido.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;w: mover adelante&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;s: mover atrás&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;a: mover izquierda&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;d: mover derecha&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;mayúsculas + w: mover arriba&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;mayúsculas + s: mover abajo&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-weight:600;&quot;&gt;Luz:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;Para mover la fuente de luz tiene que presionar la tecla &quot;L&quot;, el botón izquierdo del ratón y moverlo.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;arriba: mover la fuente de luz al norte&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;abajo: mover la fuente de luz al sur&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;izquierda: mover la fuente de luz al oeste&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;;&quot;&gt;derecha: mover la fuente de luz al este&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;How to control the 3D view&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The view and the point of view (POV) are moved by several keys together with mouse movements. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;FPV/Rotate:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;There are two basic modes: The first person view (FPV) mode and the rotation mode. In FPV mode your POV is moving freely in the screen. In rotation mode your POV is circling around the map center.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Track mode:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In track mode the POV is tied to a point within a selected track. You can use the &apos;w&apos; and &apos;s&apos; key to move along the track. You can use the mouse (left button pressed) to look around.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Mouse:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can control your POV by mouse movements. You have to press the left mouse button while moving the mouse. Moving the mouse up and down will make your POV look up and down. Moving your map left and right will depend on the mode:&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;FPV: you turn around your own axis. Rotate: you rotate the complete screen&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Mouse wheel:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can zoom in and out from the sceen by the mouse wheel. If you keep the shift key pressed while scrolling you change the elevation of the 3D sceen only.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keys:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can move your  POV in the sceen by key. This is independent of the chosen mode.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;w: move forward&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;s: move backward&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a: strafe left&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d: strafe right&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;shift + a: move up&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;shift + s: move down&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Light:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To move the light source you have to press down the &apos;L&apos; key, the left mouse button and move the mouse.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;up: move light source north&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;down: move light source south&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;left: move light source west&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;right: move light source east&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cómo regular la vista 3D&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;La visión y el punto de vista (PDV) son movidos por varias teclas junto con los movimientos del ratón. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;VPP/Rotar:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Hay dos modos básicos: El modo de vista en primera persona (VPP) y el modo rotación. En el modo VPP su PDV se está moviendo libremente en la pantalla. En el modo rotación su PDV está girando alrededor del centro del mapa.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modo &quot;track&quot;:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;En el modo &quot;track&quot; su PDV se vincula al punto del track seleccionado. Usted puede usar las teclas &apos;w&apos; y &apos;s&apos; para desplazarse a lo largo del track. Puede utilizar el ratón (presionando el botón izquierdo) para mirar alrededor.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ratón:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Usted puede controlar su PDV por los movimientos del ratón. Tiene que presionar el botón izquierdo mientras mueve el ratón. Moviendo el ratón arriba y abajo su PDV cambiara arriba y abajo. Moviendo el mapa izquierda y derecha dependerá del modo:&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;VPP: usted cambia su propio eje. Rotar: usted gira toda la pantalla.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Rueda del ratón:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Puede acercar y alejar la imagen con la rueda del ratón. Si usted mantiene pulsada la tecla mayúsculas mientras que gira la rueda, cambia solamente la elevación de la vista 3D .&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Combinación de teclas:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Usted puede mover su PDV sobre la pantalla con las teclas. Esto es independiente del modo elegido.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;w: mover adelante&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;s: mover atrás&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a: mover izquierda&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;d: mover derecha&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;shift + a: mover arriba&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;shift + s: mover abajo&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Luz:&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Para mover la fuente de luz tiene que presionar la tecla &quot;L&quot;, el botón izquierdo del ratón y moverlo.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;arriba: mover la fuente de luz al norte&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;abajo: mover la fuente de luz al sur&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;izquierda: mover la fuente de luz al oeste&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;derecha: mover la fuente de luz al este&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>IDlgCombineDistOvl</name>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="14"/>
        <source>Combine Overlays ...</source>
        <translation>Combinar Capas ...</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="36"/>
        <source>Available Overlays</source>
        <translation>Capas Disponibles</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="54"/>
        <source>Add overlay to list</source>
        <translation>Añadir capa a la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="57"/>
        <location filename="../IDlgCombineDistOvl.ui" line="67"/>
        <location filename="../IDlgCombineDistOvl.ui" line="102"/>
        <location filename="../IDlgCombineDistOvl.ui" line="115"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="64"/>
        <source>Remove overlay from list</source>
        <translation>Borrar capa de la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="78"/>
        <source>Selected Overlays</source>
        <translation>Capas seleccionadas</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="99"/>
        <source>Move overlay up in list</source>
        <translation>Mover capa hacia arriba en la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="112"/>
        <source>Move overlay down in list</source>
        <translation>Mover capa hacia abajo en la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="128"/>
        <source>New Overlay Name</source>
        <translation>Nombre de la Nueva Capa</translation>
    </message>
    <message>
        <location filename="../IDlgCombineDistOvl.ui" line="135"/>
        <source>New Distance</source>
        <translation>Nueva Distancia</translation>
    </message>
</context>
<context>
    <name>IDlgCombineTracks</name>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="14"/>
        <source>Combine Tracks ...</source>
        <translation>Combinar Tracks ...</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="38"/>
        <source>Sort by timestamp</source>
        <translation>Ordenar por fecha</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="54"/>
        <source>Available Tracks</source>
        <translation>Tracks Disponibles</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="72"/>
        <source>Add track to list</source>
        <translation>Añadir track a la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="75"/>
        <location filename="../IDlgCombineTracks.ui" line="85"/>
        <location filename="../IDlgCombineTracks.ui" line="120"/>
        <location filename="../IDlgCombineTracks.ui" line="133"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="82"/>
        <source>Remove track from list</source>
        <translation>Borrar track de la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="96"/>
        <source>Selected Tracks</source>
        <translation>Tracks Seleccionados</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="117"/>
        <source>Move track up in list</source>
        <translation>Mover track hacia arriba en la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="130"/>
        <source>Move track down in list</source>
        <translation>Mover track hacia abajo en la lista</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="146"/>
        <source>New Track Name</source>
        <translation>Nombre del Nuevo Track</translation>
    </message>
    <message>
        <location filename="../IDlgCombineTracks.ui" line="153"/>
        <source>New Track</source>
        <translation>Nuevo Track</translation>
    </message>
</context>
<context>
    <name>IDlgConfig</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Diálogo</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="14"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="24"/>
        <source>Environment</source>
        <translation>Entorno</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="30"/>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="36"/>
        <source>ABCDEFGHabcdefgh123456789</source>
        <translation>ABCDEFGHabcdefgh123456789</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="56"/>
        <location filename="../IDlgConfig.ui" line="67"/>
        <location filename="../IDlgConfig.ui" line="436"/>
        <location filename="../IDlgConfig.ui" line="679"/>
        <location filename="../IDlgConfig.ui" line="860"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="49"/>
        <source>Waypoint text color</source>
        <translation>Color de texto del waypoint</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="84"/>
        <source>Units</source>
        <translation>Unidades de medida</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="90"/>
        <source>Metric</source>
        <translation>Métrico</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="97"/>
        <source>Nautic</source>
        <translation>Náutico</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="104"/>
        <source>Imperial</source>
        <translation>Imperial</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="160"/>
        <source>Mouse Wheel</source>
        <translation>Rueda del ratón</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="166"/>
        <source>Flip</source>
        <translation>Invertir</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="176"/>
        <source>Map Canvas</source>
        <translation>Opciones del mapa</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="182"/>
        <source>The scale bar in the bottom right corner</source>
        <translation>La barra de escala en la esquina inferior derecha</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="185"/>
        <source>Show scale</source>
        <translation>Mostrar escala</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="192"/>
        <source>The compass rose in the bottom right corner</source>
        <translation>Muestra la rosa de los puntos cardinales en la esquina inferior derecha</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="195"/>
        <source>Show north</source>
        <translation>Mostrar norte</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="202"/>
        <source>The profile graph for the active track in the bottom left corner</source>
        <translation>El perfil del track activo en la esquina inferior izquierda</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="205"/>
        <source>Show track profile preview</source>
        <translation>Mostrar vista previa del perfil del track</translation>
    </message>
    <message>
        <source>Show Hmin, Hmax and Vmax on the active track</source>
        <translation type="obsolete">Mostrar Hmin, Hmax y Vmax sobre el track activo</translation>
    </message>
    <message>
        <source>Show track maxima</source>
        <translation type="obsolete">Mostrar máximos del track</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="255"/>
        <source>Show information as tooltip for items under cursor in vector maps.</source>
        <translation>Muestra información en forma de ventana de ayuda contextual para los elementos bajo el cursor en mapas vectoriales.</translation>
    </message>
    <message>
        <source>Tooltips (vector maps)</source>
        <translation type="obsolete">Tooltips (mapas vectoriales)</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="226"/>
        <source>Show zoom level in the top left corner</source>
        <translation>Muestra el nivel de zoom en la esquina superior izquierda</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="229"/>
        <source>Show zoom level</source>
        <translation>Mostrar el nivel de zoom</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="236"/>
        <source>Rendering the map with anti-aliasing uses a lot of CPU power. Best to disable it for weak CPUs.</source>
        <translation>Dibujar el mapa con anti-aliasing consume mucha CPU. Lo mejor es desactivarlo en CPU antiguas.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="239"/>
        <source>Anti-aliasing</source>
        <translation>Anti-aliasing</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="249"/>
        <source>Vector Maps</source>
        <translation>Mapas vectoriales</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="258"/>
        <source>Tooltips</source>
        <translation>Descripciones emergentes</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="265"/>
        <source>Element Info</source>
        <translation>Información de elemento</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="272"/>
        <source>Reduce POI icons</source>
        <translation>Reducir iconos POI</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="281"/>
        <source>Zoom level threshold for POIs:</source>
        <translation>Umbral de zoom para POIs:</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="294"/>
        <source>Defines at which zoom level POIs are drawn.</source>
        <translation>Define a qué nivel de zoom se dibujan los POIs.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="314"/>
        <source>Zoom level threshold for POI labels:</source>
        <translation>Umbral de zoom para etiquetas de POIs:</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="327"/>
        <source>Defines at which zoom level POIs are labeled.</source>
        <translation>Define a qué nivel de zoom se muestran etiquetas de POIs.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="570"/>
        <source>Geo Database</source>
        <translation>Archivo de Geodatos</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="581"/>
        <source>Use database</source>
        <translation>Usar base de datos</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="615"/>
        <source>Save workspace on exit</source>
        <translation>Guardar espacio de trabajo al salir</translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="obsolete">Red</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="368"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="1027"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Mouseless control&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;
&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; cellspacing=&quot;2&quot; cellpadding=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + right&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	move map view to east&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + left&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	move map view to west&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + up&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	move map view to north&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + down&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	move map view to south&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;+&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	zoom in&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;-&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	zoom out&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Mouse control&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;wheel		zoom in / out&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;left button		select&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;right button	context menu&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt+move mouse	move map&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Control sin ratón&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;
&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; cellspacing=&quot;2&quot; cellpadding=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + cursor derecho&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	mover vista del mapa al este&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + cursor izquierdo&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	mover vista del mapa al oeste&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + cursor arriba&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	mover vista del mapa al norte&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt + cursor abajo&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	mover vista del mapa al sur&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;+&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	acercar&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;-&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;	alejar&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Control con ratón&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;rueda		acercar/alejar&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;botón izquierdo	seleccionar&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;botón derecho	menú contextual&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;alt+mover ratón	mover mapa&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>enable</source>
        <translation type="obsolete">activar</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="obsolete">URL</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="393"/>
        <location filename="../IDlgConfig.ui" line="773"/>
        <source>Port</source>
        <translation>Puerto</translation>
    </message>
    <message>
        <source>00000; </source>
        <translation type="obsolete">00000;</translation>
    </message>
    <message>
        <source>8080</source>
        <translation type="obsolete">8080</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation type="obsolete">Navegador</translation>
    </message>
    <message>
        <source>Firefox</source>
        <translation type="obsolete">Firefox</translation>
    </message>
    <message>
        <source>Konqueror</source>
        <translation type="obsolete">Konqueror</translation>
    </message>
    <message>
        <source>other (needs command line)</source>
        <translation type="obsolete">otros (necesaria la linea de comandos)</translation>
    </message>
    <message>
        <source>my command %s</source>
        <translation type="obsolete">my comando %s</translation>
    </message>
    <message>
        <source>%s will be replaced by URL</source>
        <translation type="obsolete">%s se sustituirá por la URL</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="726"/>
        <source>Device &amp;&amp; Xfer</source>
        <translation>Dispositivo &amp;&amp; Transferencia</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="732"/>
        <source>Select the device you want to setup.</source>
        <translation>Seleccione el dispositivo que desee configurar.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="742"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="751"/>
        <source>IP Address</source>
        <translation>Dirección IP</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="763"/>
        <source>If your device is accessed by TCP/IP you can give a hard coded address. Leave blank for &quot;QLandkarte M&quot; as the driver will query the device by UDP broadcast.</source>
        <translation>Si se accede a su dispositivo por TCP/IP,  podrá indicar una dirección fija. Deje el espacio en blanco para &quot;QLandkarte M&quot; pues el controlador consultará el dispositivo mediante difusiones UDP.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="783"/>
        <source>Add TCP/IP port for Device. Set to 0 for &quot;QLandkarte M&quot;.</source>
        <translation>Añada el puerto TCP/IP para el dispositivo. Póngalo a 0 para &quot;QLandkarte M&quot;.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="786"/>
        <source>4242</source>
        <translation>4242</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="798"/>
        <source>Serial Port</source>
        <translation>Puerto Serie</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="808"/>
        <source>Pass something like &quot;/dev/ttyS0&quot; or &quot;/dev/rfcomm0&quot; for serial Garmin devices or NMEA devices. For Garmin USB devices leave blank.</source>
        <translation>Es algo como &quot; /dev/ttyS0&quot; o &quot; /dev/rfcomm0&quot; para dispositivos NMEA o Garmin de puerto serie. Para dispositivos Garmin USB, dejar en blanco.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="818"/>
        <source>Baud rate</source>
        <translation>Velocidad en baudios</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="828"/>
        <source>Baud rate for Serial Port</source>
        <translation>Velocidad en baudios del Puerto Serie</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="838"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="850"/>
        <source>Select your Garmin device from list. If your device is not supported use &quot;whatGarmin&quot; and download waypoints to create a protocol query.</source>
        <translation>Seleccione su dispositivo Garmin en la lista. Si su dispositivo no está soportado utilice &quot;whatGarmin&quot; y descargue waypoints para crear una consulta de protocolo.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Mouseless control&lt;/span&gt; &lt;/p&gt;
&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; cellspacing=&quot;2&quot; cellpadding=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + right&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;move map view to east&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + left&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;move map view to west&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + up&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;move map view to north&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + down&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;move map view to south&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;+&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;zoom in&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;-&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;zoom out&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Combianaciones de teclado&lt;/span&gt; &lt;/p&gt;
&lt;table border=&quot;0&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px;&quot; cellspacing=&quot;2&quot; cellpadding=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + →&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;desplazar el mapa al este&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + ←&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;desplazar el mapa al oeste&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + up&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;desplazar el mapa al norte&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;alt + ↓&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;desplazar el mapa al sur&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;+&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;ampliar&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;-&lt;/p&gt;&lt;/td&gt;
&lt;td&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;reducir&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="872"/>
        <source>Character Set</source>
        <translation>Conjunto de Caracteres</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="672"/>
        <source>Database path:</source>
        <translation>Ruta de la base de datos:</translation>
    </message>
    <message>
        <source>Reduce POI icons (vector maps)</source>
        <translation type="obsolete">Reducir iconos POI (mapas vectoriales)</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="699"/>
        <source>You have to restart QLandkarte GT to make the database changes taking effect.</source>
        <translation>Debe reiniciar QLandkarte GT para que los cambios en la base de datos tengan efecto.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="374"/>
        <source>manual configuration</source>
        <translation>Configuración manual</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="114"/>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="120"/>
        <source>UTC</source>
        <translation>UTC</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="127"/>
        <source>Local</source>
        <translation>Local</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="134"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="219"/>
        <source>Show track elevation info</source>
        <translation>Mostrar información de alturas del track</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="212"/>
        <source>Show clock</source>
        <translation>Mostrar reloj</translation>
    </message>
    <message>
        <source>Element Info (vector maps)</source>
        <translation type="obsolete">Información de elemento (mapas vectoriales)</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="362"/>
        <source>Services &amp;&amp; Paths</source>
        <translation>Servicios &amp;&amp; Rutas</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="383"/>
        <source>Host</source>
        <translation>Servidor</translation>
    </message>
    <message>
        <source>00000</source>
        <translation type="obsolete">16x {00000?}</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="415"/>
        <source>Streaming Map Cache</source>
        <translation>Caché de Mapa Streaming</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="429"/>
        <source>Cache Path: </source>
        <translation>Ruta de la caché: </translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="464"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="493"/>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="513"/>
        <source>Expire in</source>
        <translation>Caduca en</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="542"/>
        <source>Days</source>
        <translation>días</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="622"/>
        <source> and every </source>
        <translation> y cada </translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="639"/>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="886"/>
        <source>Define custom icons for Garmin Devices.</source>
        <translation>Seleccione iconos personalizados para los dispositivos Garmin.</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="889"/>
        <source>Customize Waypoint Icons...</source>
        <translation>Personalizar los iconos de los waypoints...</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="909"/>
        <source>Watch Dog</source>
        <translation type="unfinished">Vigilancia</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="925"/>
        <source>Upload All</source>
        <translation>Cargar todo</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="931"/>
        <location filename="../IDlgConfig.ui" line="964"/>
        <source>Waypoints</source>
        <translation>Waypoints</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="938"/>
        <location filename="../IDlgConfig.ui" line="971"/>
        <source>Tracks</source>
        <translation>Tracks</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="958"/>
        <source>Download All</source>
        <translation>Descargar todo</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="988"/>
        <source>Sound after Transfer</source>
        <translation>Sonido después de la transferencia</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="994"/>
        <source>Play</source>
        <translation>Reproducir</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="1021"/>
        <source>Keys</source>
        <translation>Combinaciones de teclado</translation>
    </message>
    <message>
        <source>&lt;b&gt;Mouseless control&lt;/b&gt;
&lt;table&gt;
&lt;tr&gt;&lt;td&gt;alt + right&lt;/td&gt;&lt;td&gt;move map view to east&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;alt + left&lt;/td&gt;&lt;td&gt;move map view to west&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;alt + up&lt;/td&gt;&lt;td&gt;move map view to north&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;alt + down&lt;/td&gt;&lt;td&gt;move map view to south&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;+&lt;/td&gt;&lt;td&gt;zoom in&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;-&lt;/td&gt;&lt;td&gt;zoom out&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;
&lt;b&gt;3D view&lt;/b&gt;
&lt;table&gt;
&lt;tr&gt;&lt;td&gt;m + left mouse&lt;/td&gt;&lt;td&gt;move map&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;m + scroll mouse / pageup/pagedown&lt;/td&gt;&lt;td&gt;zoom map&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;home/end&lt;/td&gt;&lt;td&gt;increase/decrease map area&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;m + left mouse&lt;/td&gt;&lt;td&gt;move map&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;l + left mouse&lt;/td&gt;&lt;td&gt;move light source horizontally&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;h + left mouse&lt;/td&gt;&lt;td&gt;move light source vertically&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</source>
        <translation type="obsolete">&lt;b&gt;Control sin ratón&lt;/b&gt;
&lt;table&gt;
&lt;tr&gt;&lt;td&gt;alt + → &lt;/td&gt;&lt;td&gt;desplazar el mapa al este&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;alt + ← &lt;/td&gt;&lt;td&gt;desplazar el mapa al oeste&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;alt + up &lt;/td&gt;&lt;td&gt;desplazar el mapa al norte&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;alt + ↓ &lt;/td&gt;&lt;td&gt;desplazar el mapa al sur&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;+&lt;/td&gt;&lt;td&gt;ampliar&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;-&lt;/td&gt;&lt;td&gt;reducir&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;
&lt;b&gt;vista 3D&lt;/b&gt;
&lt;table&gt;
&lt;tr&gt;&lt;td&gt;m + botón izq &lt;/td&gt;&lt;td&gt; mover el mapa&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;m + rueda del ratón &lt;/td&gt;&lt;td&gt; ampliar/reducir el mapa&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;m + Re-Pág/Av-Pág &lt;/td&gt;&lt;td&gt; ampliar/reducir el mapa&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;Inicio/Fin &lt;/td&gt;&lt;td&gt; aumentar/disminuir el area del mapa&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;m + botón izq &lt;/td&gt;&lt;td&gt; mover el mapa&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;l + botón izq &lt;/td&gt;&lt;td&gt; desplazar iluminación horizontalmente&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;h + botón izq &lt;/td&gt;&lt;td&gt; desplazar iluminación verticalmente&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt;</translation>
    </message>
    <message>
        <location filename="../IDlgConfig.ui" line="945"/>
        <location filename="../IDlgConfig.ui" line="978"/>
        <source>Routes</source>
        <translation>Rutas</translation>
    </message>
</context>
<context>
    <name>IDlgConfig3D</name>
    <message>
        <location filename="../IDlgConfig3D.ui" line="14"/>
        <source>3D View Options...</source>
        <translation>Opciones de la vista 3D...</translation>
    </message>
    <message>
        <location filename="../IDlgConfig3D.ui" line="29"/>
        <source>Model Quality</source>
        <translation>Calidad del modelo</translation>
    </message>
    <message>
        <location filename="../IDlgConfig3D.ui" line="39"/>
        <source>Couple Elevation/POV</source>
        <translatorcomment>Posiblemente haya mejores traducciones...</translatorcomment>
        <translation>Emparejar Elevación/PDV</translation>
    </message>
</context>
<context>
    <name>IDlgConvertToTrack</name>
    <message>
        <location filename="../IDlgConvertToTrack.ui" line="14"/>
        <source>Intermediate track points...</source>
        <translation>Puntos intermedios del track...</translation>
    </message>
    <message>
        <location filename="../IDlgConvertToTrack.ui" line="29"/>
        <source>Select interval to place additional trackpoints. &quot;none&quot; will just use the available points.</source>
        <translation>Seleccione el intervalo para añadir puntos adicionales al track. &quot;ninguno&quot; sólo utilizará los puntos disponibles.</translation>
    </message>
    <message>
        <location filename="../IDlgConvertToTrack.ui" line="42"/>
        <source>add no elevation data</source>
        <translation>no añadir información de alturas</translation>
    </message>
    <message>
        <location filename="../IDlgConvertToTrack.ui" line="52"/>
        <source>add elevation from loaded DEM data</source>
        <translation>añadir alturas desde los datos DEM cargados</translation>
    </message>
    <message>
        <location filename="../IDlgConvertToTrack.ui" line="59"/>
        <source>add elevation from www.geonames.org</source>
        <translation>añadir alturas desde www.geonames.org</translation>
    </message>
    <message>
        <location filename="../IDlgConvertToTrack.ui" line="75"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
</context>
<context>
    <name>IDlgCreateWorldBasemap</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Diálogo</translation>
    </message>
    <message>
        <source>./basemap.tif</source>
        <translation type="obsolete">./basemap.tif</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>level</source>
        <translation type="obsolete">nivel</translation>
    </message>
    <message>
        <source>0px x 0px</source>
        <translation type="obsolete">0px x 0px</translation>
    </message>
</context>
<context>
    <name>IDlgCropMap</name>
    <message>
        <location filename="../IDlgCropMap.ui" line="14"/>
        <source>Crop map...</source>
        <translation>Recortar mapa...</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="24"/>
        <source>Input:</source>
        <translation>Entrada:</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="31"/>
        <location filename="../IDlgCropMap.ui" line="45"/>
        <source>TextLabel</source>
        <translation>EtiquetaDeTexto</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="38"/>
        <source>Output:</source>
        <translation>Salida:</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="52"/>
        <source>Overview</source>
        <translation>Vista general</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="61"/>
        <source>x2</source>
        <translation>x2</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="68"/>
        <source>x4</source>
        <translation>x4</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="75"/>
        <source>x8</source>
        <translation>x8</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="82"/>
        <source>x16</source>
        <translation>x16</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="101"/>
        <source>Start</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="114"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="127"/>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <location filename="../IDlgCropMap.ui" line="148"/>
        <source>Press &quot;Start&quot;</source>
        <translation>Pulse &quot;Inicio&quot;</translation>
    </message>
</context>
<context>
    <name>IDlgDelWpt</name>
    <message>
        <location filename="../IDlgDelWpt.ui" line="13"/>
        <source>Delete waypoint by ...</source>
        <translation>Waypoint eliminado por ...</translation>
    </message>
    <message>
        <location filename="../IDlgDelWpt.ui" line="28"/>
        <source>type</source>
        <translation>tipo</translation>
    </message>
</context>
<context>
    <name>IDlgDeviceExportPath</name>
    <message>
        <location filename="../IDlgDeviceExportPath.ui" line="14"/>
        <source>Select output path...</source>
        <translation>Seleccionar ruta de salida...</translation>
    </message>
    <message>
        <location filename="../IDlgDeviceExportPath.ui" line="20"/>
        <source>Where to place..?</source>
        <translation>¿Dónde poner...?</translation>
    </message>
    <message>
        <location filename="../IDlgDeviceExportPath.ui" line="30"/>
        <source>Select a sub-directory from above or enter a new one</source>
        <translation>Seleccione un subdirectorio de los de arriba o introduzca uno nuevo</translation>
    </message>
</context>
<context>
    <name>IDlgEditDistance</name>
    <message>
        <source>Edit distance overlay ...</source>
        <translation type="obsolete">Editar distancia ...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nombre</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="obsolete">Comentario</translation>
    </message>
</context>
<context>
    <name>IDlgEditFolder</name>
    <message>
        <location filename="../IDlgEditFolder.ui" line="14"/>
        <source>Edit folder ...</source>
        <translation>Editar carpeta ...</translation>
    </message>
    <message>
        <location filename="../IDlgEditFolder.ui" line="22"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../IDlgEditFolder.ui" line="32"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../IDlgEditFolder.ui" line="42"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
</context>
<context>
    <name>IDlgEditMapLevel</name>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="14"/>
        <source>Edit map level ...</source>
        <translation>Editar nivel del mapa ...</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="22"/>
        <source>zoom levels</source>
        <translation>niveles de zoom</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="56"/>
        <source>files</source>
        <translation>archivos</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="73"/>
        <source>Select files</source>
        <translation>Seleccionar archivos</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="83"/>
        <source>Add files to list</source>
        <translation>Añadir archivos a la lista</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="96"/>
        <source>Delete file from list</source>
        <translation>Borrar archivo de la lista</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="109"/>
        <source>Move file up in list</source>
        <translation>Mover el archivo hacia arriba en la lista</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="122"/>
        <source>Move file down in list</source>
        <translation>Mover el archivo hacia abajo en la lista</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Select files&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Seleccionar archvos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../IDlgEditMapLevel.ui" line="76"/>
        <location filename="../IDlgEditMapLevel.ui" line="86"/>
        <location filename="../IDlgEditMapLevel.ui" line="99"/>
        <location filename="../IDlgEditMapLevel.ui" line="112"/>
        <location filename="../IDlgEditMapLevel.ui" line="125"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Add files to list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Añadir archivos a la lista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Delete file from list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Borrar archivo de la lista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Move file up in list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Mover el archivo hacia arriba en la lista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Move file down in list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;URW Gothic L&apos;; font-size:9pt; font-weight:200; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Mover el archivo hacia abajo en la lista&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>IDlgEditRoute</name>
    <message>
        <location filename="../IDlgEditRoute.ui" line="13"/>
        <source>Edit Route ...</source>
        <translation>Editar Ruta ...</translation>
    </message>
    <message>
        <location filename="../IDlgEditRoute.ui" line="28"/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>IDlgEditWpt</name>
    <message>
        <location filename="../IDlgEditWpt.ui" line="14"/>
        <source>Edit Waypoint ...</source>
        <translation>Editar Waypoint ...</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="32"/>
        <source>Data</source>
        <translation>Datos</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="40"/>
        <source>Symbol &amp; Name</source>
        <translation>Símbolo y Nombre</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="52"/>
        <source>Parent waypoint. Attach this waypoint to a geocache.</source>
        <translation>Waypoint padre. Adjunte este waypoint a un geocache.</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="65"/>
        <location filename="../IDlgEditWpt.ui" line="262"/>
        <location filename="../IDlgEditWpt.ui" line="455"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="72"/>
        <source>sticky</source>
        <translation>pegado</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="81"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="100"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="120"/>
        <source>m,</source>
        <translation>m,</translation>
    </message>
    <message utf8="true">
        <location filename="../IDlgEditWpt.ui" line="140"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="149"/>
        <source>Altitude</source>
        <translation>Altitud</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="174"/>
        <location filename="../IDlgEditWpt.ui" line="218"/>
        <source>m</source>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="196"/>
        <source>Proximity Dist.</source>
        <translation>Dist. de Proximidad</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="240"/>
        <source>Webpage</source>
        <translation>Página Web</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="255"/>
        <source>None</source>
        <translation>Ninguna</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="281"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="307"/>
        <source>More</source>
        <translation>Más</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="314"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="322"/>
        <source>Show hidden information</source>
        <translation>Mostrar información oculta</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="330"/>
        <source>Images</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="344"/>
        <source>If you use the word &quot;Spoiler&quot; in the comment, the image might be treated special on your GPSr. 

For modern Garmin device select &quot;Garmin Mass Storage&quot; device to exchange pictures and spoilers.</source>
        <translation>Si utiliza la palabra &quot;Spoiler&quot; en el comentario, la imagen puede ser tratada de forma especial en su GPS.

En los dispositivos modernos de Garmin, seleccione &quot;Almacenamiento masivo de Garmin&quot; para intercambiar imágenes y spoilers.</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="359"/>
        <source>Get spoilers!</source>
        <translation>¡Obtener spoilers!</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="391"/>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="426"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="703"/>
        <source>Create Buddies</source>
        <translation>Crear Buddies</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Siguiente</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="605"/>
        <source>Barcode</source>
        <translation>Código de Barras</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="632"/>
        <source>xx</source>
        <translation>xx</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Geocache buddies are additional waypoints of a geocache. QLandkarte tries to search the description for well known coordinate strings and adds them to the above list as buddies. You can select if you want these buddies exported as waypoints when saving the geocache to a gpx file (File -&amp;gt; Export geo data)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Buddies geocache son waypoints adicionales de un geocache. QLandkarte intenta buscar coordenadas en la descripción y las añade en la lista superior como buddies. Puede seleccionar si quiere que estos buddies se exporten como waypoints al guardar el geocache en un archivo gpx (Archivo -&amp;gt; Exportar datos geográficos)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Export buddies</source>
        <translation type="obsolete">Exportar buddies</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="413"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="531"/>
        <source>no image</source>
        <translation>sin imagen</translation>
    </message>
    <message>
        <source>Wpt. Summary</source>
        <translation type="obsolete">Indice de Wpt</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="651"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="644"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../IDlgEditWpt.ui" line="271"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
<context>
    <name>IDlgExport</name>
    <message>
        <location filename="../IDlgExport.ui" line="14"/>
        <source>Export data...</source>
        <translation>Exportar datos...</translation>
    </message>
    <message>
        <location filename="../IDlgExport.ui" line="34"/>
        <source>All</source>
        <translation>Todo</translation>
    </message>
</context>
<context>
    <name>IDlgImportImages</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Diálogo</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="14"/>
        <source>Import pictures</source>
        <translation>Importar imágenes</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="20"/>
        <source>Import pictures from</source>
        <translation>Importar imágenes desde</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="29"/>
        <source>./</source>
        <translation>./</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="36"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="52"/>
        <source>Create local copy</source>
        <translation>Crear copia local</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="58"/>
        <source>~600x400</source>
        <translation>~600x400</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="65"/>
        <source>~1024x700</source>
        <translation>~1024x700</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="72"/>
        <source>just link external file</source>
        <translation>solo enlazar archivo externo</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="79"/>
        <source>original size</source>
        <translation>tamaño original</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="89"/>
        <source>Reference source</source>
        <translation>Origen de la referencia</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="95"/>
        <source>From EXIF header</source>
        <translation>De la cabecera EXIF</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="102"/>
        <location filename="../IDlgImportImages.ui" line="119"/>
        <source>Time reference</source>
        <translation>Referencia de tiempo</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="109"/>
        <location filename="../IDlgImportImages.ui" line="169"/>
        <source>Position reference</source>
        <translation>Referencia de posición</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="125"/>
        <source>Take a picture of the GPS time display as the first photo in the series. Double-click that picture in the above list and enter the GPS time in the text box. QLandkarte GT will derive the delta time between camera
and GPS and adjust all image time-stamps before correlating them with loaded track points.</source>
        <translation>Tome una foto del reloj de su dispositivo GPS como la primera foto de la serie. Haga doble click en esa imagen en la lista de arriba e introduzca manualmente la hora GPS en la caja de texto. QLandkarte GT calculará la diferencia entre la cámara y el GPS. y ajustará todas las marcas de tiempo de las imágenes antes de buscar un punto coincidente en el track actualmente cargado.</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="175"/>
        <source>Take a picture of the GPS position display as the first photo in the series. Double-click that picture in the above list and enter the GPS position. QLandkarte GT will locate the closest track point and derive the delta time between camera and GPS and adjust all image time-stamps before correlating them with loaded track points.</source>
        <translation>Haga una foto de la pantalla con la posición del GPS como primera foto de la serie. Haga doble click en esa imagen en la lista de arriba e introduzca la posición del GPS. QLandkarte GT encontrará el punto del track más cercano y calculará la diferencia de tiempo entre la cámara y el GPS y ajustará todas las marcas de tiempo de las imágenes antes de buscar un punto coincidente en el track actualmente cargado.</translation>
    </message>
    <message>
        <source>Befor you start taking any picture take a picture of the clock on your GPS device. Select the picture from the list above and enter the timestamp manually. QLandkarte GT will derive the delta between your camera and your GPS. The offset is used to adust all timestamps befor finding a matching point in the currently loaded tracks.</source>
        <translation type="obsolete">Antes de que empiece a hacer fotos tome una del reloj de su dispositivo GPS. Seleccione la imagen en la lista de arriba e introduzca manualmente la marca de tiempo. QLandkarte GT calculará la diferencia entre su cámara y su GPS. La compensación se utiliza para ajustar todas las marcas de tiempo antes de buscar un punto coincidente en los tracks actualmente cargados.</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="144"/>
        <source>Select a picture from the list and enter the timestamp</source>
        <translation>Seleccione una imagen de la lista e introduzca la marca de tiempo</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="154"/>
        <source>dd.MM.yy HH:mm:ss</source>
        <translation>dd.MM.aa HH:mm:ss</translation>
    </message>
    <message>
        <source>Befor you start taking any picture take a picture of the position on your GPS device. Select the picture from the list above and enter the position manually. QLandkarte GT will find the closest track point to that position and derive the time delta bewteen that point and the selcted picture. The offset is used to adust all timestamps befor finding a matching point in the currently loaded tracks.</source>
        <translation type="obsolete">Antes de que empiece a hacer fotos haga una de la posición de su dispositivo GPS. Seleccione la imagen de la lista de arriba e introduzca la posición manualmente. QLandkarte GT encontrará el punto del track más cercano a esa posición y calculará la diferencia de tiempo entre ese punto y la imagen seleccionada. La compensación se utiliza para ajustar todas las marcas de tiempo antes de buscar un punto coincidente en los tracks actualmente cargados.</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="193"/>
        <source>Select a picture from the list and enter the position</source>
        <translation>Seleccione una imagen de la lista e introduzca la posición</translation>
    </message>
    <message>
        <location filename="../IDlgImportImages.ui" line="203"/>
        <source>The position has to be in WGS84 datum. The position format is: N|Sdd mm.mmm E|Wddd mm.mmm</source>
        <translation>La posición debe estar en datum WGS84. El formato de la posición es: N|Sdd mm.mmm E|Wddd mm.mmm</translation>
    </message>
</context>
<context>
    <name>IDlgLoadOnlineMap</name>
    <message>
        <location filename="../IDlgLoadOnlineMap.ui" line="14"/>
        <source>Available Online Map ...</source>
        <translation>Mapas Online disponibles...</translation>
    </message>
    <message>
        <location filename="../IDlgLoadOnlineMap.ui" line="31"/>
        <source>Download map file to:</source>
        <translation>Descargar archivo de mapa en:</translation>
    </message>
    <message>
        <location filename="../IDlgLoadOnlineMap.ui" line="38"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../IDlgLoadOnlineMap.ui" line="45"/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>IDlgMapJNXConfig</name>
    <message>
        <location filename="../IDlgMapJNXConfig.ui" line="14"/>
        <source>Information...</source>
        <translation>Información...</translation>
    </message>
    <message>
        <location filename="../IDlgMapJNXConfig.ui" line="21"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
</context>
<context>
    <name>IDlgMapOSMConfig</name>
    <message>
        <source>Config --- OSM ---</source>
        <translation type="obsolete">Configurar --- OSM ---</translation>
    </message>
    <message>
        <source>Config --- Tile Server ---</source>
        <translation type="obsolete">Configuración --- Servidor de Teselas ---</translation>
    </message>
    <message>
        <source>URL</source>
        <translation type="obsolete">URL</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation type="obsolete">Copyright</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">Nombre</translation>
    </message>
    <message>
        <source>Double click a custom map to edit the values</source>
        <translation type="obsolete">Haga doble click sobre un mapa personalizado para editar los valores</translation>
    </message>
    <message>
        <source>Placeholders to be used inside &quot;Path&quot; definition: %1 = osm_zoom; %2 = osm_x; %3 = osm_y</source>
        <translation type="obsolete">Sustituciones que usar en la definición del &quot;Path&quot;: %1 = osm_zoom; %2 = osm_x; %3 = osm_y</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="obsolete">Añadir</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Borrar</translation>
    </message>
</context>
<context>
    <name>IDlgMapQMAPConfig</name>
    <message>
        <location filename="../IDlgMapQMAPConfig.ui" line="14"/>
        <source>Information...</source>
        <translation>Información...</translation>
    </message>
    <message>
        <location filename="../IDlgMapQMAPConfig.ui" line="21"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
</context>
<context>
    <name>IDlgMapRMPConfig</name>
    <message>
        <location filename="../IDlgMapRMPConfig.ui" line="14"/>
        <source>Information...</source>
        <translation>Información...</translation>
    </message>
    <message>
        <location filename="../IDlgMapRMPConfig.ui" line="21"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
</context>
<context>
    <name>IDlgMapTDBConfig</name>
    <message>
        <location filename="../IDlgMapTDBConfig.ui" line="14"/>
        <source>Configure Garmin Map...</source>
        <translation>Configurar el mapa Garmin...</translation>
    </message>
    <message>
        <location filename="../IDlgMapTDBConfig.ui" line="21"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
    <message>
        <source>use typ (if available)</source>
        <translation type="obsolete">Utilizar el fichero TYP (si esta disponible)</translation>
    </message>
    <message>
        <source>text above line</source>
        <translation type="obsolete">texto sobre la línea</translation>
    </message>
</context>
<context>
    <name>IDlgMapTmsConfig</name>
    <message>
        <location filename="../IDlgMapTmsConfig.ui" line="14"/>
        <source>Config TMS</source>
        <translation>Configurar TMS</translation>
    </message>
    <message>
        <location filename="../IDlgMapTmsConfig.ui" line="31"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../IDlgMapTmsConfig.ui" line="41"/>
        <source>Placeholders to be used inside &quot;Path&quot; definition: %1 = zoom; %2 = x; %3 = y</source>
        <translation>Sustituciones que usar en la definición del &quot;Path&quot;: %1 = zoom; %2 = x; %3 = y</translation>
    </message>
    <message>
        <location filename="../IDlgMapTmsConfig.ui" line="51"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location filename="../IDlgMapTmsConfig.ui" line="61"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
</context>
<context>
    <name>IDlgMapWmsConfig</name>
    <message>
        <location filename="../IDlgMapWmsConfig.ui" line="14"/>
        <source>Config WMS</source>
        <translation>Configurar WMS</translation>
    </message>
    <message>
        <location filename="../IDlgMapWmsConfig.ui" line="24"/>
        <source>Map</source>
        <translation>Mapa</translation>
    </message>
    <message>
        <location filename="../IDlgMapWmsConfig.ui" line="30"/>
        <source>File:</source>
        <translation>Archivo:</translation>
    </message>
    <message>
        <location filename="../IDlgMapWmsConfig.ui" line="47"/>
        <source>Property</source>
        <translation>Propiedad</translation>
    </message>
    <message>
        <location filename="../IDlgMapWmsConfig.ui" line="52"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../IDlgMapWmsConfig.ui" line="61"/>
        <source>Server</source>
        <translation>Servidor</translation>
    </message>
</context>
<context>
    <name>IDlgMultiColorConfig</name>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="14"/>
        <source>Multi Color Setup...</source>
        <translation>Configuración Multi Color</translation>
    </message>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="20"/>
        <location filename="../IDlgMultiColorConfig.ui" line="79"/>
        <source>TextLabel</source>
        <translation>Etiqueta de Texto</translation>
    </message>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="29"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="36"/>
        <source>Min</source>
        <translation>Mín</translation>
    </message>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="59"/>
        <source>Max</source>
        <translation>Máx</translation>
    </message>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="86"/>
        <source>Min Color</source>
        <translation>Color Mín</translation>
    </message>
    <message>
        <location filename="../IDlgMultiColorConfig.ui" line="93"/>
        <source>Max Color</source>
        <translation>Color Máx</translation>
    </message>
</context>
<context>
    <name>IDlgNoMapConfig</name>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="14"/>
        <source>Map Setup...</source>
        <translation>Configuración de mapa...</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="22"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="31"/>
        <source>restore default</source>
        <translation>restablecer predeterminada</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="34"/>
        <location filename="../IDlgNoMapConfig.ui" line="48"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="45"/>
        <source>projection wizzard</source>
        <translation>asistente de proyección</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="64"/>
        <source>Scale x</source>
        <translation>Escala x</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="71"/>
        <source>Scale y</source>
        <translation>Escala y</translation>
    </message>
    <message>
        <location filename="../IDlgNoMapConfig.ui" line="84"/>
        <source>-</source>
        <translation>-</translation>
    </message>
</context>
<context>
    <name>IDlgParentWpt</name>
    <message>
        <location filename="../IDlgParentWpt.ui" line="14"/>
        <source>Select Parent Waypoint ...</source>
        <translation>Seleccionar waypoint padre ...</translation>
    </message>
</context>
<context>
    <name>IDlgProjWizzard</name>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="14"/>
        <source>Proj4 Wizzard</source>
        <translation>Asistente Proj4</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="138"/>
        <source>Lon/Lat</source>
        <translation>Lon/Lat</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="145"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="29"/>
        <source>Mercator</source>
        <translation>Mercator</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="38"/>
        <source>UTM</source>
        <translation>UTM</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="45"/>
        <source>zone</source>
        <translation>zona</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="82"/>
        <source>user defined</source>
        <translation>Definido por el usuario</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="94"/>
        <source>Datum</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="117"/>
        <source>Result:</source>
        <translation>Resultado:</translation>
    </message>
    <message>
        <location filename="../IDlgProjWizzard.ui" line="131"/>
        <source>World Mercator (OSM)</source>
        <translation>World Mercator (OSM)</translation>
    </message>
</context>
<context>
    <name>IDlgScreenshot</name>
    <message>
        <location filename="../IDlgScreenshot.ui" line="14"/>
        <source>Screenshot...</source>
        <translation>Capturar pantalla del dispositivo ...</translation>
    </message>
    <message>
        <location filename="../IDlgScreenshot.ui" line="35"/>
        <source>This will take a screen shot from your connected GPSr. Simply press &apos;Acquire&apos; to download the current screen. In addition, it will copy the image to your clipboard.</source>
        <translation>Esto le permitirá capturar la pantalla actual del GPS conectado. Pulse &apos;Capturar&apos; para descargar la imagen actual. Además, copiará la imagen al portapapeles.</translation>
    </message>
    <message>
        <location filename="../IDlgScreenshot.ui" line="50"/>
        <source>Acquire</source>
        <translation>Capturar</translation>
    </message>
    <message>
        <location filename="../IDlgScreenshot.ui" line="60"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
</context>
<context>
    <name>IDlgSelGeoDBFolder</name>
    <message>
        <location filename="../IDlgSelGeoDBFolder.ui" line="14"/>
        <source>Select folder...</source>
        <translation>Seleccionar carpeta...</translation>
    </message>
</context>
<context>
    <name>IDlgSetupGarminIcons</name>
    <message>
        <location filename="../IDlgSetupGarminIcons.ui" line="14"/>
        <source>Garmin Waypoint Icons</source>
        <translation>Iconos de Waypoint de Garmin</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGarminIcons.ui" line="32"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGarminIcons.ui" line="47"/>
        <source>Source</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGarminIcons.ui" line="55"/>
        <source>Send to device</source>
        <translation>Enviar al dispositivo</translation>
    </message>
</context>
<context>
    <name>IDlgSetupGrid</name>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="14"/>
        <source>Setup Grid...</source>
        <translation>Configurar rejilla...</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="22"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="31"/>
        <source>restore default</source>
        <translation>restablecer predeterminada</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="34"/>
        <location filename="../IDlgSetupGrid.ui" line="48"/>
        <location filename="../IDlgSetupGrid.ui" line="62"/>
        <location filename="../IDlgSetupGrid.ui" line="94"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="45"/>
        <source>Get projection from current map.</source>
        <translation>Obtener proyección del mapa actual.</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="59"/>
        <source>projection wizzard</source>
        <translation>asistente de proyección</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="84"/>
        <source>Grid color</source>
        <translation>Color de la rejilla</translation>
    </message>
    <message>
        <location filename="../IDlgSetupGrid.ui" line="91"/>
        <source>setup grid color</source>
        <translation>configurar color de rejilla</translation>
    </message>
</context>
<context>
    <name>IDlgTrackFilter</name>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="15"/>
        <source>Track Filter...</source>
        <translation>Filtrar Track ...</translation>
    </message>
    <message>
        <source>Reduce dataset</source>
        <translation type="obsolete">Reducir conjunto de datos</translation>
    </message>
    <message>
        <source>Mark points as deleted if:</source>
        <translation type="obsolete">Marcar puntos como borrados si:</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="31"/>
        <source>Filter Track</source>
        <translation>Filtrar Track</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="41"/>
        <source>Hide track points if:</source>
        <translation>Ocultar puntos del track si:</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="48"/>
        <source>Distance to previous point less than</source>
        <translation>La distancia al punto anterior es inferior a</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="98"/>
        <source>Time from previous point less than</source>
        <translation>El tiempo al punto anterior es inferior a</translation>
    </message>
    <message utf8="true">
        <location filename="../IDlgTrackFilter.ui" line="111"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="146"/>
        <source>Azimuth from previous point less than</source>
        <translation>Rumbo respecto al punto anterior inferior a</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="156"/>
        <source>Change track point data:</source>
        <translation>Modificar puntos del track:</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="51"/>
        <location filename="../IDlgTrackFilter.ui" line="101"/>
        <source>buttonGroup</source>
        <translation>buttonGroup</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="170"/>
        <source>Smooth profile (Median filter, 5 tabs)</source>
        <translation>Suavizar perfil (Filtro mediana, 5 puntos)</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="201"/>
        <location filename="../IDlgTrackFilter.ui" line="376"/>
        <source>If you select to split the track, the above will apply to the newly created fragments.</source>
        <translation>Si selecciona dividir el track, lo anterior aplicará a los fragmentos que se creen como resultado.</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="224"/>
        <source>Perform dataset reduction on &quot;OK&quot;</source>
        <translation>Ejecutar la reducción del conjunto de datos al pulsar &quot;Aceptar&quot;</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="232"/>
        <source>Timestamps</source>
        <translation>Marcas de tiempo</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="245"/>
        <source>Change the track&apos;s starting time (anonymize track) to:</source>
        <translation>Cambiar la hora de inicio del track (anonimizar track) a:</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="261"/>
        <source>Local time</source>
        <translation>Hora local</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="267"/>
        <location filename="../IDlgTrackFilter.ui" line="280"/>
        <source>buttonGroupTZ</source>
        <translation>buttonGroupTZ</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="274"/>
        <source>UTC</source>
        <translation>UTC</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="291"/>
        <source>Reset to 1st of month, hour 00</source>
        <translation>Restablecer al día 1, a las 00 horas</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="311"/>
        <source>Reset to 1970-01-01, 00:00 UTC</source>
        <translation>Restablecer a 1970-01-01, 00:00 UTC</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="353"/>
        <source>Leave time deltas as in original track</source>
        <translation>Dejar las diferencias de tiempo como en el track original</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="359"/>
        <location filename="../IDlgTrackFilter.ui" line="369"/>
        <source>buttonGroupTDelta</source>
        <translation>buttonGroupTDelta</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="366"/>
        <source>Change time deltas to 1 second per trackpoint</source>
        <translation>Cambiar las diferencias de tiempo a 1 segundo por punto</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="399"/>
        <source>Modify timestamps on &quot;OK&quot;</source>
        <translation>Guardar los cambios en las marcas de tiempo al pulsar &quot;Aceptar&quot;</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="407"/>
        <source>Split Track</source>
        <translation>Dividir track</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="415"/>
        <source>Split the track into </source>
        <translation>Dividir el track en</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="429"/>
        <source>chunks</source>
        <translation>fragmentos</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="436"/>
        <source>SplitTrack into chunks of </source>
        <translation>Dividir track en fragmentos de </translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="462"/>
        <source>points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../IDlgTrackFilter.ui" line="497"/>
        <source>Split track on &quot;Ok&quot;</source>
        <translation>Dividir el track al pulsar &quot;Aceptar&quot;</translation>
    </message>
</context>
<context>
    <name>IDlgWpt2Rte</name>
    <message>
        <location filename="../IDlgWpt2Rte.ui" line="14"/>
        <source>Route from waypoints...</source>
        <translation>Ruta a partir de waypoints...</translation>
    </message>
    <message>
        <location filename="../IDlgWpt2Rte.ui" line="36"/>
        <source>Available Waypoints</source>
        <translation>Waypoints disponibles</translation>
    </message>
    <message>
        <location filename="../IDlgWpt2Rte.ui" line="54"/>
        <location filename="../IDlgWpt2Rte.ui" line="61"/>
        <location filename="../IDlgWpt2Rte.ui" line="93"/>
        <location filename="../IDlgWpt2Rte.ui" line="103"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IDlgWpt2Rte.ui" line="72"/>
        <source>Selected Waypoints</source>
        <translation>Waypoints Seleccionados</translation>
    </message>
    <message>
        <location filename="../IDlgWpt2Rte.ui" line="116"/>
        <source>New Route Name</source>
        <translation>Nombre de la Nueva Ruta</translation>
    </message>
    <message>
        <location filename="../IDlgWpt2Rte.ui" line="123"/>
        <source>New Route</source>
        <translation>Nueva Ruta</translation>
    </message>
</context>
<context>
    <name>IDlgWptIcon</name>
    <message>
        <location filename="../IDlgWptIcon.ui" line="13"/>
        <source>Select icon ...</source>
        <translation>Seleccionar icono ...</translation>
    </message>
</context>
<context>
    <name>IGarminExport</name>
    <message>
        <location filename="../IGarminExport.ui" line="13"/>
        <source>Create gmapsupp.img</source>
        <translation>Crear archivo gmapsupp.img</translation>
    </message>
    <message>
        <location filename="../IGarminExport.ui" line="21"/>
        <source>Output Path:</source>
        <translation>Directorio de salida:</translation>
    </message>
    <message>
        <location filename="../IGarminExport.ui" line="37"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IGarminExport.ui" line="46"/>
        <source>File Prefix</source>
        <translation>Prefijo del Archivo</translation>
    </message>
    <message>
        <location filename="../IGarminExport.ui" line="56"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../IGarminExport.ui" line="63"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
</context>
<context>
    <name>IGarminTyp</name>
    <message>
        <location filename="../IGarminTyp.cpp" line="456"/>
        <location filename="../IGarminTyp.cpp" line="831"/>
        <source>Warning...</source>
        <translation>Atención...</translation>
    </message>
    <message>
        <location filename="../IGarminTyp.cpp" line="456"/>
        <source>This is a typ file with unknown polygon encoding. Please report!</source>
        <translation>Este es un archivo TYP con codificación de polígonos desconocida, ¡Por favor informe de ello!</translation>
    </message>
    <message>
        <location filename="../IGarminTyp.cpp" line="831"/>
        <source>This is a typ file with unknown polyline encoding. Please report!</source>
        <translation>Este es un archivo TYP con codificación de polilíneas desconocida. ¡Por favor informe de ello!</translation>
    </message>
</context>
<context>
    <name>IGeoToolWidget</name>
    <message>
        <location filename="../IGeoToolWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>IHelpDialog</name>
    <message>
        <location filename="../IHelpDlg.ui" line="26"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../IHelpDlg.ui" line="54"/>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
</context>
<context>
    <name>IImageSelect</name>
    <message>
        <location filename="../IImageSelect.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>IImageViewer</name>
    <message>
        <location filename="../IImageViewer.ui" line="429"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
</context>
<context>
    <name>ILiveLogToolWidget</name>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="48"/>
        <location filename="../ILiveLogToolWidget.ui" line="55"/>
        <location filename="../ILiveLogToolWidget.ui" line="69"/>
        <location filename="../ILiveLogToolWidget.ui" line="101"/>
        <location filename="../ILiveLogToolWidget.ui" line="119"/>
        <location filename="../ILiveLogToolWidget.ui" line="130"/>
        <location filename="../ILiveLogToolWidget.ui" line="144"/>
        <location filename="../ILiveLogToolWidget.ui" line="182"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="62"/>
        <source>Error horiz.:</source>
        <translation>Error horizontal:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="137"/>
        <source>GPS Time:</source>
        <translation>Hora GPS:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="27"/>
        <source>Status:</source>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="41"/>
        <source>Position:</source>
        <translation>Posición:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="76"/>
        <source>Error vert.:</source>
        <translation>Error vertical:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="83"/>
        <source>Satellites:</source>
        <translation>Satélites:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="175"/>
        <source>Altitude:</source>
        <translation>Altitud:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="20"/>
        <source>GPS off</source>
        <translation>GPS apagado</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="94"/>
        <source>Speed:</source>
        <translation>Velocidad:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="112"/>
        <source>Heading:</source>
        <translation>Rumbo:</translation>
    </message>
    <message>
        <location filename="../ILiveLogToolWidget.ui" line="164"/>
        <source>use small arrow</source>
        <translation>Utilizar flecha pequeña</translation>
    </message>
</context>
<context>
    <name>IMap</name>
    <message>
        <location filename="../IMap.cpp" line="228"/>
        <source>No basemap projection. That shouldn&apos;t happen.</source>
        <translation>El mapa base no tiene proyección. Esto no debería pasar.</translation>
    </message>
    <message>
        <location filename="../IMap.cpp" line="244"/>
        <source>DEM projection does not match the projection of the basemap.

Map: %1

DEM: %2

In my point of view this is bad. But if you think I am wrong just go on with &apos;Apply&apos;. Else abort operation.</source>
        <translation>La proyección del fichero DEM no coincide con la proyección del mapa base.

Mapa: %1

DEM: %2

Desde mi punto de vista esto no está bien. Pero si piensas que estoy equivocado continúa con &apos;Aplicar&apos;. Si no, aborta la operación.</translation>
    </message>
    <message>
        <location filename="../IMap.cpp" line="250"/>
        <source>DEM projection does not match the projection of the basemap.

Map: %1

DEM: %2</source>
        <translation>La proyección del fichero DEM no coincide con la proyección del mapa base.

Mapa: %1

DEM: %2</translation>
    </message>
    <message>
        <location filename="../IMap.cpp" line="369"/>
        <source>This map does not support this feature.</source>
        <translation>Este mapa no soporta esta característica.</translation>
    </message>
    <message>
        <location filename="../IMap.cpp" line="245"/>
        <location filename="../IMap.cpp" line="375"/>
        <location filename="../IMap.cpp" line="381"/>
        <location filename="../IMap.cpp" line="387"/>
        <location filename="../IMap.cpp" line="393"/>
        <source>Error...</source>
        <translation>Error...</translation>
    </message>
    <message>
        <location filename="../IMap.cpp" line="375"/>
        <location filename="../IMap.cpp" line="381"/>
        <location filename="../IMap.cpp" line="387"/>
        <location filename="../IMap.cpp" line="393"/>
        <source>Changing the offset is not supported by this map.</source>
        <translation>Este mapa no soporta cambiar la compensación.</translation>
    </message>
</context>
<context>
    <name>IMapDEMSlopeSetup</name>
    <message>
        <location filename="../IMapDEMSlopeSetup.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IMapDEMSlopeSetup.ui" line="47"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="54"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="61"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="68"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="75"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="82"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="89"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="96"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="103"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="110"/>
        <location filename="../IMapDEMSlopeSetup.ui" line="125"/>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
</context>
<context>
    <name>IMapEditWidget</name>
    <message>
        <location filename="../IMapEditWidget.ui" line="20"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IMapEditWidget.ui" line="34"/>
        <source>Source:</source>
        <translation>Fuente:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <location filename="../IMapEditWidget.ui" line="59"/>
        <source>Select a source for the map to create.</source>
        <translation>Seleccionar fuente para crear mapa.</translation>
    </message>
</context>
<context>
    <name>IMapQMAPExport</name>
    <message>
        <location filename="../IMapQMAPExport.ui" line="14"/>
        <source>Export map ...</source>
        <translation>Exportar mapa ...</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="26"/>
        <source>You want to export a map from a streaming map server. QLandkarte GT will only export those parts of the map that are anyway in the cache. In other words, &lt;b&gt;you have to view the whole area at the selected zoom levels with QLandkarte GT before you can export it&lt;/b&gt;. Keep in mind that QLandkarte is not a ripper tool for streaming maps. &lt;b&gt;Please respect the copyrights and terms of use of the particular server.&lt;/b&gt; </source>
        <translation>Quiere exportar un mapa a partir de un servidor streaming de mapas. QLandkarte GT sólo exportará aquellas partes del mapa que ya están en la caché. En otras palabras, &lt;b&gt;debe ver con QLandkarte GT el área completa a los niveles de zoom seleccionados antes de que pueda exportarlo&lt;/b&gt;. Tenga en cuenta que QLandkarte no es una herramienta para robar mapas streaming. &lt;b&gt;Por favor, respete el copyright y los términos de uso del servidor en particular.&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="48"/>
        <source>Output path:</source>
        <translation>Directorio de salida:</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="57"/>
        <location filename="../IMapQMAPExport.ui" line="406"/>
        <location filename="../IMapQMAPExport.ui" line="483"/>
        <location filename="../IMapQMAPExport.ui" line="497"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="77"/>
        <source>File prefix</source>
        <translation>Prefijo del archivo</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="87"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="97"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="104"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <source>QLandkarte M</source>
        <translation type="obsolete">QLandkarte M</translation>
    </message>
    <message>
        <source>Lowrance</source>
        <translation type="obsolete">Lowrance</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="113"/>
        <source>Streaming</source>
        <translation>Streaming</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="121"/>
        <source>Levels to export</source>
        <translation>Niveles a exportar</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="128"/>
        <source>Give a list of zoom levels you want to export. Like: 1 4 8 16</source>
        <translation>Introduzca una lista de niveles de zoom que quiera exportar. Como: 1 4 8 16</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="131"/>
        <source>1 </source>
        <translation>1 </translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="145"/>
        <location filename="../IMapQMAPExport.ui" line="458"/>
        <source>GeoTiff</source>
        <translation>GeoTiff</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="169"/>
        <source>TwoNav RMAP</source>
        <translation>TwoNav RMAP</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="176"/>
        <location filename="../IMapQMAPExport.ui" line="360"/>
        <source>Magellan RMP</source>
        <translation>Magellan RMP</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="198"/>
        <source>Tile selection is only supported by Garmin Custom Map. All other formats will export the whole area as is.</source>
        <translation>La selección de teselas sólo está soportada en Mapas Garmin Personalizados. Para el resto de formatos de mapas se exportará todo el área tal cual.</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="208"/>
        <source>BirdsEye</source>
        <translation>BirdsEye</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="216"/>
        <source>Product name</source>
        <translation>Nombre de producto</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="230"/>
        <source>Copyright notice</source>
        <translation>Aviso copyright</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="237"/>
        <source>None</source>
        <translation>Nnguno</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="246"/>
        <source>Product ID</source>
        <translation>ID de producto</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="265"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="273"/>
        <source>Quality</source>
        <translation>Calidad</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="293"/>
        <source>Chroma subsampling</source>
        <translation>Submuestreo croma</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="301"/>
        <source>411</source>
        <translation>411</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="306"/>
        <source>422</source>
        <translation>422</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="311"/>
        <source>444</source>
        <translation>444</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="324"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="332"/>
        <source>Z-Order</source>
        <translation>Orden-Z</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="366"/>
        <source>Provider </source>
        <translation>Proveedor</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="379"/>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="386"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="420"/>
        <source>RMAP</source>
        <translation>RMAP</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="428"/>
        <source>Projection </source>
        <translation>Proyección </translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="443"/>
        <source>Single File</source>
        <translation>Archivo único</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="473"/>
        <source>Projection</source>
        <translation>Proyección</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="480"/>
        <source>Get projection from current map.</source>
        <translation>Obtener proyección del mapa actual.</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="494"/>
        <source>Projection Wizard</source>
        <translation>Asistente de proyección</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="597"/>
        <source>Step -/-</source>
        <translation>Paso -/-</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="604"/>
        <source>File -/-</source>
        <translation>Archivo -/-</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="617"/>
        <source>Make your selections and press &quot;Export&quot;</source>
        <translation>Haga sus selecciones y pulse &quot;Exportar&quot;</translation>
    </message>
    <message>
        <source>Optimization</source>
        <translation type="obsolete">Optimización</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="515"/>
        <source>Overviews</source>
        <translation>Vista general</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="522"/>
        <source>2x</source>
        <translation>2x</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="529"/>
        <source>4x</source>
        <translation>4x</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="536"/>
        <source>8x</source>
        <translation>8x</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="543"/>
        <source>16x</source>
        <translation>16x</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="577"/>
        <source>Details</source>
        <translation>Detalles</translation>
    </message>
    <message>
        <source>Google Earth (KMZ)</source>
        <translation type="obsolete">Google Earth (KMZ)</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="155"/>
        <source>Garmin Custom Map</source>
        <translation>Mapa Garmin Personalizado</translation>
    </message>
    <message>
        <location filename="../IMapQMAPExport.ui" line="162"/>
        <source>Garmin BirdsEye</source>
        <translation>Garmin BirdsEye</translation>
    </message>
</context>
<context>
    <name>IMapSearchWidget</name>
    <message>
        <location filename="../IMapSearchWidget.ui" line="32"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="obsolete">Base de datos</translation>
    </message>
    <message>
        <source>Lines</source>
        <translation type="obsolete">Líneas</translation>
    </message>
    <message>
        <source>Text to find:</source>
        <translation type="obsolete">Buscar texto:</translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="obsolete">Puntos</translation>
    </message>
    <message>
        <source>Limit search to viewport</source>
        <translation type="obsolete">Limitar búsqueda a la vista</translation>
    </message>
    <message>
        <source>Create Index</source>
        <translation type="obsolete">Crear Índice</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="48"/>
        <source>Symbols</source>
        <translation>Símbolos</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="77"/>
        <location filename="../IMapSearchWidget.ui" line="84"/>
        <location filename="../IMapSearchWidget.ui" line="94"/>
        <location filename="../IMapSearchWidget.ui" line="185"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="112"/>
        <source>No mask selected</source>
        <translation>Máscara no seleccionada</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="134"/>
        <source>Gray Threshold</source>
        <translation>Umbral de gris</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="178"/>
        <source>Area:</source>
        <translation>Área:</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="200"/>
        <source>No area selected.</source>
        <translation>No se seleccionó área.</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="231"/>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <location filename="../IMapSearchWidget.ui" line="247"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>IMapToolWidget</name>
    <message>
        <location filename="../IMapToolWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Known Maps:</source>
        <translation type="obsolete">Mapas conocidos:</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="98"/>
        <source>Tab 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="70"/>
        <location filename="../IMapToolWidget.ui" line="135"/>
        <location filename="../IMapToolWidget.ui" line="200"/>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="30"/>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="73"/>
        <location filename="../IMapToolWidget.ui" line="138"/>
        <location filename="../IMapToolWidget.ui" line="203"/>
        <source>Mode - show active map and active overlays</source>
        <translation>Modo - muestra el mapa activo y las superposiciones activas</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="78"/>
        <location filename="../IMapToolWidget.ui" line="143"/>
        <location filename="../IMapToolWidget.ui" line="208"/>
        <source>T</source>
        <translation>T</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="81"/>
        <location filename="../IMapToolWidget.ui" line="146"/>
        <location filename="../IMapToolWidget.ui" line="211"/>
        <source>Type of map</source>
        <translation>Tipo de mapa</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="86"/>
        <location filename="../IMapToolWidget.ui" line="151"/>
        <location filename="../IMapToolWidget.ui" line="216"/>
        <source>Map</source>
        <translation>Mapa</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="89"/>
        <location filename="../IMapToolWidget.ui" line="154"/>
        <location filename="../IMapToolWidget.ui" line="219"/>
        <source>The map&apos;s name</source>
        <translation>El nombre del mapa</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="163"/>
        <source>Tab 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="231"/>
        <source>Selected Maps:</source>
        <translation>Mapas Seleccionados:</translation>
    </message>
    <message>
        <location filename="../IMapToolWidget.ui" line="259"/>
        <source>Export Map</source>
        <translation>Exportar Mapa</translation>
    </message>
</context>
<context>
    <name>IMouse</name>
    <message>
        <source>%4 %3 %1:%2h (%5%)</source>
        <translation type="obsolete">%4 %3 %1:%2h (%5%)</translation>
    </message>
    <message>
        <source> | (%5%) %1:%2h %3 %4</source>
        <translation type="obsolete"> | (%5%) %1:%2h %3 %4</translation>
    </message>
    <message>
        <source>%5 %4 %1%2 (%3%)</source>
        <translation type="obsolete">%5 %4 %1%2 (%3%)</translation>
    </message>
    <message>
        <source> | (%3%) %1%2 %4 %5</source>
        <translation type="obsolete"> | (%3%) %1%2 %4 %5</translation>
    </message>
    <message>
        <source>elevation: %1 %2</source>
        <translation type="obsolete">altura: %1 %2</translation>
    </message>
    <message>
        <source>start %4 %1%2 (%3%)</source>
        <translation type="obsolete">inicio %4 %1%2 (%3%)</translation>
    </message>
    <message>
        <source> | (%3%) %1%2 %4 end</source>
        <translation type="obsolete"> | (%3%) %1%2 %4 final</translation>
    </message>
    <message>
        <source>
 %1: %2 </source>
        <translation type="obsolete">
 %1: %2 </translation>
    </message>
    <message>
        <location filename="../IMouse.cpp" line="313"/>
        <source>too many...</source>
        <translation>demasiados...</translation>
    </message>
    <message>
        <location filename="../IMouse.cpp" line="321"/>
        <source>Left click to lock circles.
Then select function from circle.
Left click on canvas to un-lock circles.</source>
        <translation>Haga click con el botón izquierdo para fijar círculo.
Entonces seleccione función en el círculo.
Haga click con el botón izquierdo en la pantalla para desbloquear círculo.</translation>
    </message>
</context>
<context>
    <name>IOverlay</name>
    <message>
        <location filename="../IOverlay.h" line="52"/>
        <source>No info set</source>
        <translation>Sin información</translation>
    </message>
</context>
<context>
    <name>IOverlayAreaEditWidget</name>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="28"/>
        <source>TextLabel</source>
        <translation>Etiqueta de Texto</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="35"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="48"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="55"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="65"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="72"/>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="99"/>
        <source>Border Width</source>
        <translation>Anchura del borde</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="109"/>
        <source>Opacity</source>
        <translation>Transparencia</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="133"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../IOverlayAreaEditWidget.ui" line="163"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
</context>
<context>
    <name>IOverlayDistanceEditWidget</name>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="76"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="86"/>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="26"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="51"/>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="100"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../IOverlayDistanceEditWidget.ui" line="124"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
</context>
<context>
    <name>IOverlayToolWidget</name>
    <message>
        <location filename="../IOverlayToolWidget.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>IRouteToolWidget</name>
    <message>
        <location filename="../IRouteToolWidget.ui" line="19"/>
        <source>Sort by name</source>
        <translation>Ordenar por nombre</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="22"/>
        <location filename="../IRouteToolWidget.ui" line="38"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="35"/>
        <source>Sort by time</source>
        <translation>Ordenar por fecha</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="70"/>
        <source>Routes</source>
        <translation>Rutas</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="99"/>
        <source>Setup</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="117"/>
        <location filename="../IRouteToolWidget.ui" line="157"/>
        <source>Avoid:</source>
        <translation>Evitar:</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="126"/>
        <source>Highways</source>
        <translation>Autopistas</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="133"/>
        <location filename="../IRouteToolWidget.ui" line="173"/>
        <source>Toll Road</source>
        <translation>Peajes</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="166"/>
        <source>Lim. Access</source>
        <translation>Acceso limitado</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="180"/>
        <source>Seasonal</source>
        <translation>Estacional</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="187"/>
        <source>Unpaved</source>
        <translation>Sin asfaltar</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="194"/>
        <source>Ferry</source>
        <translation>Ferry</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="201"/>
        <source>Country Border</source>
        <translation>Frontera</translation>
    </message>
    <message>
        <source>Avoid highways</source>
        <translation type="obsolete">Evitar autopistas</translation>
    </message>
    <message>
        <source>Avoid tollways</source>
        <translation type="obsolete">Evitar peajes</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;How to add a route?&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Routes can be created from waypoints or distance polylines. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;To create a route from waypoints you have to select at least two waypoints in the waypoint tool view. After you made your selection you summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;To create a route from a distance polyline you select the line and summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;In the &amp;quot;Setup&amp;quot; tab you can select settings for auto routing. To calculate a secondary, autorouted route to your primary route definition you  summon the menu by a right mouse button click and select &amp;quot;Calc. route&amp;quot;.&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;¿Cómo añadir una ruta?&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Las rutas pueden crearse a partir de waypoints o polilíneas. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Para crear una ruta a partir de waypoints tiene que seleccionar al menos dos waypoints en la herramienta de vista de waypoint. Después de hacer su selección abra el menú con el ratón haciendo click derecho y selecione &amp;quot;Crear Ruta&amp;quot;. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Para crear una ruta a partir de polilíneas tiene que seleccionar la línea y abrir el menú haciendo click derecho y selecionar &amp;quot;Crear Ruta&amp;quot;.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;En la pestaña &amp;quot;Ajustes&amp;quot; puede seleccionar las preferencias de autoenrutado. Para calcular una ruta alternativa abra el menú haciendo click derecho y seleccione &amp;quot;Calc. ruta&amp;quot;.&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;How to add a route?&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Routes can be created from waypoints or distance polylines. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;To create a route from waypoints you have to select at least two waypoints in the waypoint tool view. After you made your selection you summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;To create a route from a distance polyline you select the line and summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;In the &amp;quot;Setup&amp;quot; tab you can select settings for auto routing. To calculate a secondary, autorouted route to your primary route definition you  summon the menu by a right mouse button click and select &amp;quot;Calc. route&amp;quot;.&lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;¿Cómo añadir una ruta?&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Las rutas pueden crearse a partir de waypoints o polilíneas. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Para crear una ruta a partir de waypoints tiene que seleccionar al menos dos waypoints en la herramienta de vista de waypoint. Después de hacer su selección abra el menú con el ratón haciendo click derecho y selecione &amp;quot;Crear Ruta&amp;quot;. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;Para crear una ruta a partir de polilíneas tiene seleccionar la línea y abrir el menú haciendo click derecho y selecione &amp;quot;Crear Ruta&amp;quot;. &lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt;&quot;&gt;En la pestaña &amp;quot;Ajustes&amp;quot; puede seleccionar las preferencias de autoenrutado. Para calcular una ruta alternativa abra el menú haciendo click derecho y selecione &amp;quot;Calc. ruta&amp;quot;. &lt;/span&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../IRouteToolWidget.ui" line="239"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table border=&quot;0&quot; style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;How to add a route?&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Routes can be created from waypoints or distance polylines. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To create a route from waypoints you have to select at least two waypoints in the waypoint tool view. After you made your selection you summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To create a route from a distance polyline you select the line and summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In the &amp;quot;Setup&amp;quot; tab you can select settings for auto routing. To calculate a secondary, autorouted route to your primary route definition you  summon the menu by a right mouse button click and select &amp;quot;Calc. route&amp;quot;.&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;¿Cómo añadir una ruta?&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Las rutas pueden crearse a partir de waypoints o polilíneas. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Para crear una ruta a partir de waypoints tiene que seleccionar al menos dos waypoints en la herramienta de vista de waypoint. Después de hacer su selección abra el menú con el ratón haciendo click derecho y seleccione &amp;quot;Crear Ruta&amp;quot;. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Para crear una ruta a partir de polilíneas tiene que seleccionar la línea y abrir el menú haciendo click derecho y selecionar &amp;quot;Crear Ruta&amp;quot;. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;En la pestaña &amp;quot;Preferencias&amp;quot; puede seleccionar las preferencias de autoenrutado. Para calcular una ruta alternativa abrir el menú haciendo click derecho y seleccionar &amp;quot;Calc. ruta&amp;quot;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;How to add a route?&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Routes can be created from waypoints ot distance polylines. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To create a route from waypoints you have to select at least two waypoints in the waypoint tool view. After you made your selection you summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To create a route from a distance polyline you select the line and summon the menu by a right mouse button click and select &amp;quot;Make Route&amp;quot;.&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In the &amp;quot;Setup&amp;quot; tab you can select settings for auto routing. To calculate a secondary, autorouted route to your primary route definition you  summon the menu by a right mouse button click and select &amp;quot;Calc. route&amp;quot;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;¿Como añadir una ruta?&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Las rutas pueden crearse a partir de waypoints o polilíneas. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Para crear una ruta a partir de waypoints tiene que seleccionar al menos dos waypoints en la herramienta de vista de waypoint. Después de hacer su selección abra el menú con el ratón haciendo click derecho y selecione &amp;quot;Crear Ruta&amp;quot;. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Para crear una ruta a partir de polilíneas tiene seleccionar la línea y abrir el menú haciendo click derecho y selecione &amp;quot;Crear Ruta&amp;quot;. &lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;En la pestaña &amp;quot;Ajustes&amp;quot; puede seleccionar las preferencias de autoenrutado. Para calcular una ruta alternativa abrir el menú haciendo click derecho y selecione &amp;quot;Calc. ruta&amp;quot;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ISearchToolWidget</name>
    <message>
        <location filename="../ISearchToolWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ISearchToolWidget.ui" line="22"/>
        <source>Host:</source>
        <translation>Servidor:</translation>
    </message>
    <message>
        <location filename="../ISearchToolWidget.ui" line="32"/>
        <source>Search:</source>
        <translation>Buscar:</translation>
    </message>
</context>
<context>
    <name>IStatusDEM</name>
    <message>
        <location filename="../IStatusDEM.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IStatusDEM.ui" line="23"/>
        <source>none</source>
        <translation>ninguno</translation>
    </message>
    <message>
        <location filename="../IStatusDEM.ui" line="33"/>
        <source>shading</source>
        <translation>sombreado</translation>
    </message>
    <message>
        <location filename="../IStatusDEM.ui" line="40"/>
        <source>contour</source>
        <translation>perfil</translation>
    </message>
    <message>
        <location filename="../IStatusDEM.ui" line="47"/>
        <source>slope</source>
        <translation>pendiente</translation>
    </message>
</context>
<context>
    <name>ITextEditWidget</name>
    <message>
        <location filename="../ITextEditWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ITextEditWidget.ui" line="25"/>
        <location filename="../ITextEditWidget.ui" line="38"/>
        <location filename="../ITextEditWidget.ui" line="51"/>
        <location filename="../ITextEditWidget.ui" line="64"/>
        <location filename="../ITextEditWidget.ui" line="77"/>
        <location filename="../ITextEditWidget.ui" line="117"/>
        <location filename="../ITextEditWidget.ui" line="130"/>
        <location filename="../ITextEditWidget.ui" line="143"/>
        <location filename="../ITextEditWidget.ui" line="156"/>
        <location filename="../ITextEditWidget.ui" line="169"/>
        <location filename="../ITextEditWidget.ui" line="182"/>
        <location filename="../ITextEditWidget.ui" line="195"/>
        <location filename="../ITextEditWidget.ui" line="208"/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>ITrackEditWidget</name>
    <message>
        <location filename="../ITrackEditWidget.ui" line="38"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="49"/>
        <location filename="../ITrackEditWidget.ui" line="65"/>
        <location filename="../ITrackEditWidget.ui" line="81"/>
        <location filename="../ITrackEditWidget.ui" line="100"/>
        <location filename="../ITrackEditWidget.ui" line="119"/>
        <location filename="../ITrackEditWidget.ui" line="150"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="78"/>
        <source>Toggle statistics view for trainings data.</source>
        <translation>Activar vista de estadísticas para datos de entrenamiento.</translation>
    </message>
    <message>
        <source>Close this view.</source>
        <translation type="obsolete">Cerrar esta vista.</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="obsolete">Ctrl+S</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="97"/>
        <source>Toggle extensions statistics view over time</source>
        <translatorcomment>Se debe mejorar la traducción cuando se sepa a lo que se refiere</translatorcomment>
        <translation>Activar la vista de estadísticas de extensiones por tiempo</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="136"/>
        <source>Multicolor</source>
        <translation>Multicolor</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="168"/>
        <location filename="../ITrackEditWidget.ui" line="222"/>
        <source>Stages</source>
        <translation>Etapas</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="182"/>
        <source>If checked, the map is centered map on selected trackpoint.</source>
        <translation>Si se selecciona, el mapa se centrará en el punto seleccionado del track.</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="185"/>
        <source>Center map</source>
        <translation>Centrar mapa</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="711"/>
        <source>Extensions</source>
        <translation>Extensiones</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="116"/>
        <source>Show the track on Google Maps</source>
        <translation>Mostrar el track en Google Maps</translation>
    </message>
    <message>
        <source>Google Maps</source>
        <translation type="obsolete">Google Maps</translation>
    </message>
    <message>
        <source>Filter track points.</source>
        <translation type="obsolete">Filtrar puntos del track.</translation>
    </message>
    <message>
        <source>Reset all changes (hidden track points and filters)</source>
        <translation type="obsolete">Restaurar todos los cambios (puntos del track ocultos y filtros)</translation>
    </message>
    <message>
        <source>Remove hidden track points permanently.</source>
        <translation type="obsolete">Eliminar permanentemente puntos del track ocultos.</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="161"/>
        <source>Use &apos;return&apos; key to change name permanently.</source>
        <translation>Utilice la tecla &apos;Enter&apos; para cambiar el nombre de forma permanente.</translation>
    </message>
    <message>
        <source>remove hidden track points</source>
        <translation type="obsolete">Eliminar puntos del track ocultos</translation>
    </message>
    <message>
        <source>show all hidden track points</source>
        <translation type="obsolete">mostrar puntos del track ocultos</translation>
    </message>
    <message>
        <source>reset all changes (hide/filter)</source>
        <translation type="obsolete">restaurar todos los cambios (ocultar/filtrar)</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="236"/>
        <source>Tracklist</source>
        <translation>Lista de tracks</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="273"/>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="278"/>
        <location filename="../ITrackEditWidget.ui" line="485"/>
        <source>time</source>
        <translation>fecha/hora</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="283"/>
        <location filename="../ITrackEditWidget.ui" line="510"/>
        <source>altitude</source>
        <translation>altitud</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="288"/>
        <location filename="../ITrackEditWidget.ui" line="535"/>
        <source>delta</source>
        <translation>delta</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="293"/>
        <location filename="../ITrackEditWidget.ui" line="560"/>
        <source>azimuth</source>
        <translation>azimut</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="298"/>
        <location filename="../ITrackEditWidget.ui" line="585"/>
        <source>distance</source>
        <translation>distancia</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="303"/>
        <location filename="../ITrackEditWidget.ui" line="610"/>
        <source>speed</source>
        <translation>velocidad</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="308"/>
        <location filename="../ITrackEditWidget.ui" line="635"/>
        <source>ascend</source>
        <translation>ascenso</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="313"/>
        <location filename="../ITrackEditWidget.ui" line="660"/>
        <source>descend</source>
        <translation>descenso</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="318"/>
        <location filename="../ITrackEditWidget.ui" line="685"/>
        <source>position</source>
        <translation>posición</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="331"/>
        <source>Filter</source>
        <translation>Filtros</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="345"/>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="351"/>
        <source>Choose here which columns are shown in the tracklist view</source>
        <translation>Seleccionar aquí qué columnas serán mostradas en la vista de tracks</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="367"/>
        <source>Standard</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="460"/>
        <source>row number (#)</source>
        <translation>fila (#)</translation>
    </message>
    <message>
        <source>remove purged track points</source>
        <translation type="obsolete">eliminar los puntos borrados</translation>
    </message>
    <message>
        <source>reset purged track points</source>
        <translation type="obsolete">restaurar los puntos borrados</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="46"/>
        <source>Toggle track statistics view over distance.</source>
        <translation>Mostrar pestañas de perfiles del track por distancia.</translation>
    </message>
    <message>
        <location filename="../ITrackEditWidget.ui" line="62"/>
        <source>Toggle track statistics view over time.</source>
        <translation>Mostrar pestañas de perfiles del track por tiempo.</translation>
    </message>
</context>
<context>
    <name>ITrackFilterWidget</name>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="197"/>
        <source>Points</source>
        <translation>Puntos</translation>
    </message>
    <message>
        <source>Reset changes</source>
        <translation type="obsolete">Reiniciar cambios</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="37"/>
        <location filename="../ITrackFilterWidget.ui" line="51"/>
        <location filename="../ITrackFilterWidget.ui" line="140"/>
        <location filename="../ITrackFilterWidget.ui" line="154"/>
        <location filename="../ITrackFilterWidget.ui" line="304"/>
        <location filename="../ITrackFilterWidget.ui" line="331"/>
        <location filename="../ITrackFilterWidget.ui" line="354"/>
        <location filename="../ITrackFilterWidget.ui" line="368"/>
        <location filename="../ITrackFilterWidget.ui" line="428"/>
        <location filename="../ITrackFilterWidget.ui" line="449"/>
        <location filename="../ITrackFilterWidget.ui" line="521"/>
        <location filename="../ITrackFilterWidget.ui" line="582"/>
        <location filename="../ITrackFilterWidget.ui" line="605"/>
        <location filename="../ITrackFilterWidget.ui" line="663"/>
        <location filename="../ITrackFilterWidget.ui" line="683"/>
        <location filename="../ITrackFilterWidget.ui" line="720"/>
        <location filename="../ITrackFilterWidget.ui" line="813"/>
        <location filename="../ITrackFilterWidget.ui" line="824"/>
        <location filename="../ITrackFilterWidget.ui" line="880"/>
        <location filename="../ITrackFilterWidget.ui" line="891"/>
        <location filename="../ITrackFilterWidget.ui" line="961"/>
        <location filename="../ITrackFilterWidget.ui" line="972"/>
        <location filename="../ITrackFilterWidget.ui" line="1078"/>
        <location filename="../ITrackFilterWidget.ui" line="1130"/>
        <location filename="../ITrackFilterWidget.ui" line="1153"/>
        <location filename="../ITrackFilterWidget.ui" line="1214"/>
        <location filename="../ITrackFilterWidget.ui" line="1237"/>
        <location filename="../ITrackFilterWidget.ui" line="1315"/>
        <location filename="../ITrackFilterWidget.ui" line="1338"/>
        <location filename="../ITrackFilterWidget.ui" line="1416"/>
        <location filename="../ITrackFilterWidget.ui" line="1436"/>
        <location filename="../ITrackFilterWidget.ui" line="1447"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Restore hidden points and changes applied by filters.</source>
        <translation type="obsolete">Restaurar los puntos ocultos y los cambios hechos por los filtros.</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="230"/>
        <source>Reduce Points</source>
        <translation>Reducir Puntos</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="236"/>
        <location filename="../ITrackFilterWidget.ui" line="379"/>
        <source>Hide track points if:</source>
        <translation>Ocultar puntos del track si:</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="243"/>
        <source>Distance to previous point less than</source>
        <translation>La distancia al punto anterior es inferior a</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="281"/>
        <source>Azimuth from previous point less than</source>
        <translation>Rumbo respecto al punto anterior inferior a</translation>
    </message>
    <message utf8="true">
        <location filename="../ITrackFilterWidget.ui" line="288"/>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="512"/>
        <source>Smooth Profile</source>
        <translation>Suavizar perfil</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="532"/>
        <source>Change elevation data of track:</source>
        <translation>Modificar datos de alturas del track:</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="539"/>
        <source>Median filter over</source>
        <translation>Filtro mediana sobre</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="559"/>
        <location filename="../ITrackFilterWidget.ui" line="1189"/>
        <source>points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="419"/>
        <source>Delete hidden points</source>
        <translation>Borrar puntos ocultos</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="34"/>
        <source>reset filter list</source>
        <translation>reiniciar lista de filtros</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="48"/>
        <source>save filter list</source>
        <translation>guardar lista de filtros</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="68"/>
        <source>apply filter</source>
        <translation>aplicar filtro</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="71"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="122"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#c00000;&quot;&gt;The filters will only apply to the selected part of the track.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#c00000;&quot;&gt;Los filtros sólo se aplicarán a la parte seleccionada del track.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="137"/>
        <location filename="../ITrackFilterWidget.ui" line="183"/>
        <location filename="../ITrackFilterWidget.ui" line="328"/>
        <location filename="../ITrackFilterWidget.ui" line="351"/>
        <location filename="../ITrackFilterWidget.ui" line="446"/>
        <location filename="../ITrackFilterWidget.ui" line="579"/>
        <location filename="../ITrackFilterWidget.ui" line="660"/>
        <location filename="../ITrackFilterWidget.ui" line="1127"/>
        <location filename="../ITrackFilterWidget.ui" line="1211"/>
        <location filename="../ITrackFilterWidget.ui" line="1312"/>
        <location filename="../ITrackFilterWidget.ui" line="1413"/>
        <source>apply now</source>
        <translation>aplicar ahora</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="151"/>
        <location filename="../ITrackFilterWidget.ui" line="301"/>
        <location filename="../ITrackFilterWidget.ui" line="365"/>
        <location filename="../ITrackFilterWidget.ui" line="425"/>
        <location filename="../ITrackFilterWidget.ui" line="518"/>
        <location filename="../ITrackFilterWidget.ui" line="602"/>
        <location filename="../ITrackFilterWidget.ui" line="1075"/>
        <location filename="../ITrackFilterWidget.ui" line="1150"/>
        <location filename="../ITrackFilterWidget.ui" line="1234"/>
        <location filename="../ITrackFilterWidget.ui" line="1335"/>
        <source>add to list</source>
        <translation>añadir a la lista</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="165"/>
        <source>Reset all changes</source>
        <translation>Deshacer todos los cambios</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="345"/>
        <source>Douglas-Peucker</source>
        <translation>Douglas-Peucker</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="392"/>
        <source>Distance of a point to a straight line between neighbor points is less than</source>
        <translation>Distancia de un punto a una línea recta entre puntos vecinos es inferior a</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="439"/>
        <source>Delete hidden track points for ever. No way back!</source>
        <translation>Borrar para siempre puntos del track ocultos. ¡No hay vuelta atrás!</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="485"/>
        <source>Profile</source>
        <translation>Perfil</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="596"/>
        <source>Replace elevation data</source>
        <translation>Reemplazar datos de alturas</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="629"/>
        <source>Use elevation from loaded DEM data</source>
        <translation>Utilizar alturas de los datos DEM cargados</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="639"/>
        <source>Use elevation from www.geonames.org</source>
        <translation>Utilizar alturas de www.geonames.org</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="648"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="677"/>
        <source>Offset elevation data</source>
        <translation>Desplazar los datos de elevación</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="731"/>
        <source>Add offset of</source>
        <translation>Añadir un desplazamiento de</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="955"/>
        <source>Unify timestamps</source>
        <translation>Igualar la separación temporal entre puntos del track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="983"/>
        <source>Increase timestamp by</source>
        <translation>Espaciar puntos consecutivos del track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="990"/>
        <source>sec.</source>
        <translation> s.</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="997"/>
        <source>0 will remove timestamps</source>
        <translation>0 eliminará la fecha y hora de los puntos</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1042"/>
        <source>Split</source>
        <translation>Dividir</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1069"/>
        <source>Split into equal chunks</source>
        <translation>Dividir en fragmentos iguales</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1091"/>
        <source>Split the track into </source>
        <translation>Dividir el track en </translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1105"/>
        <source>chunks</source>
        <translation>fragmentos</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1144"/>
        <source>Split by number of points</source>
        <translation>Dividir por número de puntos</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1166"/>
        <location filename="../ITrackFilterWidget.ui" line="1250"/>
        <source>SplitTrack into chunks of </source>
        <translation>Dividir track en fragmentos de </translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1228"/>
        <source>Split by distance</source>
        <translation>Dividir por distancia</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="780"/>
        <source>Time</source>
        <translation>Tiempo</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="807"/>
        <source>Date/Time of track</source>
        <translation>Fecha/Hora del track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="835"/>
        <source>New date/time of track</source>
        <translation>Nueva fecha/hora del track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="848"/>
        <source>dd.MMMM.yyyy HH:mm:ss</source>
        <translation>dd.MMMM.yyyy HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="874"/>
        <source>Speed of track</source>
        <translation>Velocidad del track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="902"/>
        <source>Speed</source>
        <translation>Velocidad</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="909"/>
        <source>km/h</source>
        <translation>km/h</translation>
    </message>
    <message>
        <source>Anonymize</source>
        <translation type="obsolete">Anonimizar</translation>
    </message>
    <message>
        <source>Change the track&apos;s starting time (anonymize track) to:</source>
        <translation type="obsolete">Cambiar la hora de inicio del track (anonimizar track) a:</translation>
    </message>
    <message>
        <source>yyyy-MM-dd HH:mm:ss</source>
        <translation type="obsolete">aaaa-MM-dd HH:mm:ss</translation>
    </message>
    <message>
        <source>Local time</source>
        <translation type="obsolete">Hora local</translation>
    </message>
    <message>
        <source>UTC</source>
        <translation type="obsolete">UTC</translation>
    </message>
    <message>
        <source>1st of month, hour 0</source>
        <translation type="obsolete">Primer día del mes, hora 0</translation>
    </message>
    <message>
        <source>1970-01-01 00:00 UTC</source>
        <translation type="obsolete">1970-01-01 00:00 UTC</translation>
    </message>
    <message>
        <source>Change time deltas:</source>
        <translation type="obsolete">Cambiar las diferencias de tiempos:</translation>
    </message>
    <message>
        <source>No, leave them &quot;as is&quot;</source>
        <translation type="obsolete">No, dejarlas como están</translation>
    </message>
    <message>
        <source>Change to 1 s per track point</source>
        <translation type="obsolete">Cambiar a 1 segundo por cada punto del track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="409"/>
        <location filename="../ITrackFilterWidget.ui" line="694"/>
        <location filename="../ITrackFilterWidget.ui" line="1257"/>
        <location filename="../ITrackFilterWidget.ui" line="1358"/>
        <source>m</source>
        <translation>m</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1290"/>
        <source>length</source>
        <translation>longitud</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1329"/>
        <source>Split by ascend</source>
        <translation>Dividir por desnivel</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1351"/>
        <source>SplitTrack into chunks with </source>
        <translation>Dividir track en fragmentos con </translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1391"/>
        <source>ascend</source>
        <translation>desnivel</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1430"/>
        <source>Split at stages</source>
        <translation>Dividir el track según las etapas</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1458"/>
        <source>Split track at stage waypoints</source>
        <translation>Dividir el track en los waypoints que delimitan las etapas</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1500"/>
        <source>Split track</source>
        <translation>Dividir track</translation>
    </message>
    <message>
        <location filename="../ITrackFilterWidget.ui" line="1510"/>
        <source>Add only waypoints for stages</source>
        <translation>Solo añadir waypoints para etapas</translation>
    </message>
    <message>
        <source>Annonymous</source>
        <translation type="obsolete">Anónimo</translation>
    </message>
    <message>
        <source>To be done.</source>
        <translation type="obsolete">Por hacer.</translation>
    </message>
</context>
<context>
    <name>ITrackStatWidget</name>
    <message>
        <location filename="../ITrackStatWidget.ui" line="13"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
</context>
<context>
    <name>ITrackToolWidget</name>
    <message>
        <location filename="../ITrackToolWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../ITrackToolWidget.ui" line="22"/>
        <source>Sort by name</source>
        <translation>Ordenar por nombre</translation>
    </message>
    <message>
        <location filename="../ITrackToolWidget.ui" line="25"/>
        <location filename="../ITrackToolWidget.ui" line="41"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ITrackToolWidget.ui" line="38"/>
        <source>Sort by time (start)</source>
        <translation>Ordenar por fecha (comienzo)</translation>
    </message>
</context>
<context>
    <name>IWptToolWidget</name>
    <message>
        <location filename="../IWptToolWidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="25"/>
        <source>Sort by alphanumerical order</source>
        <translation>Ordenar alfabéticamente</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="28"/>
        <location filename="../IWptToolWidget.ui" line="47"/>
        <location filename="../IWptToolWidget.ui" line="63"/>
        <location filename="../IWptToolWidget.ui" line="79"/>
        <location filename="../IWptToolWidget.ui" line="98"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="44"/>
        <source>Sort by time</source>
        <translation>Ordenar por fecha</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="60"/>
        <source>Sort by comment</source>
        <translation>Ordenar por comentario</translation>
    </message>
    <message>
        <source>Sort waypoints by comment.</source>
        <translation type="obsolete">Ordenar los waypoints por comentarios.</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="76"/>
        <source>Sort by icon</source>
        <translation>Ordenar por iconos</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="95"/>
        <source>Sort by position</source>
        <translation>Ordenar por posición</translation>
    </message>
    <message>
        <location filename="../IWptToolWidget.ui" line="111"/>
        <source>Add position to sort waypoints by distance to that position.</source>
        <translation>Añadir posición para ordenar los waypoints por distancia a dicha posición.</translation>
    </message>
</context>
<context>
    <name>PrintPreview</name>
    <message>
        <source>Diary - Print Preview</source>
        <translation type="obsolete">Diario - Previsualizar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="obsolete">Imprimir</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation type="obsolete">Im&amp;primir...</translation>
    </message>
    <message>
        <source>Page Setup...</source>
        <translation type="obsolete">Ajustes de página...</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Acercar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Alejar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="obsolete">&amp;Cerrar</translation>
    </message>
    <message>
        <source>Print Diary</source>
        <translation type="obsolete">Imprimir el Diario</translation>
    </message>
</context>
<context>
    <name>ProxyDialog</name>
    <message>
        <location filename="../IDlgProxy.ui" line="13"/>
        <source>Proxy Authentication</source>
        <translation>Autenticación del Proxy</translation>
    </message>
    <message>
        <location filename="../IDlgProxy.ui" line="19"/>
        <source>ICON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IDlgProxy.ui" line="26"/>
        <source>Connect to proxy</source>
        <translation>Conectar al proxy</translation>
    </message>
    <message>
        <location filename="../IDlgProxy.ui" line="36"/>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../IDlgProxy.ui" line="46"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="428"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../CDeviceGarmin.cpp" line="443"/>
        <source>

Estimated finish: %02i:%02i:%02i [hh:mm:ss]</source>
        <translation>

Finalización estimada: %02i:%02i:%02i [hh:mm:ss]</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="231"/>
        <location filename="../CTrack.cpp" line="261"/>
        <location filename="../CTrack.cpp" line="285"/>
        <location filename="../CTrack.cpp" line="330"/>
        <location filename="../CTrack.cpp" line="358"/>
        <location filename="../CTrack.cpp" line="383"/>
        <source>Corrupt track ...</source>
        <translation>Track dañado ...</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="231"/>
        <location filename="../CTrack.cpp" line="261"/>
        <source>Number of trackpoints is not equal the number of training data trackpoints.</source>
        <translation>El número de puntos del track no es igual al número de datos de entrenamiento.</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="285"/>
        <location filename="../CTrack.cpp" line="330"/>
        <source>Number of trackpoints is not equal the number of extended data trackpoints.</source>
        <translation>El número de puntos del track no es igual al número de datos extendidos.</translation>
    </message>
    <message>
        <location filename="../CTrack.cpp" line="358"/>
        <location filename="../CTrack.cpp" line="383"/>
        <source>Number of trackpoints is not equal the number of shadow data trackpoints.</source>
        <translation>El número de puntos del track no es igual al número de datos sombreados.</translation>
    </message>
    <message>
        <location filename="../GeoMath.cpp" line="550"/>
        <location filename="../GeoMath.cpp" line="556"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Bad position format. Must be: [N|S] ddd mm.sss [W|E] ddd mm.sss</source>
        <translation type="obsolete">Formato de posición erróneo. Debe de ser: [N|S] ddd mm.sss [W|E] ddd mm.sss</translation>
    </message>
    <message>
        <location filename="../GeoMath.cpp" line="550"/>
        <source>Bad position format. Must be: &quot;[N|S] ddd mm.sss [W|E] ddd mm.sss&quot; or &quot;[N|S] ddd.ddd [W|E] ddd.ddd&quot;</source>
        <translation>Formato de posición erróneo. Debe ser: &quot;[N|S] ddd mm.sss [O|E] ddd mm.sss&quot; o &quot;[N|S] ddd.ddd [O|E] ddd.ddd&quot;</translation>
    </message>
    <message>
        <location filename="../GeoMath.cpp" line="556"/>
        <source>Position values out of bounds. </source>
        <translation>Valores de posición fuera de los límites. </translation>
    </message>
    <message>
        <location filename="../GeoMath.cpp" line="779"/>
        <location filename="../GeoMath.cpp" line="792"/>
        <location filename="../GeoMath.cpp" line="810"/>
        <source>Error ...</source>
        <translation>Error ...</translation>
    </message>
    <message>
        <location filename="../GeoMath.cpp" line="779"/>
        <location filename="../GeoMath.cpp" line="792"/>
        <source>Failed to setup projection. Bad syntax?
%1</source>
        <translation>Fallo al configurar proyección. ¿Sintaxis errónea?
%1</translation>
    </message>
    <message>
        <location filename="../GeoMath.cpp" line="810"/>
        <source>Failed to read reference coordinate. Bad syntax?
%1</source>
        <translation>Fallo al leer las coordenadas de referencia. ¿Sintaxis errónea? %1</translation>
    </message>
    <message>
        <location filename="../tcxreader.cpp" line="48"/>
        <source>Error open file &apos;%1&apos;: %2</source>
        <translation>Error al abrir el archivo&apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location filename="../tcxreader.cpp" line="72"/>
        <source>The file is not an http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2 file.</source>
        <translation>El fichero no es un archivo en formato http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2 .</translation>
    </message>
    <message>
        <location filename="../CCanvasUndoCommandZoom.cpp" line="28"/>
        <source>Zoom in</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <location filename="../CCanvasUndoCommandZoom.cpp" line="30"/>
        <source>Zoom out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <location filename="../CMapUndoCommandMove.cpp" line="27"/>
        <source>Move Map</source>
        <translation>Mover el Mapa</translation>
    </message>
    <message>
        <location filename="../CTrackUndoCommandDelete.cpp" line="29"/>
        <source>delete track</source>
        <translation>borrar track</translation>
    </message>
    <message>
        <location filename="../CTrackUndoCommandDeletePts.cpp" line="25"/>
        <source>Delete Selection</source>
        <translation>Borrar Selección</translation>
    </message>
    <message>
        <location filename="../CTrackUndoCommandPurgePts.cpp" line="25"/>
        <source>Purge Selection</source>
        <translation>Eliminar Selección</translation>
    </message>
    <message>
        <location filename="../CTrackUndoCommandSelect.cpp" line="27"/>
        <source>Select Trackpoints</source>
        <translation>Seleccionar puntos del track</translation>
    </message>
    <message>
        <location filename="../CTrackUndoCommandSelect.cpp" line="29"/>
        <source>Unselect Trackpoints</source>
        <translation>Desmarcar puntos del track</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="60"/>
        <source>There is a problem with your Proj4 library and localization. The key issue is that the floating point definition in your localization is different from what Proj4 uses for it&apos;s correction tables (&apos;1.2&apos; vs &apos;1,2&apos;). That might cause an offset when using raster maps. Vector maps are not affected, as they use a projection that works without a textual table. </source>
        <translation>Hay un problema con su librería Proj4 y su configuración de idioma. La cuestión es que la definición de la coma flotante en su localización es diferente de lo que utiliza Proj4 para las tablas de corrección (&apos;1.2&apos; frente a &apos;1,2&apos;). Esto podría causar un desajuste al usar mapas raster. Los mapas vectoriales no se ven afectados, pues utilizan una proyección que trabaja sin una tabla textual.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=utf-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap; }           td {padding-top: 10px;}           th {background-color: lightBlue;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family:&apos;Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${info}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=utf-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap; }           td {padding-top: 10px;}           th {background-color: lightBlue;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family:&apos;Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${info}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=UTF-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap; }           td {padding-top: 10px;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family:&apos;Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${copyright}&lt;/p&gt;       &lt;h1&gt;Map Levels&lt;/h1&gt;       &lt;p&gt;${maplevels}&lt;/p&gt;       &lt;h1&gt;Legend&lt;/h1&gt;       &lt;h2&gt;Lines&lt;/h2&gt;       &lt;p&gt;${legendlines}&lt;/p&gt;       &lt;h2&gt;Areas&lt;/h2&gt;       &lt;p&gt;${legendareas}&lt;/p&gt;       &lt;h2&gt;Points&lt;/h2&gt;       &lt;p&gt;${legendpoints}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=UTF-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap; }           td {padding-top: 10px;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family:&apos;Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${copyright}&lt;/p&gt;       &lt;h1&gt;Niveles de Mapa&lt;/h1&gt;       &lt;p&gt;${maplevels}&lt;/p&gt;       &lt;h1&gt;Leyenda&lt;/h1&gt;       &lt;h2&gt;Líneas&lt;/h2&gt;       &lt;p&gt;${legendlines}&lt;/p&gt;       &lt;h2&gt;Áreas&lt;/h2&gt;       &lt;p&gt;${legendareas}&lt;/p&gt;       &lt;h2&gt;Puntos&lt;/h2&gt;       &lt;p&gt;${legendpoints}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../CDlgLoadOnlineMap.cpp" line="34"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=utf-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap; }           td {padding-top: 10px;}           th {background-color: darkBlue; color: white;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family:&apos;Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${info}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../CDlgMapJNXConfig.cpp" line="29"/>
        <location filename="../CDlgMapQMAPConfig.cpp" line="29"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=utf-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap;}           td {padding-top: 3px;}           th {background-color: darkBlue; color: white;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family: sans-serif; font-size: 9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${info}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../CDlgMapRMPConfig.cpp" line="28"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=utf-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap;}           td {padding-top: 3px;}           h1,th {background-color: darkBlue; color: white;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family: sans-serif; font-size: 9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${info}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../CDlgMapTDBConfig.cpp" line="29"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &apos;-//W3C//DTD HTML 4.01 Transitional//EN&apos;  &apos;http://www.w3.org/TR/html4/loose.dtd&apos;&gt;&lt;html&gt;   &lt;head&gt;       &lt;title&gt;&lt;/title&gt;       &lt;META HTTP-EQUIV=&apos;CACHE-CONTROL&apos; CONTENT=&apos;NO-CACHE&apos;&gt;       &lt;meta http-equiv=&apos;Content-Type&apos; content=&apos;text/html; charset=UTF-8&apos;&gt;       &lt;style type=&apos;text/css&apos;&gt;           p, li { white-space: pre-wrap;}           td {padding-top: 3px;}           th {background-color: darkBlue; color: white;}       &lt;/style&gt;   &lt;/head&gt;   &lt;body style=&apos; font-family: sans-serif; font-size: 9pt; font-weight:400; font-style:normal;&apos;&gt;       &lt;p&gt;${copyright}&lt;/p&gt;       &lt;h1&gt;Map Levels&lt;/h1&gt;       &lt;p&gt;${maplevels}&lt;/p&gt;       &lt;h1&gt;Legend&lt;/h1&gt;       &lt;h2&gt;Lines&lt;/h2&gt;       &lt;p&gt;${legendlines}&lt;/p&gt;       &lt;h2&gt;Areas&lt;/h2&gt;       &lt;p&gt;${legendareas}&lt;/p&gt;       &lt;h2&gt;Points&lt;/h2&gt;       &lt;p&gt;${legendpoints}&lt;/p&gt;   &lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../CExchangeGarmin.cpp" line="52"/>
        <source>No &apos;Garmin/GarminDevice.xml&apos; found</source>
        <translation>No se ha encontrado &apos;Garmin/GarminDevice.xml&apos;</translation>
    </message>
    <message>
        <location filename="../CExchangeGarmin.cpp" line="209"/>
        <location filename="../CExchangeGarmin.cpp" line="217"/>
        <source>Failed to read...</source>
        <translation>Error al leer...</translation>
    </message>
    <message>
        <location filename="../CExchangeGarmin.cpp" line="209"/>
        <source>Failed to read: %1
line %2, column %3:
 %4</source>
        <translation>Error al leer: %1
línea %2, columna %3:
 %4</translation>
    </message>
    <message>
        <location filename="../CExchangeGarmin.cpp" line="217"/>
        <source>Not a GPX file: </source>
        <translation>No es un archivo GPX: </translation>
    </message>
    <message>
        <location filename="../COverlayAreaEditWidget.cpp" line="54"/>
        <source>thin</source>
        <translation>fino</translation>
    </message>
    <message>
        <location filename="../COverlayAreaEditWidget.cpp" line="55"/>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <location filename="../COverlayAreaEditWidget.cpp" line="56"/>
        <source>wide</source>
        <translation>ancho</translation>
    </message>
    <message>
        <location filename="../COverlayAreaEditWidget.cpp" line="57"/>
        <source>strong</source>
        <translation>muy ancho</translation>
    </message>
</context>
</TS>
